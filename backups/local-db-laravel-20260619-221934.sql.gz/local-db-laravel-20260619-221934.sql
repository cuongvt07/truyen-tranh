-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `achievements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'reading',
  `metric` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chapters_read',
  `target` int unsigned NOT NULL DEFAULT '1',
  `reward_credits` int unsigned NOT NULL DEFAULT '0',
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `achievements_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
INSERT INTO `achievements` VALUES (1,'first_chapter','Bước đầu đọc truyện','First Chapter','Đọc 1 chương đầu tiên.','Read your first chapter.','reading','chapters_read',1,1,1,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(2,'reader_5','Đọc chăm chỉ','Getting Started','Đọc 5 chương.','Read 5 chapters.','reading','chapters_read',5,2,2,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(3,'reader_50','Mọt sách','Bookworm','Đọc 50 chương.','Read 50 chapters.','reading','chapters_read',50,5,3,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(4,'reader_200','Người đọc tích cực','Avid Reader','Đọc 200 chương.','Read 200 chapters.','reading','chapters_read',200,10,4,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(5,'reader_1000','Người đọc không ngừng','Marathon Reader','Đọc 1000 chương.','Read 1000 chapters.','reading','chapters_read',1000,30,5,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(6,'first_comment','Bình luận đầu tiên','First Comment','Đăng bình luận đầu tiên.','Post your first comment.','social','comments_posted',1,1,10,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(7,'commenter_10','Tích cực bình luận','Active Commenter','Đăng 10 bình luận.','Post 10 comments.','social','comments_posted',10,3,11,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(8,'commenter_50','Trụ cột cộng đồng','Community Pillar','Đăng 50 bình luận.','Post 50 comments.','social','comments_posted',50,10,12,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(9,'first_bookmark','Đánh dấu truyện','First Bookmark','Theo dõi 1 truyện.','Follow your first story.','social','bookmarks',1,1,15,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(10,'bookmark_10','Tủ sách riêng','Bookshelf','Theo dõi 10 truyện.','Follow 10 stories.','social','bookmarks',10,3,16,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(11,'bookmark_50','Thư viện cá nhân','Personal Library','Theo dõi 50 truyện.','Follow 50 stories.','social','bookmarks',50,10,17,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(12,'first_deposit','Nhà đầu tư mới','New Investor','Nạp xu lần đầu tiên.','Make your first deposit.','support','deposit_count',1,20,20,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(13,'deposit_3','Người ủng hộ','Supporter','Nạp xu 3 lần.','Make 3 deposits.','support','deposit_count',3,30,21,'2026-06-18 22:55:11','2026-06-18 22:55:11'),(14,'big_spender','Người bảo trợ lớn','Big Spender','Tổng nạp ≥ 500.000 VNĐ.','Total deposit ≥ 500,000 VND.','support','deposit_total',500000,100,22,'2026-06-18 22:55:11','2026-06-18 22:55:11');
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ad_items`
--

DROP TABLE IF EXISTS `ad_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ad_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ad_items_ad_id_is_active_sort_order_index` (`ad_id`,`is_active`,`sort_order`),
  CONSTRAINT `ad_items_ad_id_foreign` FOREIGN KEY (`ad_id`) REFERENCES `ads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ad_items`
--

LOCK TABLES `ad_items` WRITE;
/*!40000 ALTER TABLE `ad_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ad_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'banner',
  `placement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pages` json DEFAULT NULL,
  `frequency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'once_session',
  `frequency_value` int unsigned NOT NULL DEFAULT '1',
  `delay_seconds` int unsigned NOT NULL DEFAULT '0',
  `after_click` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `cooldown_seconds` int unsigned NOT NULL DEFAULT '0',
  `chapter_start` int unsigned NOT NULL DEFAULT '2',
  `chapter_interval` int unsigned NOT NULL DEFAULT '1',
  `chapter_inline_count` smallint unsigned NOT NULL DEFAULT '1',
  `chapter_inline_first_after` smallint unsigned NOT NULL DEFAULT '4',
  `chapter_inline_every` smallint unsigned NOT NULL DEFAULT '8',
  `hide_for_vip` tinyint(1) NOT NULL DEFAULT '1',
  `require_click` tinyint(1) NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `start_at` timestamp NULL DEFAULT NULL,
  `end_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ads`
--

LOCK TABLES `ads` WRITE;
/*!40000 ALTER TABLE `ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affiliate_links`
--

DROP TABLE IF EXISTS `affiliate_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `article_id` bigint unsigned NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `affiliate_links_article_id_foreign` (`article_id`),
  CONSTRAINT `affiliate_links_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affiliate_links`
--

LOCK TABLES `affiliate_links` WRITE;
/*!40000 ALTER TABLE `affiliate_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `affiliate_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_character`
--

DROP TABLE IF EXISTS `article_character`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_character` (
  `article_id` bigint unsigned NOT NULL,
  `character_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`article_id`,`character_id`),
  KEY `article_character_character_id_foreign` (`character_id`),
  CONSTRAINT `article_character_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `article_character_character_id_foreign` FOREIGN KEY (`character_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_character`
--

LOCK TABLES `article_character` WRITE;
/*!40000 ALTER TABLE `article_character` DISABLE KEYS */;
/*!40000 ALTER TABLE `article_character` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_tag`
--

DROP TABLE IF EXISTS `article_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_tag` (
  `article_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`article_id`,`tag_id`),
  KEY `article_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `article_tag_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `article_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_tag`
--

LOCK TABLES `article_tag` WRITE;
/*!40000 ALTER TABLE `article_tag` DISABLE KEYS */;
INSERT INTO `article_tag` VALUES (1,1),(3,1),(5,1),(8,1),(10,1),(17,1),(19,1),(20,1),(21,1),(23,1),(24,1),(25,1),(26,1),(27,1),(29,1),(1,2),(13,2),(1,3),(3,3),(13,3),(1,4),(14,4),(1,5),(2,5),(3,5),(14,5),(1,6),(8,6),(1,7),(3,7),(1,8),(5,8),(1,9),(1,10),(2,10),(21,10),(1,11),(2,12),(3,12),(6,12),(7,12),(14,12),(15,12),(30,12),(2,13),(3,13),(7,13),(10,13),(12,13),(13,13),(14,13),(19,13),(21,13),(24,13),(27,13),(2,14),(11,14),(28,14),(2,15),(5,15),(6,15),(9,15),(11,15),(14,15),(15,15),(16,15),(18,15),(21,15),(22,15),(23,15),(28,15),(29,15),(2,16),(7,16),(11,16),(13,16),(14,16),(16,16),(18,16),(2,17),(3,17),(7,17),(10,17),(11,17),(13,17),(18,17),(21,17),(27,17),(2,18),(2,19),(23,19),(2,20),(2,21),(14,21),(2,22),(23,22),(28,22),(2,23),(15,23),(21,23),(30,23),(2,24),(7,24),(8,24),(11,24),(13,24),(14,24),(16,24),(21,24),(2,25),(2,26),(16,26),(28,26),(2,27),(17,27),(2,28),(7,28),(2,29),(2,30),(7,30),(28,30),(29,30),(30,30),(2,31),(14,31),(2,32),(14,32),(2,33),(3,33),(14,33),(21,33),(29,33),(2,34),(3,34),(21,34),(2,35),(14,35),(2,36),(2,37),(9,37),(16,37),(30,37),(2,38),(11,38),(14,38),(16,38),(18,38),(29,38),(2,39),(13,39),(2,40),(3,40),(2,41),(2,42),(14,42),(2,43),(2,44),(7,44),(8,44),(13,44),(14,44),(16,44),(17,44),(20,44),(21,44),(22,44),(2,45),(3,46),(3,47),(29,47),(3,48),(21,48),(26,48),(28,48),(3,49),(3,50),(28,50),(3,51),(14,51),(21,51),(28,51),(3,52),(8,52),(13,52),(19,52),(21,52),(3,53),(21,53),(3,54),(11,54),(16,54),(18,54),(27,54),(3,55),(21,55),(28,55),(29,55),(3,56),(3,57),(3,58),(21,58),(3,59),(4,59),(8,59),(16,59),(3,60),(9,60),(28,60),(3,61),(5,61),(8,61),(9,61),(3,62),(29,62),(3,63),(6,63),(27,63),(3,64),(21,64),(3,65),(3,66),(9,66),(10,66),(11,66),(21,66),(28,66),(3,67),(14,67),(3,68),(5,68),(15,68),(28,68),(30,68),(3,69),(14,69),(29,69),(3,70),(14,70),(21,70),(24,70),(3,71),(21,71),(22,71),(28,71),(29,71),(3,72),(3,73),(5,73),(6,73),(21,73),(3,74),(15,74),(21,74),(28,74),(3,75),(28,75),(3,76),(21,76),(3,77),(18,77),(21,77),(30,77),(3,78),(11,78),(21,78),(24,78),(30,78),(3,79),(5,79),(15,79),(21,79),(3,80),(6,80),(14,80),(21,80),(24,80),(27,80),(3,81),(14,81),(21,81),(3,82),(3,83),(3,84),(3,85),(24,85),(3,86),(3,87),(21,87),(3,88),(27,88),(4,89),(8,89),(21,89),(4,90),(4,91),(28,91),(5,92),(5,93),(30,93),(5,94),(5,95),(14,95),(5,96),(21,96),(5,97),(5,98),(21,98),(5,99),(9,99),(14,99),(15,99),(18,99),(5,100),(8,100),(5,101),(18,101),(29,101),(5,102),(5,103),(5,104),(28,104),(5,105),(15,105),(5,106),(21,106),(5,107),(21,107),(5,108),(11,108),(15,108),(18,108),(27,108),(6,109),(9,109),(15,109),(17,109),(22,109),(23,109),(28,109),(30,109),(6,110),(18,110),(22,110),(23,110),(6,111),(6,112),(16,112),(6,113),(22,113),(23,113),(6,114),(10,114),(14,114),(30,114),(6,115),(6,116),(11,116),(15,116),(21,116),(22,116),(24,116),(28,116),(6,117),(10,117),(14,117),(19,117),(6,118),(6,119),(7,120),(11,120),(13,120),(21,120),(7,121),(24,121),(7,122),(30,122),(7,123),(7,124),(28,124),(30,124),(7,125),(8,126),(19,126),(21,126),(8,127),(27,127),(8,128),(20,128),(28,128),(8,129),(14,129),(20,129),(8,130),(13,130),(21,130),(8,131),(8,132),(8,133),(10,133),(13,133),(27,133),(8,134),(10,134),(24,134),(8,135),(8,136),(8,137),(14,137),(21,137),(28,137),(8,138),(28,138),(8,139),(30,139),(8,140),(8,141),(24,141),(28,141),(8,142),(22,142),(9,143),(28,143),(30,143),(9,144),(9,145),(16,145),(18,145),(29,145),(9,146),(15,146),(28,146),(29,146),(9,147),(11,147),(18,147),(9,148),(9,149),(16,149),(9,150),(9,151),(28,151),(29,151),(9,152),(9,153),(28,153),(9,154),(14,154),(15,154),(16,154),(30,154),(9,155),(11,155),(15,155),(9,156),(14,156),(9,157),(22,157),(29,157),(30,157),(9,158),(16,158),(29,158),(9,159),(16,159),(21,159),(28,159),(9,160),(9,161),(10,162),(10,163),(16,163),(11,164),(11,165),(21,165),(11,166),(15,166),(11,167),(21,167),(11,168),(11,169),(29,169),(11,170),(12,171),(12,172),(13,173),(14,173),(13,174),(14,174),(30,174),(13,175),(24,175),(13,176),(21,176),(14,177),(15,177),(17,177),(14,178),(16,178),(30,178),(14,179),(20,179),(14,180),(30,180),(14,181),(14,182),(14,183),(20,183),(14,184),(28,184),(14,185),(14,186),(30,186),(14,187),(14,188),(14,189),(14,190),(14,191),(16,191),(14,192),(30,192),(14,193),(14,194),(30,194),(14,195),(14,196),(14,197),(14,198),(15,199),(29,199),(15,200),(28,200),(15,201),(15,202),(15,203),(28,203),(30,203),(15,204),(15,205),(16,206),(16,207),(16,208),(16,209),(21,209),(16,210),(16,211),(30,211),(16,212),(23,212),(16,213),(19,213),(17,214),(17,215),(21,215),(17,216),(18,217),(28,217),(18,218),(18,219),(28,219),(29,219),(18,220),(18,221),(19,222),(19,223),(19,224),(19,225),(21,225),(19,226),(21,226),(19,227),(20,228),(24,228),(27,228),(20,229),(28,229),(21,230),(28,230),(21,231),(21,232),(29,232),(21,233),(21,234),(21,235),(21,236),(21,237),(21,238),(21,239),(21,240),(21,241),(21,242),(21,243),(21,244),(21,245),(21,246),(21,247),(21,248),(22,248),(28,248),(21,249),(21,250),(21,251),(21,252),(21,253),(24,253),(29,253),(21,254),(22,255),(30,255),(22,256),(28,256),(22,257),(23,258),(28,258),(30,258),(24,259),(24,260),(24,261),(26,261),(24,262),(25,263),(26,263),(26,264),(29,264),(26,265),(26,266),(26,267),(28,267),(27,268),(27,269),(27,270),(27,271),(30,271),(27,272),(27,273),(27,274),(28,275),(28,276),(28,277),(28,278),(28,279),(28,280),(28,281),(28,282),(28,283),(28,284),(28,285),(28,286),(28,287),(28,288),(28,289),(28,290),(28,291),(28,292),(28,293),(30,293),(28,294),(28,295),(28,296),(30,296),(28,297),(29,297),(28,298),(29,299),(30,299),(29,300),(29,301),(29,302),(29,303),(29,304),(29,305),(30,305),(29,306),(29,307),(29,308),(29,309),(29,310),(29,311),(29,312),(29,313),(29,314),(29,315),(30,315),(29,316),(29,317),(29,318),(29,319),(29,320),(29,321),(29,322),(29,323),(29,324),(30,325),(30,326),(30,327),(30,328),(30,329),(30,330),(30,331),(30,332);
/*!40000 ALTER TABLE `article_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `team_id` bigint unsigned DEFAULT NULL,
  `is_user_submitted` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `illustrator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_release` year DEFAULT NULL,
  `country` tinyint DEFAULT NULL,
  `similar_article_ids` json DEFAULT NULL,
  `translation_request_article_ids` json DEFAULT NULL,
  `related_genre_ids` json DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',
  `novel_type` tinyint NOT NULL DEFAULT '0',
  `is_adult` tinyint(1) NOT NULL DEFAULT '0',
  `credit_start_chapter` smallint unsigned DEFAULT NULL,
  `credit_per_chapter` smallint unsigned NOT NULL DEFAULT '0',
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affi_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affi_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view` int NOT NULL DEFAULT '0',
  `rating` decimal(3,1) NOT NULL DEFAULT '0.0',
  `rating_count` int unsigned NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_title_unique` (`title`),
  KEY `articles_user_id_foreign` (`user_id`),
  KEY `articles_is_user_submitted_index` (`is_user_submitted`),
  KEY `articles_team_id_foreign` (`team_id`),
  CONSTRAINT `articles_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL,
  CONSTRAINT `articles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,201,NULL,0,'0.0000001% Demon King',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'The 72 Demons invading the Earth, the Demon Kings.Each of them possesses unique abilities.\n\nThey alter matter,Dominate minds,And topple mountains – each power is transcendent.\n\nI, too, am a Demon King.',0,0,0,NULL,0,'/images/articles/novelight/covers/00000001-demon-king-read-online-93ccd91d82.webp','https://novelight.net/media/book/background/2024/03/25/0.0000001_Demon_King_Read_Online.webp',NULL,NULL,2242,0.0,0,1,'2026-06-07 21:29:45','2026-06-15 23:08:39'),(2,201,NULL,0,'12 O’Clock Marionette',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'“Blonde again this time.”\n\nIt’s already the third time being possessed. The third time with blonde hair. At this point, I can’t help but doubt the taste of the deity I serve, Pebula.\n\nUpon waking up, the detailed personal information of the third body, Siora, is as follows:\n\n[Siora Velvet. 20 years old.\n\nParents died in a fire.\n\nCurrently under the protection of Count Bonetti.\n\nRemaining assets: 0g.\n\nScheduled to be evicted in 3 days]\n\nIt’s clearly a worse situation than the previous two possessions!\n\n***\n\nAs the only priestess, cleric, saint, and pope of the ancient deity Pebula, one day she received a book.\n\nThe book titled described that the world would soon be destroyed by the villain ‘Cruello White Desert.’\n\n“Ancient deity Pebula, please perform a miracle.”\n\nAs soon as she finished reading the book, Pebula, who had given the revelation to ‘Reform the villain!’ immediately threw her into the body of the villain’s childhood fiancée.\n\nFirst attempt: Died after being poisoned instead of the villain, thus failing. Second attempt: Possessed the body of the villain’s maid but also failed, as she was too focused on doing nothing but dying.\n\nFinally, the third attempt.\n\nWaking up in the body of Siora, who had no connection with the villain, she strives to make a connection with Cruello.\n\nHowever, there is only one year left before Cruello destroys the world…\n\nMoreover, after two failed attempts, the once innocent child has already grown into a wicked villain!\n\nLike Cinderella returning home at midnight, Siora wants to save Cruello and escape her duties. Will she be able to fulfill her role and break free from her fate?\n\n#Overpowered #MultiplePossessions #PoliticalMarriage #Revenge #ComingOfAge #Redemption #SaintOfAncientDeity #ReformTheVillain',1,0,0,NULL,0,'/images/articles/novelight/covers/oclock-marionette-1640051357-rfo6d65-989a1b0fe6.jpg','https://novelight.net/media/book/background/2025/02/04/OClock-Marionette_1640051357.jpg',NULL,NULL,3168,0.0,0,1,'2026-06-07 21:29:45','2026-06-07 21:29:45'),(3,201,NULL,0,'30 Years Have Passed Since the Prologue',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'I got transmigrated into a game I’ve never seen before.\n\nI thought it was a top-notch RPG and spent 30 years on it.\n\nI retired as a war hero and planned to spend my remaining time leisurely.\n\nBut it turns out, it was an academy story?',0,0,0,NULL,0,'/images/articles/novelight/covers/30-years-have-passed-since-the-prologue-web-novel-read-online-e498e80c28.webp','https://novelight.net/media/book/background/2024/04/09/30-years-have-passed-since-the-prologue-web-novel-read-online.webp',NULL,NULL,6299,0.0,0,1,'2026-06-07 21:29:46','2026-06-07 21:29:46'),(4,201,NULL,0,'86--EIGHTY-SIX (Light Novel)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Volume 1: \"Eighty-Six\"The Republic of San Magnolia has been at war with the Giadian Empire, which uses autonomous machines known as the Legion. Despite claims of a war without casualties, the Republic secretly employs humans from the 86th District to pilot these machines. The story follows Major Vladilena Milizé and Shinei Nouzen, the leader of the 86, as they navigate the brutal realities of war.\n\nVolume 2: \"Run Through the Battlefront (Start)\"The continuation of the conflict sees Lena struggling with the moral implications of her role, while Shin and his squad face increasingly dangerous missions. Relationships between the characters deepen, revealing more about their backgrounds and motivations.\n\nVolume 3: \"Run Through the Battlefront (Finish)\"The stakes escalate as the 86 face new threats from the Legion. Shin\'s leadership is put to the test, and Lena must confront her superiors to protect her squad. This volume concludes the intense battles started in Volume 2.\n\nVolume 4: \"Under Pressure\"With the war intensifying, new alliances are formed. Lena and Shin\'s bond strengthens, but they are continuously challenged by the harsh realities of their world. The story delves into themes of sacrifice and resilience.\n\nVolume 5: \"Death, Be Not Proud\"As the Legion\'s attacks become more relentless, the 86 must adapt to survive. This volume explores the psychological and emotional toll of the war on the characters, particularly focusing on their personal growth and struggles.\n\nVolume 6: \"Darkest Before the Dawn\"The narrative reaches new heights of tension as the 86 uncover critical information about the Legion. The characters face internal and external battles, pushing their limits in the fight for survival.\n\nVolume 7: \"Mist\"The squad undergoes a period of rest and recuperation, but the respite is short-lived. New challenges arise, and relationships are tested. This volume focuses on character development and the deepening of existing conflicts.\n\nVolume 8 and beyondThe subsequent volumes continue to expand the story, introducing new characters, conflicts, and revelations. Each volume builds upon the last, creating a complex and engaging narrative that keeps readers invested in the fate of the 86.',0,0,0,NULL,0,'/images/articles/novelight/covers/9781975373474-e687f94434.webp','https://novelight.net/media/book/background/2024/06/27/86_complete_edition.webp',NULL,NULL,336,0.0,0,1,'2026-06-07 21:29:47','2026-06-07 21:29:47'),(5,201,NULL,0,'A Destiny That Must Die',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\'The one who receives this curse will die in exactly ten years.\'\n\nThat’s the legacy I inherited. A fate where I am literally destined to die. To ensure I die on the appointed day, I am forbidden from dying before it, no matter what I do.\n\nTen years of immortality, followed by certain death.And the moment that death finally descends, the curse transfers to the person you loved most in your life.\n\nThat’s why I left him.\n\n“Hyung, you’ll stay with me forever, right?”\n\nI made that promise and then I broke it, abandoning the kid. There was no way I was going to pass this vicious curse onto someone so innocent. And so, I resolved to never appear before him again…\n\nBut now, with only a year left on the clock, fate, that cruel joke, has thrown us back together.\n\nExcept the boy I once knew has changed.\n\n“Why are you trembling like that?”\n\nSo much that I almost don\'t recognize him.\n\n“Are you scared? Scared I might do something… bad to you?”',1,0,0,NULL,0,'/images/articles/novelight/covers/no-2580d49b97.jpg','https://novelight.net/media/book/background/2025/10/22/no.jpg',NULL,NULL,2095,0.0,0,1,'2026-06-07 21:29:48','2026-06-07 21:29:48'),(6,201,NULL,0,'A Former Gangster Boss’s Possession of a Housekeeper in an R-19 Novel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'I was born with a silver spoon in my mouth, right in the middle of a mob family. But when I lost consciousness and woke up, I wasn’t the boss, nor the successor—I was a mere housekeeper.\n\nTo make matters worse, I was the timid, introverted extra whose role was to die in place of the female lead. At first, I just worked silently to survive, but it turns out the housekeeping life suits my aptitude better than I thought.\n\nBut then, the male leads, who used to shudder with disgust at the original owner, started sticking to me, begging me to do this and that….\n\nI started dealing with them the way I’d play with young nephews… but strangely, they keep taking their clothes off in front of me and showing off their muscles.\n\nYeah. I guess since you’re the male leads of an R-19 novel, your bodies are killer. But guys. The female lead is over there? Why are you stripping in front of me? You’ll catch a cold.\n\nA push-and-pull love story between an indifferent housekeeper and the three gangster brothers—where only the housekeeper is clueless about what’s going on.',1,0,0,NULL,0,'/images/articles/novelight/covers/a-former-gangster-bosss-possession-of-a-housekeeper-in-an-r-novel-07a130efdd.webp','https://novelight.net/media/book/background/2025/12/26/A-Former-Gangster-Bosss-Possession-of-a-Housekeeper-in-an-R-Novel.webp',NULL,NULL,8811,0.0,0,1,'2026-06-07 21:29:50','2026-06-07 21:29:50'),(7,201,NULL,0,'A Fortune-telling Princess',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Lee Sia is a top actress with the ability to see ghosts.\n\nAfter an accident, she wakes up in the body of ‘Camilla Sorpel’.\n\nThe problem is…\n\n“Ah, father! Please spare me!”\n\n…that this woman always meets a gruesome end!\n\nSince extending the lifeline is a priority, let’s start by communing with the ghosts here, shall we?\n\n“You will get a divorce soon.”\n\n“…What?”\n\nThe atmosphere in the conference hall suddenly becomes uncomfortable again as the hummed words hang in the air.\n\n“What are you talking about now…?!”\n\n“Your servant’s wife.”\n\nThe bewilderment is evident on the face of the person subjected to these words.\n\n“She is also the wife of a subordinate whom she cherishes the most.”\n\n“Wh-What…?!”\n\n“Have you heard of my rumors?”\n\nCamilla smiled and took a step closer.\n\n“They say that the princess of the Sorpel family is looking at some fortune-telling.”',1,0,0,NULL,0,'/images/articles/novelight/covers/a-fortunetelling-princess-sxqvduh-22fc327bb3.jpg','https://novelight.net/media/book/background/2025/09/19/A-Fortunetelling-Princess.jpg',NULL,NULL,1199,0.0,0,1,'2026-06-07 21:29:51','2026-06-07 21:29:51'),(8,201,NULL,0,'A Knight Who Eternally Regresses',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'The Knight Who Lives for Today is a riveting fantasy novel that masterfully intertwines the concepts of time loops and personal growth. Written by Soulpung, this series has quickly gained recognition for its unique premise, compelling protagonist, and thought-provoking themes. Available on Naver Series, it’s a must-read for fans of character-driven stories with a touch of existential intrigue.\n\nPlot OverviewThe story follows Enkrid, a young man who dreams of becoming a knight despite his lack of extraordinary talent. Trapped in mediocrity and crushed by the weight of societal expectations, his life takes a sharp turn when he dies in battle—only to wake up at the beginning of the same day. Armed with this mysterious ability to relive each day, Enkrid embarks on a relentless journey to perfect his skills, uncover hidden truths, and prove that even an ordinary man can achieve greatness.\n\nStrengths\n\nEngaging Character Development:Enkrid’s journey is both inspiring and relatable. His struggle to overcome his limitations resonates deeply with readers, and his growth feels earned rather than handed to him by the plot. Each loop presents him with new challenges, forcing him to adapt, learn, and push beyond his boundaries.\n\nInnovative Use of Time Loops:Unlike many time-loop stories that focus solely on the mechanics of repetition, The Knight Who Lives for Today uses the concept as a tool for introspection and resilience. Enkrid’s evolving understanding of his abilities keeps the narrative fresh and unpredictable.\n\nVivid World-Building:The novel paints a rich, immersive world where the ideals of knighthood clash with the harsh realities of war and politics. From the intricacies of swordsmanship to the camaraderie of soldiers, every detail feels authentic and well-researched.\n\nThemes of Perseverance and Redemption:At its core, the novel is a heartfelt exploration of perseverance in the face of adversity. Enkrid’s relentless drive to improve himself, even when the odds are stacked against him, serves as a powerful reminder that determination can overcome even the harshest circumstances.\n\nPotential Drawbacks\n\nFor readers looking for fast-paced action, the novel\'s introspective tone and focus on gradual character growth may feel slow at times. Additionally, while the time-loop concept is handled exceptionally well, those unfamiliar with this trope might need some time to adjust to its cyclical nature.\n\nConclusion\n\nSoulpung’s The Knight Who Lives for Today is a triumph of modern fantasy. It’s a story that doesn’t just entertain but also challenges readers to reflect on their own lives and the value of persistence. With its relatable protagonist, layered storytelling, and poignant themes, it’s no surprise that this novel has earned its place among Naver Series’ most popular titles.\n\nFor fans of tales like Re:Zero or Groundhog Day with a medieval twist, this is a book that should not be missed.\n\nVerdict: A deeply inspiring and thought-provoking journey, perfect for fans of time-loop narratives and character-driven fantasy.',0,0,0,NULL,0,'/images/articles/novelight/covers/a-knight-who-eternally-regresses-6a987361ad.jpg','https://novelight.net/media/book/background/2024/11/24/A-Knight-Who-Eternally-Regresses.jpg',NULL,NULL,1975,0.0,0,1,'2026-06-07 21:29:52','2026-06-07 21:29:52'),(9,201,NULL,0,'A Letter from Keanu Reeves',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Crown Prince Heir X Illegitimate Child\n\nZhao Shengge x Chen Wan\n\nChen Wan is smooth and tactful in dealing with people, relying on thoroughness and reliability to work his way into the crown prince circle. Wherever he is, even the humidity in the air feels just right.\n\nAll his efforts are not because he hopes Zhao Shengge will like him. Chen Wan seeks neither recognition nor credit. Zhao Shengge does not even need to know who he is. It is enough for Chen Wan to occasionally see him from afar within the same circle.\n\nA friend, frustrated at his lack of ambition, asks: What are you after?\n\n“Nothing,” Chen Wan smiles, holding firmly to his own unshakable creed of secret love. “If I have to say, then I just want that wherever I am, it can make him feel a little more at ease and happy.”\n\nZhao Shengge is heaven’s favored son, holding high status and great power. Chen Wan knows his place best. For something completely impossible, he does not allow himself even the slightest fantasy, and believes he has done everything flawlessly without leaving a trace.\n\nAt an auction, Chen Wan stays hidden in the crowd, offering polite greetings along with others. When he picks up something the other has dropped, he entrusts a friend to return it. When someone tries to use him to get closer to Zhao Shengge, he apologetically explains that the other party does not actually know him.\n\nThat is what he truly believes.\n\nUntil, on a cruise ship, the other man bites down on a cigarette and looks at him quietly and slowly. “Chen Wan, I didn’t bring a lighter.”\n\nOn the surface, it seems like the gong is being pursued, but in reality, the gong calmly guides the other into chasing him. A push-and-pull between adults, circling and probing, with undercurrents running deep. Between the two of them, there are eight hundred schemes in total.',1,0,0,NULL,0,'/images/articles/novelight/covers/a-letter-from-keanu-reeves-b79e230bd4.webp','https://novelight.net/media/book/background/2026/05/18/A_Letter_from_Keanu_Reeves.webp',NULL,NULL,7768,0.0,0,1,'2026-06-07 21:29:52','2026-06-07 21:29:52'),(10,201,NULL,0,'A Mastermind? No, I’m just the Live-In Son-in-Law',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'People keep assuming I’m some kind of evil mastermind.\n\nBut seriously, I’m just a son-in-law freeloading off my noble wife’s family.\n\n…Why does everyone look so suspicious?\n\nWait—don’t tell me. Is it because of my squinty eyes?!',1,0,0,NULL,0,'/images/articles/novelight/covers/a-mastermind-no-im-just-the-livein-soninlaw-gni62bg-10c95969fd.jpg','https://novelight.net/media/book/background/2025/03/17/A-Mastermind-No-Im-just-the-LiveIn-SoninLaw.jpg',NULL,NULL,2384,0.0,0,1,'2026-06-07 21:29:53','2026-06-07 21:29:53'),(11,201,NULL,0,'A Painting of the Villainess as a Young Lady',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'A villainess known by all as a wicked woman who has done all sorts of evil deeds—Ducal Lady Violet.She regained her memories of her previous life after she fell into a lake and almost died.The very moment she woke up, she immediately visited her father, Duke Everett, and asked one thing.\n\n“Please confine me to the annex.”\n\nAnd so, she imprisoned herself there.Now that Violet was secluded away from the world’s criticism and reproach,She immersed herself in her previous life’s memories and started painting them.\n\n“What the hell are you up to this time?”\n\nEveryone was suspicious of just what she might be scheming.However, the misunderstandings surrounding her gradually got resolved one at a time…',1,0,0,NULL,0,'/images/articles/novelight/covers/a-painting-of-the-villainess-as-a-young-lady-web-novel-read-online-2e1b1e91ca.webp','/images/articles/novelight/backgrounds/a-painting-of-the-villainess-as-a-young-lady-web-novel-read-online-7b2bf80072.webp',NULL,NULL,684,0.0,0,1,'2026-06-07 21:29:54','2026-06-07 21:29:54'),(12,201,NULL,0,'A Practical Guide to Evil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\"It doesn\'t matter how flawless the scheme was, how impregnable the fortress or powerful the magical weapon, it always ends with a band of adolescents shouting utter platitudes as they tear it all down. The game is rigged so that we lose, every single time: half the world, turned into a prop for the glory of the other half.\"— Black KnightA Practical Guide to Evil (2015-2022) is a Young Adult Heroic Fantasy Web Serial Novel written by erraticerrata. The seventh book of the series was completed on February 25th, 2022, ending the series. A key element of the setting is that many Heroic Fantasy tropes are enforced by the universe\'s laws.\n\nBlack-and-White Morality is an objective reality here. Individuals, species, and nations can be clearly and unapologetically Evil and Good. People can gain superhuman powers and a degree of in-universe Plot Armor by embodying certain archetypes, which leads to gaining a Name. The majority of Names have a definitive association with either Good or Evil. A few Names can be claimed by a person from either side. While some Names used in-story are more specific (Bumbling Conjurer, Ashen Priestess, etc.) the majority of Names can be found or derived from the Fantasy Character Classes page (Black Knight, White Knight, Ranger, Warlock, Thief). Named individuals are both more powerful than normal people (able to kill dozens or hundreds of Nameless Mooks or Red Shirts single-handedly) and more important in terms of fate (i.e. the plot). Fate tends to play out in patterns that can be manipulated by particularly Genre Savvy individuals. Named individuals also each have access to three personalized Aspects, initially undefined powerful moves or abilities that they gain access to at a suitably dramatic or necessary moment.\n\nThe series follows the exploits of sixteen-year-old Catherine Foundling, the Squire. An orphan born a few years after her homeland, the Kingdom of Callow, was annexed by their perennial foe, the Dread Empire of Praes, following a short and utterly devastating war of conquest, Catherine was raised at the Imperial House for Tragically Orphaned Girls. Although she resents the greed and corruption of the imperial governor of her home city, she is cynical about the prospects of rebellion, instead planning to join the Imperial Legions of Terror in order to improve the system from the inside. However, when she manages to impress the Empress\' Black Knight, she is offered a chance to join the ranks of the Named by taking the role of the Squire.\n\nBut the Balance of Good and Evil is reasserting itself. Whereas previously a new hero might have appeared in Callow once every few years, they are now popping up every few months, which is a rate that even the Black Knight\'s supremely efficient spy network can no longer keep a lid on. Meanwhile the very reforms that made it possible for the Dread Empire to triumph so completely are stirring unrest among the nobility of Praes, who seek a return to the Stupid Evil ways of the Empire\'s past. To make matters worse, the powerful neighbouring Principate of Procer has emerged from the long, debilitating civil war that has crippled them for so long — and are seeking revenge for the Empire\'s role in prolonging that conflict. As all of this threatens to boil over into a continent-wide war, Catherine must navigate her own, and her country\'s, path through the turmoil.\n\nThe premiere of Book 7 was also followed by an announcement for the author\'s next series, Pale Lights, which premiered August 26, 2022. The original 2015-2022 release of the series was always intended to be a first draft of a final published version, and a second draft has begun uploading to the Yonder web serial app as of October 2022.',1,0,0,NULL,0,'/images/articles/novelight/covers/01517-a-practical-guide-to-evil-fbd895de0f.jpg','https://novelight.net/media/book/background/2024/06/30/01517-a-practical-guide-to-evil.jpg',NULL,NULL,4538,0.0,0,1,'2026-06-07 21:29:54','2026-06-07 21:29:54'),(13,201,NULL,0,'A Secretly Capable Child Is Seeking For Her Dad',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Jongno-gu, Republic of Korea.\n\nAt the age of four, Tie received Father’s death notice.\n\n“In accordance with Article 12, Paragraph 1 of the Act on Funeral Services, the body of the deceased without family ties has been processed. Relatives are requested to claim the enshrined remains.”\n\nFather was always saying strange things.\n\nThat he came from the Empire of Tallocium.\n\nAnd that Tie’s true homeland was there as well.\n\n“Father will live with Tie for a long, long time. One day we will return to our homeland, and Tie will laugh in a much bigger and cleaner house.”\n\nHe spoke of returning to Tallocium. Of making her happy.\n\nIn the end, he left Tie behind.\n\nBut then—\n\nWhile searching through his belongings, a mysterious being appeared.\n\n“Shall I bring him back to life?”\n\n“A, a stone is talking…”\n\n“If you wish, I will return you. To where you were born. To where you were meant to be. To where that man is still alive.”\n\nTie was given one final chance.\n\nNow she could save Father and return to Tallocium.\n\nAnd she believed that everything would finally become simple.\n\n“Honestly, I was wondering when we would meet again.”\n\nAfter returning to the other world,\n\nTie was finally reunited with Father from the past—\n\nBut something was wrong.\n\n“For someone who has ruined countless livelihoods, you are quite shameless, King of the Dead.”\n\nFather… weren’t you a Holy Knight of the Imperial Holy Knight Order?\n\n“I am getting bored. Let us end this in a single round. The loser drops everything and leaves this field for good.”\n\nA mercenary.\n\nNot just any mercenary, but the leader of a high-ranking squad, infamous for cutting down Magical Beasts and dominating battlefields.\n\n“If I kill you today, won’t I reclaim the title of the most hired mercenary!”\n\nIt seemed Father had been hiding something.\n\nSomething vast.\n\nSomething extraordinary.',0,0,0,NULL,0,'/images/articles/novelight/covers/a-secretly-capable-child-is-seeking-for-her-dad-71e85daf61.jpg',NULL,NULL,NULL,5611,0.0,0,1,'2026-06-07 21:29:55','2026-06-07 21:29:55'),(14,201,NULL,0,'A Transmigrator’s Privilege',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'It’s the era of Transmigration.\n\nI wanted to possess a body of a rich young lady in a Rofan childcare novel, and live while receiving lots of love.\n\nNo. 1 to be avoided!\n\nNo. 1 in frustrating the reader!\n\nI possessed someone inside an infinite return novel called: Return Until the World is Saved.\n\nForget being a young lady from a prominent family, I will soon be ruined because the survival difficulty of the original work is S-Class.\n\nI became an extra. Ailette, the young daughter of a servant in the Count’s manor.\n\nWe are poor, but it’s a happy life between a kind brother and a good father.\n\nI’ve got a best friend I’ve never made before because I was always busy.\n\nEven the gods of the Transmigration Management Bureau are openly fond of me.\n\nI’m living a life full of confidence.\n\nOn top of that, I accidentally bought the ‘After-Life Insurance’ full package just before my death.\n\nI leveled up with the high-speed growth buff, and diligently destroyed the original plot.\n\nThanks to plenty of special privileges, I came to give satisfaction for all the frustrated readers of the original work.\n\n“You wiped your face with your dirty hands.”\n\n“…….”\n\n“Don’t be surprised. It’s because I have an obligation to be kind.”\n\nAnd then, there’s the protagonist who is still nothing more than a handsome push over, Thesilid.\n\n‘Why is he being this crafty with me?’',1,0,0,NULL,0,'/images/articles/novelight/covers/a-transmigrators-privilege-rs4jh3p-e7d559dcb9.jpg','https://novelight.net/media/book/background/2025/01/17/A-Transmigrators-Privilege.jpg',NULL,NULL,5307,0.0,0,1,'2026-06-07 21:29:57','2026-06-07 21:29:57'),(15,201,NULL,0,'A Villain, But Not a Villain',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[ 𝚀𝚞𝚎𝚜𝚝 𝟷: 𝙰𝚙𝚘𝚕𝚘𝚐𝚒𝚣𝚎 𝚝𝚘 𝚝𝚑𝚎 𝚖𝚊𝚒𝚗 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜. (𝟶/𝟹) ]\n\n(★𝚃𝙸𝙿: 𝙰 𝚜𝚠𝚎𝚎𝚝 𝚝𝚒𝚙 𝚏𝚘𝚛 𝚜𝚘𝚖𝚎𝚘𝚗𝚎 𝚠𝚑𝚘’𝚜 𝚗𝚎𝚟𝚎𝚛 𝚊𝚙𝚘𝚕𝚘𝚐𝚒𝚣𝚎𝚍 𝚋𝚎𝚏𝚘𝚛𝚎!★)\n\n*𝙷𝚘𝚠 𝚊𝚋𝚘𝚞𝚝 𝚐𝚒𝚏𝚝𝚒𝚗𝚐 𝚊 𝚌𝚛𝚎𝚊𝚖 𝚋𝚞𝚗 𝚊𝚜 𝚊 𝚐𝚎𝚜𝚝𝚞𝚛𝚎 𝚘𝚏 𝚢𝚘𝚞𝚛 𝚙𝚞𝚛𝚎-𝚑𝚎𝚊𝚛𝚝𝚎𝚍 𝚒𝚗𝚝𝚎𝚗𝚝𝚒𝚘𝚗𝚜 𝚝𝚘 𝚝𝚞𝚛𝚗 𝚘𝚟𝚎𝚛 𝚊 𝚗𝚎𝚠 𝚕𝚎𝚊𝚏?\n\n“I’m sorry. For everything I’ve done until now, I sincerely apologize.”\n\nI was supposed to be dead.\n\nBut overnight, I found myself reincarnated as the villain Min Yu-un in a novel.\n\nTo finally end this life, I must apologize and earn forgiveness as Min Yu-un.\n\nBut why?\n\nThe main love interest is desperate to stay by my side.\n\nThe second lead wants to be more than just friends.\n\nAnd the protagonist clings to me, blaming himself for everything.\n\nPlease, just leave me alone!\n\nAll you need to do is forgive me!',1,0,0,NULL,0,'/images/articles/novelight/covers/a-villain-but-not-a-villain-8a115dd7b5.webp','/images/articles/novelight/backgrounds/a-villain-but-not-a-villain-f7d208e8a3.webp',NULL,NULL,2319,0.0,0,1,'2026-06-07 21:30:00','2026-06-07 21:30:00'),(16,201,NULL,0,'A Wicked Husband',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cesare Traon Karl Erzet, the Imperial Commander-in-Chief.\n\nAfter three years of service in the war, he returned to propose to Eileen.\n\nEileen struggled to believe that Cesare’s marriage proposal was sincere.\n\nAfter all, from the moment they met when she was ten,\n\nThe affectionate man had always treated her like a child.\n\n“I don’t—I don’t want to marry Your Highness.”\n\nFor so long, her love for him was unrequited.\n\nShe did not wish for their marriage to be a transaction.\n\nWas it because of the long war?\n\nThe man, who was normally cool and rational, had changed.\n\nHis impulsive actions, his unbridled desire for her—they were all too unfamiliar.\n\n“This should only be done with someone you love!”\n\n“You can also do it with the person you plan to marry.”\n\nEileen was intrigued by this change.\n\nAnd yet, the closer she became with Cesare…\n\nShe discovered things that defied reason or logic.\n\nEileen learned about her husband’s many evil deeds not long after.\n\n“I couldn’t even have your body, Eileen.”\n\nEverything he did was for her.\n\nHe became the villain, only for his Eileen.',1,0,0,NULL,0,'/images/articles/novelight/covers/a-wicked-husband-1srnxgi-f32b0534c3.jpg','https://novelight.net/media/book/background/2025/09/25/A-Wicked-Husband.jpg',NULL,NULL,5533,0.0,0,1,'2026-06-07 21:30:01','2026-06-07 21:30:01'),(17,201,NULL,0,'A Wimp’s Strategy Guide to Conquer the Tower',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'A wimpy, safety-first, and cautious ordinary man climbs the tower.',0,0,0,NULL,0,'/images/articles/novelight/covers/a-wimps-strategy-guide-to-conquer-the-tower-3f2336569f.jpg',NULL,NULL,NULL,3982,0.0,0,1,'2026-06-07 21:30:02','2026-06-07 21:30:02'),(18,201,NULL,0,'A Witch Lives in Geppetto’s Doll Workshop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'“Seducing the so called witch and bringing her as a partner to the New Year’s gala.”\n\nFor Edgar de Grace, dazzlingly handsome, silver tongued, gentle and gentlemanly to all, what bet could be easier? All the more because the target was Angela Faber, the dollmaker nicknamed “witch” who already nursed a quiet crush on him.\n\n“Angela, please… Then curse me instead. Slap me, grab me by the collar, shake me, tell me a bastard like me deserves to rot in hell. Just… hate me, if you must…”\n\nBeing used as a nobleman’s pastime was not what hurt.\n\n“How could I possibly resent Your Grace? I was the fool who believed a wooden doll could be alive. I was the one who fluttered over a counterfeit love, not even knowing I had become the stakes of a bet.”\n\nOnly the betrayal, that the man to whom she gave everything, whom she loved with all her heart, had thrown her aside, hurt as though her heart had been smashed to pieces.\n\n“Sob… no, please… The words I love you were not a lie. I am begging you, do not abandon me like this.”\n\nEven watching him cry and cling so desperately, she could only suspect that this too was another lie, another deception.\n\n“Eddy, from the moment you let me call you that, our ending was already decided.”\n\nNo matter how much he wept and repented, it was far too late to put back together Angela’s shattered heart and crumbled trust.',1,0,0,NULL,0,'/images/articles/novelight/covers/a-witch-lives-in-geppettos-doll-workshop-ab60fde237.webp','https://novelight.net/media/book/background/2025/11/09/A-Witch-Lives-in-Geppettos-Doll-Workshop.webp',NULL,NULL,8464,0.0,0,1,'2026-06-07 21:30:03','2026-06-10 21:38:31'),(19,201,NULL,0,'A Wizard’s Farming Life in Another World',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sometimes, life takes the absurd to new heights.\n\nPatrick, a burned-out office worker, dreams of retiring as a “natural recluse,” tending a garden near all the conveniences of modern life.\n\nInstead, he dies of overwork and wakes up in a world of magic and monsters—exiled to a remote island as punishment for a crime he didn’t commit.\n\nWith no choice but to survive, he juggles farming, fishing, and avoiding starvation while navigating the eccentric villagers and bizarre events plaguing the island. Armed with his meager magic and a sarcastic attitude, Patrick learns the hard way that rural life is no “romantic” dream—it’s a fucking comedy.',1,0,0,NULL,0,'/images/articles/novelight/covers/a-wizards-farming-life-in-another-world-hiswuij-9e218c26c3.jpg','https://novelight.net/media/book/background/2025/11/19/A-Wizards-Farming-Life-in-Another-World.jpg',NULL,NULL,3464,0.0,0,1,'2026-06-07 21:30:04','2026-06-07 21:30:04'),(20,201,NULL,0,'Absolute Regression',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'“Send me to the past.” That’s how the first step toward revenge began.',0,0,0,NULL,0,'/images/articles/novelight/covers/absolute-regression-389e17fd05.jpg','https://novelight.net/media/book/background/2024/11/25/Absolute-Regression.jpg',NULL,NULL,4421,0.0,0,1,'2026-06-07 21:30:04','2026-06-07 21:30:04'),(21,201,NULL,0,'Academy’s Undercover Professor (Light Novel)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'I wasn’t reborn with talent or ability, but at least my knowledge from earth allowed me to stay one step ahead in this other world.\n\nMagic exists here, and new progress was rapidly being made in science while magic stagnated in the name of tradition. Using my earthly knowledge and not bound by the traditional thinking, I was able to do things other wizards couldn’t even imagine.\n\nStill, inadvertently becoming an undercover professor for a mysterious secret society at the renowned Theon academy was never in my to-do list!',1,0,0,NULL,0,'/images/articles/novelight/covers/i-got-a-fake-job-at-the-academy-68ea1a358f.jpg','https://novelight.net/media/book/background/2025/03/21/I-got-a-fake-job-at-the-academy.jpg',NULL,NULL,8042,0.0,0,1,'2026-06-07 21:30:05','2026-06-07 21:30:05'),(22,201,NULL,0,'Accidental Baby',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Do Yihyeon is rumored to be an Alpha within his company. In reality, however, he is a mutant Omega, and a severe workaholic suffering from prosopagnosia (face blindness).\n\nExtremely indifferent to others, Do Yihyeon can’t even remember the faces of the team members he sees every day.\n\nOne day, Do Yihyeon gets blackout drunk and spends the night with a stranger. From that single mistake, he suddenly finds himself pregnant.\n\nHis surprise at the sudden news is brief.\n\nDo Yihyeon resolves to have and raise the child on his own.\n\nWhile secretly suffering from morning sickness, his superior—with whom he’s never had any interaction—suddenly starts coming on to him…\n\n“I want us to be in a relationship where we’re involved with each other, Yihyeon-ssi.”\n\n“You’re already my superior, sir.”\n\n“You like things that are pretty and handsome, don’t you, Yihyeon-ssi?”\n\n“…I do?”\n\nBetween the relentless flirting and the impenetrable wall, who will emerge as the victor?',1,0,0,NULL,0,'/images/articles/novelight/covers/accidental-baby-nwt2hfi-1dc873770c.jpg','/images/articles/novelight/backgrounds/accidental-baby-1b3b0c7d26.jpg',NULL,NULL,1982,0.0,0,1,'2026-06-07 21:30:06','2026-06-12 13:22:45'),(23,201,NULL,0,'Acidic Scent (Light Novel)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Marvin, born with the stigma of a “rut baby,” clawed his way out of misfortune to become an elite secret agent for the National Security Intelligence Bureau. But one mission ends in betrayal—and leaves him forcibly transformed into something he never chose.\n\nStripped of his old life, Marvin hides away in a quiet rural hotel, waiting for the day he can return to who he once was. His peace shatters when Jang Jinwoo, a sharp-eyed prosecutor, suddenly appears.\n\nFrom the very first moment, Jinwoo sees through Marvin’s disguise. Even without pheromones, he recognizes him for what he truly is—an omega.\n\nAnd Jinwoo doesn’t hesitate to corner him.',1,0,0,NULL,0,'/images/articles/novelight/covers/acidic-scent-2-4ab790be19.webp','https://novelight.net/media/book/background/2025/08/17/Acidic-Scent_2.webp',NULL,NULL,4658,0.0,0,1,'2026-06-07 21:30:08','2026-06-07 21:30:08'),(24,201,NULL,0,'Adopting Disaster',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Jinhyuk is a person who likes to immerse himself in the role of the Villains but there is one villain which he particularly hates,\n\nReed Adeleheights Roton, the false final boss of the game.\n\nThe one who created the Seven Disasters.\n\nThe one who due to his inferiority complex led to his own doom.\n\nThe one who turned a cute innocent girl into the monstrous First Disaster codenamed Cosmo.\n\n“If I was the Villain then I would have raised her a little better.”\n\nAnd thus God granted his wish and now he was the false final Villain Reed Adeleheights Roton, the creator of the Seven Disasters.\n\nHow different would the world turn out to be now?',1,0,0,NULL,0,'/images/articles/novelight/covers/adopting-disaster-0c48965447.jpg','https://novelight.net/media/book/background/2024/06/28/Adopting-Disaster.jpg',NULL,NULL,6818,0.0,0,1,'2026-06-07 21:30:09','2026-06-07 21:30:09'),(25,201,NULL,0,'Affinity:Chaos',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'“Grey, elemental affinity, zero” The Elder announced the result loudly\n\nOn hearing this, it was like a bolt of lightning struck Grey, he stood there dumbfounded and just stared at the Elder.\n\nShocked voices could be heard from the people and there was some which were also filled with scorn.\n\nGrey stood dazed amidst all the noises without any reactions. One word was constantly reverberating in his head, \'How?\'.\n\n\'Why, why did this happen to me?\' Grey asked himself over and over again\n\n****************\n\nUnbeknownst to Grey, something greater lies in wait in his body....\n\n***************',0,0,0,NULL,0,'/images/articles/novelight/covers/read-online-affinity-chaos-free-1bb8bd2c4d.webp','https://novelight.net/media/book/background/2024/03/18/Life_Mission_background_VTnDIOK.webp',NULL,NULL,6085,0.0,0,1,'2026-06-07 21:30:10','2026-06-07 21:30:10'),(26,201,NULL,0,'After Having Babies with My Wives in a Dream, They All Came True',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'When Lin Chuan was eighteen, he awakened the Dream-Reincarnation System—a mysterious ability that let him enter hyper-realistic dreams where time flowed differently and anything was possible. Each dream was a fully immersive life, shaped by the entries he chose.\n\nHe selected tags like:【 Villainous Demoness 】, 【 Sword Genius 】, 【 Split Personality 】—And lived through thrilling battles and intense cultivation arcs.\n\nThen he tried:【 Childhood Sweetheart 】, 【 Prestigious Family Heiress 】, 【 Loyal Confidante 】—And found himself in heart-racing romances and emotional bonds.\n\nHe experimented with:【 Morally Grey 】, 【 Interracial Forbidden Love 】, 【 Lovers Turned Rivals 】—And was swept into dangerous liaisons full of passion, betrayal, and obsession.\n\nEven tags like:【 Eternally Unrestrained 】—Made him the peerless emperor who walked a lonely path, slaying demons with one sword, yet still surrounded by comrades, soulmates, and a tender daughter of jade and pearl.\n\nIn reality, Lin Chuan was just a quiet student. In dreams, he was a legend.\n\nBut everything changed when one of the dream heroines appeared in the real world—with their child in her arms.\n\nNow, the cold beauty from his fantasy stands at his door, calling him husband. Their daughter calls him dad. And soon, more women start appearing—each from a different dream.\n\nAs dreams bleed into reality, Lin Chuan gulps.What if every dream lover... actually shows up in real life?',1,0,0,NULL,0,'/images/articles/novelight/covers/after-having-babies-with-my-wives-in-a-dream-they-all-came-true-e1438756a3.webp','https://novelight.net/media/book/background/2025/07/31/After_Having_Babies_with_My_Wives_in_a_Dream_They_All_Came_True.webp',NULL,NULL,1156,0.0,0,1,'2026-06-07 21:30:12','2026-06-07 21:30:12'),(27,201,NULL,0,'After Leaving the A-Rank Party, I Aim for the Deep Part of the Labyrinth With My Former Students (Light Novel)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Red Mage Yuki left the A-rank party “Thunder Pike” without a word after being a member for 5 years.\n\nAfter years of being insulted and called useless, he finally lost his patience.\n\nAs he headed to the Adventurer’s Guild to look for a new party, he met his former student Marina.\n\nShe invited Yuki to join her new fledgling party which had only girl members.\n\nWhile capturing the dungeon, Yuki’s true ability was revealed. In fact, his magic and skills were non-standard!\n\nA fantasy adventure where the non-standard hero aims for a happy ending starts here!',0,0,0,NULL,0,'/images/articles/novelight/covers/after-leaving-the-arank-party-i-aim-for-the-deep-part-of-the-laby-kay4ghx-9a711ad36f.jpg','https://novelight.net/media/book/background/2025/01/14/After-Leaving-the-ARank-Party-I-Aim-for-the-Deep-Part-of-the-_KHa4YNO.jpg',NULL,NULL,204,0.0,0,1,'2026-06-07 21:30:12','2026-06-07 21:30:12'),(28,201,NULL,0,'After Rebirth, The Real Young Master Began to Maintain His Health',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'As a real young master of a wealthy family who was taken away by mistake, Chen Mo has never understood why it was him who was lost outside for seventeen years, and everyone still liked the fake young master Yang Shule, so he fought hard to fight, to grab, and to rob. In the end, his parents hated him, he was abandoned by his relatives and friends, and he died unexpectedly.\n\nSo after rebirth, Chen Mo thought it over.\n\nLaughing makes you ten years younger, and going to bed early can help you live till old age.\n\nNot long after returning home, his biological parents asked him: “Chen Mo, do you think your brother… Can he still live with us now?” Chen Mo said sincerely: “As long as you are happy.”\n\nAunts and uncles praised the fake young master during festivals. Chen Mo drank the wolfberry and red dates mixed soup and nodded repeatedly: “Yes, you have good taste.” The people around him openly and secretly compared the two of them, mocking him for not being worthy of the identity of a real young master of a wealthy family. Chen Mo slept soundly while soaking his feet in medicinal water: “Isn’t this a fact? Just keep talking about it, you can even go out on the streets with a loudspeaker.”\n\nOthers: “…”\n\nLater, people found out that this real young master picked up by a wealthy family is best at three things.\n\nEating, sleeping, and being gay.\n\nNot only is he gay, he also dumped the excellent student in his grade, who was the childhood sweetheart of the fake young master. Chen Mo felt extremely wronged. Xi Siyan, the cold-faced devil, didn’t like him in his previous life. How did these people came to think that he dumped him.\n\n“How about I explain it for you?” Chen Mo tried one day.\n\nThe person leaning against the wall looked down at him and raised his eyebrows: “What do you want to explain?”\n\n“You, Xi Siyan, will have nothing to do with me, Chen Mo, in this life, the next life, and another next life.”\n\nThe person in front of him kissed him with his hands in his pockets, and said coldly: “Now I do.”\n\nChen Mo was shocked; Xi Siyan! You dog forced me !',1,0,0,NULL,0,'/images/articles/novelight/covers/after-rebirth-the-real-young-master-began-to-maintain-his-health-b0f8f4b90a.jpg','https://novelight.net/media/book/background/2024/10/18/After-Rebirth-The-Real-Young-Master-Began-to-Maintain-His-Health.jpg',NULL,NULL,1631,0.0,0,1,'2026-06-07 21:30:13','2026-06-07 21:30:13'),(29,201,NULL,0,'After the 99th Confession , The Cold School Beauty’s Personality Collapsed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'From the day Qin Luo acquired the system, he set his sights on the aloof school beauty.\n\nThe first time, Qin Luo brought milk tea to confess his feelings and was rejected.\n\nThe 12th time, Qin Luo brought breakfast to confess his feelings and was rejected.\n\nThe 48th time, Qin Luo brought roses to confess his feelings and was rejected.\n\nThe 99th time, Qin Luo stood outside the dormitory loudly confessing his feelings and was rejected.\n\nInside the girls’ dormitory, the school beauty waited and waited, but Qin Luo’s 100th confession never came.\n\nShe took the initiative to find Qin Luo and asked, “Why didn’t you come to confess?”\n\nQin Luo responded, “Miss, do we know each other?”\n\nThe school beauty: “???”\n\nThe next day, the school beauty appeared holding milk tea.\n\nClassmates exclaimed, “She broke character! The aloof school beauty broke character!”',0,0,0,NULL,0,'/images/articles/novelight/covers/after-the-th-confession-the-cold-school-beautys-personality-collapsed-74c8a7dee9.jpg','https://novelight.net/media/book/background/2024/09/26/After-the-th-Confession-The-Cold-School-Beautys-Personality-Collapsed.jpg',NULL,NULL,8522,0.0,0,1,'2026-06-07 21:30:14','2026-06-07 21:30:14'),(30,201,NULL,0,'After the Secrets of the Passerby Were Leaked, He Was Cherished by the Entire Family of Antagonists',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Contemporary college student Ye Leyao died suddenly from staying up late, and found himself transported into a world where several novels merged together, becoming the useless adopted son of the prestigious Huo family.\r\n\r\nThe good news is that, apart from him, everyone else in the family is a big shot. Eldest Brother Huo is a legendary figure in the business world, Second Brother Huo is a top actor in the entertainment industry, and Third Brother Huo is a skilled esports player and boss.\r\n\r\nThe bad news is, these big shots are all antagonists, and none of them have good endings.\r\n\r\nEven worse news is that, upon waking up, he finds himself in the middle of a cheap romance involving Second Brother, who is oblivious to the fact that the child in his lover’s belly isn’t his seed at all!\r\n\r\nYe Leyao couldn’t help but scream inwardly: “Aaaaaahhhh—seriously? This romance-idiot still doesn’t know the child in his lover’s belly isn’t his?!”\r\n\r\nAll eyes in the family suddenly turn towards him. The second brother even stumbles.\r\n\r\nEveryone: What?!\r\n\r\nThe top-tier Huo family adopted a young troublemaker some years ago.\r\n\r\nInitially, nobody in the family paid him any mind. That is, until they could all hear Ye Leyao’s inner thoughts—\r\n\r\nJust as Father Huo brings his down-and-out friend home. Ye Leyao’s inner voice: “Oh, so this is the little seductress trying to seduce Father Huo, plotting to make Mother Huo and Father Huo divorce, and wrecking the Huo family?”\r\n\r\nFather Huo’s pupils dilate: “!” That night, before Ye Leyao can subtly hint to Mother Huo, the little seductress is personally “thrown” out by Father Huo.\r\n\r\nDuring breakfast at home, Eldest Brother Huo takes a video call discussing crucial shipment matters with his assistant.\r\n\r\nYe Leyao perks up his ears, muttering to himself: “Why do I vaguely remember a typhoon changing course to pass through this route in a few days? Big Brother’s business deal is definitely going down.”\r\n\r\nEldest Brother Huo: “…” He immediately changes the shipping route with his assistant. Sure enough, five days later, news came that the original route was hit by a typhoon.\r\n\r\nAfterwards, Eldest Brother Huo transfers five million into Ye Leyao’s account. Ye Leyao is astonished. Eldest Brother Huo tries to remain composed, saying calmly, “Take it, you’ve earned it.”\r\n\r\nThird Brother Huo isn’t home often. After the league ends, he brings his newly recruited team members home for dinner. Just as they enter the house, Ye Leyao stares keenly at his new teammates.\r\n\r\nThird Brother Huo is about to warn Ye Leyao against premature romance, when he hears Ye Leyao whispering in his mind: “They’re handsome alright, but unfortunately, they’re moles sent by the rival team.”\r\n\r\nThird Brother Huo: “!!!” That night, Third Brother Huo begins investigating and not only discovers that the new teammates are moles from the rival team, but also finds out that his most trusted assistant has been secretly gathering data on their team!\r\n\r\nA week later, another ten million appeared in Ye Leyao’s account.\r\n\r\nYe Leyao, holding the money happily: “Third Brother, you’re more generous than Big Brother!”\r\n\r\nJust then, Eldest Brother Huo passes by: “…”\r\n\r\nAs a supporting character in the novel, Ye Leyao’s biggest dream is to save up money and flee with his family of antagonists when they hit rock bottom. Little did he expect that all these villains in his family would not only avoid disaster but thrive in their careers, and he would end up soaring with them.',1,0,0,5,10,'/images/articles/novelight/covers/after-the-secrets-of-the-passerby-72a942d6df.webp','https://novelight.net/media/book/background/2024/10/03/After-the-secrets-of-the-passerby.webp',NULL,NULL,7268,0.0,0,1,'2026-06-07 21:30:15','2026-06-09 18:59:11');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles_authors`
--

DROP TABLE IF EXISTS `articles_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles_authors` (
  `article_id` bigint unsigned NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`article_id`,`author_id`),
  KEY `articles_authors_author_id_foreign` (`author_id`),
  CONSTRAINT `articles_authors_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `articles_authors_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles_authors`
--

LOCK TABLES `articles_authors` WRITE;
/*!40000 ALTER TABLE `articles_authors` DISABLE KEYS */;
INSERT INTO `articles_authors` VALUES (1,1),(3,1),(4,1),(7,1),(9,1),(11,1),(12,1),(17,1),(24,1),(28,1),(29,1),(2,2),(6,2),(21,2),(5,3),(8,4),(10,4),(16,4),(13,5),(14,5),(19,5),(20,5),(22,5),(23,5),(15,6),(18,6),(27,6),(29,6),(30,6),(17,7),(25,8),(26,9);
/*!40000 ALTER TABLE `articles_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles_genres`
--

DROP TABLE IF EXISTS `articles_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles_genres` (
  `article_id` bigint unsigned NOT NULL,
  `genre_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`article_id`,`genre_id`),
  KEY `articles_genres_genre_id_foreign` (`genre_id`),
  CONSTRAINT `articles_genres_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `articles_genres_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles_genres`
--

LOCK TABLES `articles_genres` WRITE;
/*!40000 ALTER TABLE `articles_genres` DISABLE KEYS */;
INSERT INTO `articles_genres` VALUES (1,1),(2,1),(3,1),(5,1),(6,1),(7,1),(8,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(21,1),(22,1),(24,1),(25,1),(27,1),(30,1),(1,2),(2,2),(3,2),(6,2),(7,2),(10,2),(13,2),(14,2),(19,2),(21,2),(22,2),(24,2),(25,2),(26,2),(27,2),(28,2),(30,2),(1,3),(3,3),(4,3),(5,3),(8,3),(9,3),(10,3),(12,3),(14,3),(17,3),(20,3),(21,3),(23,3),(24,3),(25,3),(26,3),(27,3),(2,4),(4,4),(5,4),(6,4),(7,4),(9,4),(11,4),(13,4),(14,4),(15,4),(16,4),(18,4),(22,4),(26,4),(27,4),(28,4),(29,4),(30,4),(3,5),(5,5),(10,5),(12,5),(13,5),(17,5),(19,5),(21,5),(24,5),(25,5),(27,5),(4,6),(6,6),(15,6),(19,6),(4,7),(21,7),(4,8),(5,9),(7,9),(10,9),(18,9),(21,9),(24,9),(5,10),(13,10),(16,10),(21,10),(24,10),(5,11),(9,11),(11,11),(14,11),(15,11),(18,11),(21,11),(23,11),(24,11),(27,11),(28,11),(29,11),(30,11),(5,12),(6,12),(9,12),(15,12),(16,12),(18,12),(28,12),(5,13),(6,13),(9,13),(15,13),(22,13),(6,14),(16,14),(18,14),(22,14),(23,14),(6,15),(10,15),(15,15),(21,15),(26,15),(27,15),(8,16),(9,16),(8,17),(13,18),(14,19),(28,19),(15,20),(20,21),(20,22),(27,23),(27,24);
/*!40000 ALTER TABLE `articles_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authors_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'solee_79',NULL),(2,'kenga',NULL),(3,'MiniMushroomie',NULL),(4,'KimSU',NULL),(5,'SataBog',NULL),(6,'Santos',NULL),(7,'Diver',NULL),(8,'Sejong',NULL),(9,'innOK',NULL);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_users`
--

DROP TABLE IF EXISTS `banned_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banned_users` (
  `user_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint unsigned NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `banned_users_admin_id_foreign` (`admin_id`),
  CONSTRAINT `banned_users_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `banned_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned_users`
--

LOCK TABLES `banned_users` WRITE;
/*!40000 ALTER TABLE `banned_users` DISABLE KEYS */;
INSERT INTO `banned_users` VALUES (292,299,'gà','2024-07-28 14:54:06','2024-04-20 14:54:06','2024-04-20 14:54:06'),(295,299,'gà','2024-04-25 14:45:08','2024-04-20 14:45:08','2024-04-20 14:45:08'),(298,299,'aaaaa','2024-04-20 14:44:17','2024-04-20 14:44:17','2024-04-20 14:44:17'),(300,299,'fsaf','2024-04-22 13:03:30','2024-04-22 13:03:30','2024-04-22 13:03:30');
/*!40000 ALTER TABLE `banned_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'reading',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookmarks_user_id_name_unique` (`user_id`,`name`),
  KEY `bookmarks_article_id_foreign` (`article_id`),
  CONSTRAINT `bookmarks_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookmarks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarks`
--

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
INSERT INTO `bookmarks` VALUES (2,201,1,'reading','0.0000001% Demon King',NULL,1,'2026-06-14 14:07:10','2026-06-14 14:07:10'),(3,201,2,'completed','12 O’Clock Marionette',NULL,1,'2026-06-14 14:07:10','2026-06-14 14:07:10');
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_likes`
--

DROP TABLE IF EXISTS `chapter_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `chapter_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chapter_likes_user_id_chapter_id_unique` (`user_id`,`chapter_id`),
  KEY `chapter_likes_chapter_id_foreign` (`chapter_id`),
  CONSTRAINT `chapter_likes_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_likes`
--

LOCK TABLES `chapter_likes` WRITE;
/*!40000 ALTER TABLE `chapter_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_paragraph_bookmarks`
--

DROP TABLE IF EXISTS `chapter_paragraph_bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_paragraph_bookmarks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `chapter_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `paragraph` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chapter_paragraph_bookmarks_user_id_chapter_id_unique` (`user_id`,`chapter_id`),
  KEY `chapter_paragraph_bookmarks_chapter_id_foreign` (`chapter_id`),
  KEY `chapter_paragraph_bookmarks_article_id_foreign` (`article_id`),
  CONSTRAINT `chapter_paragraph_bookmarks_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_paragraph_bookmarks_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_paragraph_bookmarks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_paragraph_bookmarks`
--

LOCK TABLES `chapter_paragraph_bookmarks` WRITE;
/*!40000 ALTER TABLE `chapter_paragraph_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter_paragraph_bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_reports`
--

DROP TABLE IF EXISTS `chapter_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chapter_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `resolved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chapter_reports_chapter_id_foreign` (`chapter_id`),
  KEY `chapter_reports_article_id_foreign` (`article_id`),
  KEY `chapter_reports_user_id_foreign` (`user_id`),
  CONSTRAINT `chapter_reports_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_reports_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_reports`
--

LOCK TABLES `chapter_reports` WRITE;
/*!40000 ALTER TABLE `chapter_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_unlocks`
--

DROP TABLE IF EXISTS `chapter_unlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_unlocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `chapter_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `credits_spent` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chapter_unlocks_user_id_chapter_id_unique` (`user_id`,`chapter_id`),
  KEY `chapter_unlocks_chapter_id_foreign` (`chapter_id`),
  CONSTRAINT `chapter_unlocks_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chapter_unlocks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_unlocks`
--

LOCK TABLES `chapter_unlocks` WRITE;
/*!40000 ALTER TABLE `chapter_unlocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter_unlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapters`
--

DROP TABLE IF EXISTS `chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `number` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `notified_at` timestamp NULL DEFAULT NULL,
  `view` int NOT NULL DEFAULT '0',
  `credit_cost` smallint unsigned DEFAULT NULL,
  `article_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chapters_number_article_id_unique` (`number`,`article_id`),
  KEY `chapters_article_id_foreign` (`article_id`),
  KEY `chapters_published_at_index` (`published_at`),
  CONSTRAINT `chapters_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=300 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapters`
--

LOCK TABLES `chapters` WRITE;
/*!40000 ALTER TABLE `chapters` DISABLE KEYS */;
INSERT INTO `chapters` VALUES (1,1,'Prologue (Part 1)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16877',NULL,'2026-06-15 23:24:40',563,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(2,2,'Prologue (Part 2)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16878',NULL,'2026-06-15 23:24:40',1117,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(3,3,'Demon King (1) (Part 1)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16879',NULL,'2026-06-15 23:24:40',679,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(4,4,'Demon King (1) (Part 2)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16880',NULL,'2026-06-15 23:24:40',853,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(5,5,'Demon King (2) (Part 1)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16881',NULL,'2026-06-15 23:24:40',199,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(6,6,'Demon King (2) (Part 2)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16882',NULL,'2026-06-15 23:24:40',140,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(7,7,'Demon King (3) (Part 1)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16883',NULL,'2026-06-15 23:24:40',528,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(8,8,'Demon King (3) (Part 2)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16884',NULL,'2026-06-15 23:24:40',400,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(9,9,'Demon King (4) (Part 1)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16885',NULL,'2026-06-15 23:24:40',258,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(10,10,'Demon King (4) (Part 2)\nsolee_79\n25.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16886',NULL,'2026-06-15 23:24:40',93,NULL,1,'2026-06-07 21:29:45','2026-06-15 23:24:40'),(11,1,'113 chapter\nkenga\n05.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 206676',NULL,'2026-06-15 23:24:40',925,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(12,2,'114 chapter\nkenga\n06.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 206839',NULL,'2026-06-15 23:24:40',953,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(13,3,'115 chapter\nkenga\n06.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 206841',NULL,'2026-06-15 23:24:40',177,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(14,4,'116 chapter\nkenga\n06.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 206844',NULL,'2026-06-15 23:24:40',131,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(15,5,'117 chapter\nkenga\n07.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207098',NULL,'2026-06-15 23:24:40',1047,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(16,6,'118 chapter\nkenga\n07.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207099',NULL,'2026-06-15 23:24:40',1089,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(17,7,'119 chapter\nkenga\n07.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207100',NULL,'2026-06-15 23:24:40',1106,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(18,8,'120 chapter\nkenga\n08.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207246',NULL,'2026-06-15 23:24:40',50,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(19,9,'121 chapter\nkenga\n08.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207247',NULL,'2026-06-15 23:24:40',800,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(20,10,'122 chapter\nkenga\n08.03.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 207248',NULL,'2026-06-15 23:24:40',674,NULL,2,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(21,1,'Chapter 236\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151281',NULL,'2026-06-15 23:24:40',272,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(22,2,'Chapter 237\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151282',NULL,'2026-06-15 23:24:40',923,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(23,3,'Chapter 238\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151283',NULL,'2026-06-15 23:24:40',859,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(24,4,'Chapter 239\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151284',NULL,'2026-06-15 23:24:40',952,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(25,5,'Chapter 240\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151285',NULL,'2026-06-15 23:24:40',817,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(26,6,'Chapter 241\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151608',NULL,'2026-06-15 23:24:40',131,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(27,7,'Chapter 242\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151609',NULL,'2026-06-15 23:24:40',403,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(28,8,'Chapter 243\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151610',NULL,'2026-06-15 23:24:40',947,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(29,9,'Chapter 244\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151611',NULL,'2026-06-15 23:24:40',75,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(30,10,'Chapter 245\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151612',NULL,'2026-06-15 23:24:40',802,NULL,3,'2026-06-07 21:29:46','2026-06-15 23:24:40'),(31,1,'1 vol. 0 chapter - Prologue. Crimson Poppies on the Battlefield\nsolee_79\n19.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 6683',NULL,'2026-06-15 23:24:40',392,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(32,2,'2 vol. 0 chapter - Prologue\nsolee_79\n27.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 76713',NULL,'2026-06-15 23:24:40',541,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(33,3,'3 vol. 0 chapter - Memoirs\nsolee_79\n27.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 76721',NULL,'2026-06-15 23:24:40',263,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(34,4,'4 vol. 1 chapter - Synopsis\nsolee_79\n17.11.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 181694',NULL,'2026-06-15 23:24:40',729,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(35,5,'1 vol. 1 chapter - On the battlefield, there are no dead.\nsolee_79\n20.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 6684',NULL,'2026-06-15 23:24:40',105,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(36,6,'2 vol. 1 chapter - Chapter 1\nsolee_79\n27.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 76714',NULL,'2026-06-15 23:24:40',768,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(37,7,'3 vol. 1 chapter - An interlude. Get out your weapon\nsolee_79\n27.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 76722',NULL,'2026-06-15 23:24:40',656,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(38,8,'4 vol. 2 chapter - Prologue: Missing in Action\nsolee_79\n17.11.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 181696',NULL,'2026-06-15 23:24:40',1163,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(39,9,'2 vol. 2 chapter - Chapter 2\nsolee_79\n27.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 76715',NULL,'2026-06-15 23:24:40',473,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(40,10,'1 vol. 2 chapter - On the Eastern Front Without Change\nsolee_79\n20.03.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 8105',NULL,'2026-06-15 23:24:40',394,NULL,4,'2026-06-07 21:29:47','2026-06-15 23:24:40'),(41,1,'1 chapter\nMiniMushroomie\n26.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 264467',NULL,'2026-06-15 23:24:40',1160,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(42,2,'2 chapter\nMiniMushroomie\n26.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 264472',NULL,'2026-06-15 23:24:40',357,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(43,3,'3 chapter\nMiniMushroomie\n26.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 264475',NULL,'2026-06-15 23:24:40',787,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(44,4,'4 chapter\nMiniMushroomie\n27.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 264593',NULL,'2026-06-15 23:24:40',906,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(45,5,'5 chapter\nMiniMushroomie\n06.11.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 267037',NULL,'2026-06-15 23:24:40',627,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(46,6,'6 chapter\nMiniMushroomie\n06.11.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 267049',NULL,'2026-06-15 23:24:40',118,NULL,5,'2026-06-07 21:29:49','2026-06-15 23:24:40'),(47,1,'84 chapter\nkenga\n26.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286010',NULL,'2026-06-15 23:24:40',522,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(48,2,'85 chapter\nkenga\n27.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286155',NULL,'2026-06-15 23:24:40',1132,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(49,3,'86 chapter\nkenga\n27.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286214',NULL,'2026-06-15 23:24:40',1166,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(50,4,'87 chapter\nkenga\n27.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286215',NULL,'2026-06-15 23:24:40',75,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(51,5,'88 chapter\nkenga\n28.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286479',NULL,'2026-06-15 23:24:40',766,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(52,6,'89 chapter\nkenga\n28.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286480',NULL,'2026-06-15 23:24:40',864,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(53,7,'90 chapter\nkenga\n28.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286482',NULL,'2026-06-15 23:24:40',1134,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(54,8,'91 chapter\nkenga\n29.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286587',NULL,'2026-06-15 23:24:40',138,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(55,9,'92 chapter\nkenga\n29.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286589',NULL,'2026-06-15 23:24:40',247,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(56,10,'93 chapter\nkenga\n29.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 286591',NULL,'2026-06-15 23:24:40',1017,NULL,6,'2026-06-07 21:29:50','2026-06-15 23:24:40'),(57,1,'264 chapter\nsolee_79\n29.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298267',NULL,'2026-06-15 23:24:40',468,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(58,2,'265 chapter\nsolee_79\n31.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298615',NULL,'2026-06-15 23:24:40',244,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(59,3,'The Numbers Seen Through the System\nsolee_79\n02.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298815',NULL,'2026-06-15 23:24:40',372,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(60,4,'267 chapter\nsolee_79\n02.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298816',NULL,'2026-06-15 23:24:40',905,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(61,5,'268 chapter\nsolee_79\n03.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299047',NULL,'2026-06-15 23:24:40',958,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(62,6,'The End of the Eva Church Followers\nsolee_79\n04.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299360',NULL,'2026-06-15 23:24:40',116,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(63,7,'270 chapter\nsolee_79\n06.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299657',NULL,'2026-06-15 23:24:40',1152,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(64,8,'271 chapter\nsolee_79\n08.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299976',NULL,'2026-06-15 23:24:40',768,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(65,9,'272 chapter\nsolee_79\n10.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 300514',NULL,'2026-06-15 23:24:40',990,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(66,10,'Spring Has Come\nsolee_79\n11.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 300647',NULL,'2026-06-15 23:24:40',475,NULL,7,'2026-06-07 21:29:51','2026-06-15 23:24:40'),(67,1,'Rather Better\nKimSU\n25.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 297411',NULL,'2026-06-15 23:24:40',377,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(68,2,'See Everything as Swordsmanship\nKimSU\n26.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 297584',NULL,'2026-06-15 23:24:40',1099,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(69,3,'Connivance\nKimSU\n29.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298215',NULL,'2026-06-15 23:24:40',392,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(70,4,'Me, Fooled?\nKimSU\n30.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298489',NULL,'2026-06-15 23:24:40',168,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(71,5,'Master Eudokia\nKimSU\n31.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298579',NULL,'2026-06-15 23:24:40',926,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(72,6,'Because He Loved It, He Wanted To Be Good At it, And Now That He Was Good at it\nKimSU\n01.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298744',NULL,'2026-06-15 23:24:40',1150,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(73,7,'Zaiden\nKimSU\n02.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 298933',NULL,'2026-06-15 23:24:40',1016,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(74,8,'Spell Butcher\nKimSU\n05.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299521',NULL,'2026-06-15 23:24:40',420,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(75,9,'That Madman Is on Our Side\nKimSU\n06.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299660',NULL,'2026-06-15 23:24:40',912,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(76,10,'In Border Guard, Too\nKimSU\n07.04.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 299863',NULL,'2026-06-15 23:24:40',845,NULL,8,'2026-06-07 21:29:52','2026-06-15 23:24:40'),(77,1,'Tropical Cyclone\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310017',NULL,'2026-06-15 23:24:40',1015,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(78,2,'Pennywort and Rehmannia Tea\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310022',NULL,'2026-06-15 23:24:40',160,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(79,3,'A Lotus Petal from the Millennium\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310030',NULL,'2026-06-15 23:24:40',148,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(80,4,'Keats\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310347',NULL,'2026-06-15 23:24:40',585,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(81,5,'High Mountain, Low Valley\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310351',NULL,'2026-06-15 23:24:40',501,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(82,6,'Do Your Best, Keep a Calm Heart\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310352',NULL,'2026-06-15 23:24:40',1095,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(83,7,'Warm Yet Stern, Commanding Yet Not Fierce\nsolee_79\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310624',NULL,'2026-06-15 23:24:40',673,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(84,8,'Sunset Speed Run\nsolee_79\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310625',NULL,'2026-06-15 23:24:40',222,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(85,9,'Romeo and Juliet\nsolee_79\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310626',NULL,'2026-06-15 23:24:40',283,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(86,10,'A Rose Meets a Tiger\nsolee_79\n21.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310836',NULL,'2026-06-15 23:24:40',1140,NULL,9,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(87,1,'Companion (2)\nKimSU\n12.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223626',NULL,'2026-06-15 23:24:40',845,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(88,2,'Companion (3)\nKimSU\n12.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223627',NULL,'2026-06-15 23:24:40',439,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(89,3,'Companion (4)\nKimSU\n13.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223813',NULL,'2026-06-15 23:24:40',137,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(90,4,'Standoff\nKimSU\n13.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223815',NULL,'2026-06-15 23:24:40',732,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(91,5,'Standoff (2)\nKimSU\n13.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223816',NULL,'2026-06-15 23:24:40',547,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(92,6,'The Nest\nKimSU\n13.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223817',NULL,'2026-06-15 23:24:40',987,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(93,7,'The Nest (2)\nKimSU\n13.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 223818',NULL,'2026-06-15 23:24:40',1062,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(94,8,'The Nest (3)\nKimSU\n14.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224008',NULL,'2026-06-15 23:24:40',958,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(95,9,'Underground\nKimSU\n14.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224009',NULL,'2026-06-15 23:24:40',268,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(96,10,'Desperate Situation\nKimSU\n14.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224011',NULL,'2026-06-15 23:24:40',1157,NULL,10,'2026-06-07 21:29:53','2026-06-15 23:24:40'),(97,1,'Chapter 250\nsolee_79\n06.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 146368',NULL,'2026-06-15 23:24:40',1195,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(98,2,'Chapter 251\nsolee_79\n06.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 146369',NULL,'2026-06-15 23:24:40',1024,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(99,3,'Chapter 252\nsolee_79\n16.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148113',NULL,'2026-06-15 23:24:40',1009,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(100,4,'Chapter 253\nsolee_79\n16.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148114',NULL,'2026-06-15 23:24:40',224,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(101,5,'Chapter 254\nsolee_79\n16.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148115',NULL,'2026-06-15 23:24:40',446,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(102,6,'Chapter 255\nsolee_79\n16.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148116',NULL,'2026-06-15 23:24:40',394,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(103,7,'Chapter 256\nsolee_79\n16.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148117',NULL,'2026-06-15 23:24:40',557,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(104,8,'Chapter 257\nsolee_79\n21.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148676',NULL,'2026-06-15 23:24:40',467,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(105,9,'Chapter 258\nsolee_79\n21.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148677',NULL,'2026-06-15 23:24:40',849,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(106,10,'Chapter 259\nsolee_79\n21.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 148678',NULL,'2026-06-15 23:24:40',631,NULL,11,'2026-06-07 21:29:54','2026-06-15 23:24:40'),(107,1,'7 vol. 19 chapter - Vivienne’s Plan (Redux)\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81034',NULL,'2026-06-15 23:24:40',513,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(108,2,'7 vol. 20 chapter - Malicia’s Plan\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81035',NULL,'2026-06-15 23:24:40',192,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(109,3,'7 vol. 21 chapter - Amadeus’ Plan\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81036',NULL,'2026-06-15 23:24:40',1071,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(110,4,'7 vol. 22 chapter - Advent\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81037',NULL,'2026-06-15 23:24:40',784,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(111,5,'7 vol. 23 chapter - Sung; Singer\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81038',NULL,'2026-06-15 23:24:40',154,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(112,6,'7 vol. 24 chapter - Bequeathal\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81039',NULL,'2026-06-15 23:24:40',151,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(113,7,'7 vol. 25 chapter - Fool\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81040',NULL,'2026-06-15 23:24:40',856,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(114,8,'7 vol. 26 chapter - Singer; Sung\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81041',NULL,'2026-06-15 23:24:40',767,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(115,9,'7 vol. 27 chapter - Recoil\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81042',NULL,'2026-06-15 23:24:40',1159,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(116,10,'7 vol. 28 chapter - Grieved\nsolee_79\n30.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 81043',NULL,'2026-06-15 23:24:40',610,NULL,12,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(117,1,'266 chapter\nSataBog\n18.05.2026','\"Test subjects...?\"\n\nWhen Tie repeated the words, the child across from her froze.\n\nA faint mixture of confusion and curiosity immediately appeared in his eyes.\n\n\"You’re not test subjects?\"\n\nAfter thinking for a moment, Tie stepped forward.\n\nThen she turned sideways and showed him the mercenary badge hidden beneath her cloak.\n\n\"Yep! We’re mercenaries.\"',NULL,'2026-06-15 23:24:40',238,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(118,2,'267 chapter\nSataBog\n18.05.2026','Tick-tock. Tick-tock.\n\nThe ticking of the second hand echoed through the room.\n\nThe fresh morning breeze stirred the curtains inside the pilgrims’ quarters.\n\n\'...What in the world.\'\n\nMel, a cardinal of the order and one of Luciano’s subordinates, frowned deeply.\n\nHis gaze was fixed on the unbelievable scene unfolding right before his eyes.\n\n\"Uwaaaaaah, I don’t wannaaaa! Tie hates this!\"',NULL,'2026-06-15 23:24:40',182,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(119,3,'268 chapter\nSataBog\n19.05.2026','Neither Tie nor Lucarion knew the drug’s exact nature.\n\nThey could only roughly guess at its effects.\n\n\"Tie thinks it’s definitely medicine that makes everybody obedient!\"\n\n\"Obedient...?\"\n\n\"Yeah! So even if somebody does bad things to you, you can’t say you hate it anymore. Eloa said it too. If you drink that medicine, your head starts feeling weird.\"\n\n\"That makes sense.\"\n\nBasto nodded.',NULL,'2026-06-15 23:24:40',969,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(120,4,'269 chapter\nSataBog\n19.05.2026','Bale lowered the piece of meat in his hand.\n\n\"Haaah, this brat’s doing it again.\"\n\n\"Hmm...\"\n\nWith a heavy sigh, Basto became the second one to enter the battlefield.\n\n\"Tie. Just one bite. Really, just try one bite. It’s good, okay?\"\n\nTie still did not move.\n\nBut after the silence stretched on, the child secretly cracked one eye open.',NULL,'2026-06-15 23:24:40',444,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(121,5,'270 chapter\nSataBog\n19.05.2026','\"So basically.\"\n\nEloa only spoke again after eating five whole pieces of the jerky Tie had given her.\n\n\"You came back here to steal that strange powder from the storage room?\"\n\n\"Mhm!\"\n\nTie nodded.\n\nThe faint glow of the sealing stone embedded in the wall reflected in Eloa’s eyes.\n\n\"...That’s stupid.\"',NULL,'2026-06-15 23:24:40',1015,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(122,6,'271 chapter\nSataBog\n20.05.2026','Tie’s tightly clenched fists trembled.\n\n\"People who awaken both holy power and magic at the same time? Rare. Out of everyone I know, only Tie and Tesetan.\"\n\n\"The little one’s an exception since she inherited the World Tree’s power. But the vice squad leader just got lucky. Can someone really be born like that?\"\n\n\"Who knows. I don’t know if there’s anyone else like me. And even if there is, they probably wouldn’t show it. People say awakening two powers at once is a bad omen.\"\n\nThe voices she had heard during the journey echoed through her mind.\n\n\"Aunt Ribia, why can’t Tie heal people? Tie has holy power now. She can heal!\"\n\n\"Mm, well... Ah, young miss. There are things like that. Things people think are better kept hidden.\"',NULL,'2026-06-15 23:24:40',1199,NULL,13,'2026-06-07 21:29:55','2026-06-15 23:24:40'),(123,7,'272 chapter\nSataBog\n20.05.2026','Tie forgot even to blink as she stared at the door.\n\nCreak—\n\nThe floorboards beyond it groaned softly.\n\nHer right hand instinctively clutched at the collar of her clothes.\n\nShe could feel cold sweat gathering in her palm.\n\n‘Priests?’\n\nThey said priests checked the Pilgrimage Corps building two or three times a day.',NULL,'2026-06-15 23:24:40',293,NULL,13,'2026-06-07 21:29:56','2026-06-15 23:24:40'),(124,8,'273 chapter\nSataBog\n20.05.2026','Nordix spoke.\n\n“Do you know what this medicine, Silencium, is made from?”\n\nSilence settled over the room.\n\nNordix carefully took the bottle from Tie and examined it closely.\n\n“Inside are distilled leaves of the Herb of Oblivion, pollen from the Rechenera flower known as the Night Flower, and sap from the tatin tree.”\n\nHe lifted his gaze.\n\n“And naturally, all of those can only be obtained within the Rokse Forest. The materials needed to create the antidote are there as well.”',NULL,'2026-06-15 23:24:40',57,NULL,13,'2026-06-07 21:29:56','2026-06-15 23:24:40'),(125,9,'274 chapter\nSataBog\n21.05.2026','The flame frozen at the tip of the candle trembled softly.\n\nUnder the dim light, Tesetan asked in a low voice,\n\n\"Can\'t sleep?\"\n\nInstead of answering, Tie turned to the side and curled into herself.\n\nThen she buried her face against his chest.\n\n\"Yeah. Because Grandpa Nordix came…… I was just really happy.\"\n\nTesetan slowly stroked her hair.',NULL,'2026-06-15 23:24:40',174,NULL,13,'2026-06-07 21:29:56','2026-06-15 23:24:40'),(126,10,'275 chapter\nSataBog\n21.05.2026','\"Compromise?\"\n\nAfter murmuring that word, the World Tree fell briefly speechless.\n\nThe shimmering green eyes before it seemed to pierce straight through it.\n\nAstie.\n\nFar too small, far too young, an incomplete existence.\n\nAnd yet the power flowing through the child’s heart was strong and frighteningly clear.\n\n‘Because this is mine.’',NULL,'2026-06-15 23:24:40',966,NULL,13,'2026-06-07 21:29:56','2026-06-15 23:24:40'),(127,1,'501 chapter\nSataBog\n20.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232455',NULL,'2026-06-15 23:24:40',84,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(128,2,'502 chapter\nSataBog\n20.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232456',NULL,'2026-06-15 23:24:40',780,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(129,3,'503 chapter\nSataBog\n20.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232457',NULL,'2026-06-15 23:24:40',387,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(130,4,'504 chapter\nSataBog\n21.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232618',NULL,'2026-06-15 23:24:40',533,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(131,5,'505 chapter\nSataBog\n21.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232619',NULL,'2026-06-15 23:24:40',20,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(132,6,'506 chapter\nSataBog\n21.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232620',NULL,'2026-06-15 23:24:40',557,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(133,7,'507 chapter\nSataBog\n22.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232883',NULL,'2026-06-15 23:24:40',64,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(134,8,'508 chapter\nSataBog\n22.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232884',NULL,'2026-06-15 23:24:40',566,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(135,9,'509 chapter\nSataBog\n22.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232885',NULL,'2026-06-15 23:24:40',970,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(136,10,'510 chapter\nSataBog\n22.06.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 232886',NULL,'2026-06-15 23:24:40',357,NULL,14,'2026-06-07 21:29:57','2026-06-15 23:24:40'),(137,1,'76 chapter\nSantos\n17.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309529',NULL,'2026-06-15 23:24:40',1132,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(138,2,'77 chapter\nSantos\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309835',NULL,'2026-06-15 23:24:40',1056,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(139,3,'78 chapter\nSantos\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309836',NULL,'2026-06-15 23:24:40',1010,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(140,4,'79 chapter\nSantos\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309837',NULL,'2026-06-15 23:24:40',261,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(141,5,'80 chapter\nSantos\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309838',NULL,'2026-06-15 23:24:40',864,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(142,6,'81 chapter\nSantos\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309839',NULL,'2026-06-15 23:24:40',129,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(143,7,'82 chapter\nSantos\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310207',NULL,'2026-06-15 23:24:40',63,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(144,8,'83 chapter\nSantos\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310208',NULL,'2026-06-15 23:24:40',262,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(145,9,'84 chapter\nSantos\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310210',NULL,'2026-06-15 23:24:40',918,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(146,10,'85 chapter\nSantos\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310513',NULL,'2026-06-15 23:24:40',501,NULL,15,'2026-06-07 21:30:00','2026-06-15 23:24:40'),(147,1,'210 chapter\nKimSU\n02.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273559',NULL,'2026-06-15 23:24:40',435,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(148,2,'211 chapter\nKimSU\n04.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273889',NULL,'2026-06-15 23:24:40',182,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(149,3,'212 chapter\nKimSU\n04.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273891',NULL,'2026-06-15 23:24:40',926,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(150,4,'213 chapter\nKimSU\n04.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273892',NULL,'2026-06-15 23:24:40',378,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(151,5,'214 chapter\nKimSU\n04.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273893',NULL,'2026-06-15 23:24:40',561,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(152,6,'215 chapter\nKimSU\n04.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 273894',NULL,'2026-06-15 23:24:40',480,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(153,7,'216 chapter\nKimSU\n05.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 274134',NULL,'2026-06-15 23:24:40',509,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(154,8,'217 chapter\nKimSU\n05.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 274135',NULL,'2026-06-15 23:24:40',708,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(155,9,'218 chapter\nKimSU\n05.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 274137',NULL,'2026-06-15 23:24:40',1040,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(156,10,'219 chapter\nKimSU\n05.12.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 274136',NULL,'2026-06-15 23:24:40',438,NULL,16,'2026-06-07 21:30:01','2026-06-15 23:24:40'),(157,1,'259 chapter\nsolee_79\n24.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 311701',NULL,'2026-06-15 23:24:40',506,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(158,2,'260 chapter\nsolee_79\n24.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 311702',NULL,'2026-06-15 23:24:40',492,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(159,3,'261 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312286',NULL,'2026-06-15 23:24:40',66,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(160,4,'262 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312290',NULL,'2026-06-15 23:24:40',764,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(161,5,'263 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312291',NULL,'2026-06-15 23:24:40',1083,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(162,6,'264 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312292',NULL,'2026-06-15 23:24:40',633,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(163,7,'265 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312293',NULL,'2026-06-15 23:24:40',568,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(164,8,'266 chapter\nDiver\n26.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312294',NULL,'2026-06-15 23:24:40',347,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(165,9,'267 chapter\nDiver\n27.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312501',NULL,'2026-06-15 23:24:40',598,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(166,10,'268 chapter\nDiver\n27.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 312503',NULL,'2026-06-15 23:24:40',722,NULL,17,'2026-06-07 21:30:02','2026-06-15 23:24:40'),(167,1,'98 chapter\nSantos\n11.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 16877',NULL,'2026-06-15 23:24:40',916,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(168,2,'99 chapter\nSantos\n12.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282725',NULL,'2026-06-15 23:24:40',68,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(169,3,'100 chapter\nSantos\n12.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282728',NULL,'2026-06-15 23:24:40',800,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(170,4,'101 chapter\nSantos\n12.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282729',NULL,'2026-06-15 23:24:40',97,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(171,5,'102 chapter\nSantos\n13.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282909',NULL,'2026-06-15 23:24:40',765,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(172,6,'103 chapter\nSantos\n13.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282913',NULL,'2026-06-15 23:24:40',544,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(173,7,'104 chapter\nSantos\n13.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282915',NULL,'2026-06-15 23:24:40',83,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(174,8,'105 chapter\nSantos\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283113',NULL,'2026-06-15 23:24:40',338,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(175,9,'106 chapter\nSantos\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283114',NULL,'2026-06-15 23:24:40',1199,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(176,10,'107 chapter\nSantos\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283115',NULL,'2026-06-15 23:24:40',972,NULL,18,'2026-06-07 21:30:03','2026-06-15 23:24:40'),(177,1,'Settlement (2)\nSataBog\n01.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287166',NULL,'2026-06-15 23:24:40',339,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(178,2,'The Usefulness of Titles (1)\nSataBog\n02.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287361',NULL,'2026-06-15 23:24:40',504,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(179,3,'The Usefulness of Titles (2)\nSataBog\n02.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287362',NULL,'2026-06-15 23:24:40',122,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(180,4,'Tofu and Blasphemy (1)\nSataBog\n02.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287363',NULL,'2026-06-15 23:24:40',722,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(181,5,'Tofu and Blasphemy (2)\nSataBog\n03.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287586',NULL,'2026-06-15 23:24:40',320,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(182,6,'Goddess is watching (1)\nSataBog\n03.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287587',NULL,'2026-06-15 23:24:40',543,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(183,7,'Goddess is watching (2)\nSataBog\n03.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287588',NULL,'2026-06-15 23:24:40',856,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(184,8,'Influencer Project (1)\nSataBog\n04.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287723',NULL,'2026-06-15 23:24:40',254,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(185,9,'Influencer Project (2)\nSataBog\n04.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287722',NULL,'2026-06-15 23:24:40',1163,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(186,10,'Hotteok Plague (1)\nSataBog\n04.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 287721',NULL,'2026-06-15 23:24:40',280,NULL,19,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(187,1,'Do Not Upend the Cult Lord’s Drink Table.\nSataBog\n12.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 289130',NULL,'2026-06-15 23:24:40',506,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(188,2,'Have You Ever Asked the Cult Lord?\nSataBog\n13.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 289369',NULL,'2026-06-15 23:24:40',600,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(189,3,'It’s Time to Take Off the Mask.\nSataBog\n13.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 289368',NULL,'2026-06-15 23:24:40',1098,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(190,4,'The World Is Full of Swindlers.\nSataBog\n14.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 289613',NULL,'2026-06-15 23:24:40',1023,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(191,5,'Fishing Is Merely a Pretext to Gather Everyone.\nSataBog\n14.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 289614',NULL,'2026-06-15 23:24:40',962,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(192,6,'The Heavenly Demon Cup Fishing Tournament Begins.\nSataBog\n19.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 290567',NULL,'2026-06-15 23:24:40',387,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(193,7,'The Fate of This Martial World Rests on You.\nSataBog\n21.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 290912',NULL,'2026-06-15 23:24:40',443,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(194,8,'Have You Decided Whom to Choose?\nSataBog\n24.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 291464',NULL,'2026-06-15 23:24:40',1007,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(195,9,'You Just Killed Vile Young Demon.\nSataBog\n25.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 291664',NULL,'2026-06-15 23:24:40',905,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(196,10,'What Kind of Drunk Worries About a Hangover?\nSataBog\n26.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 291900',NULL,'2026-06-15 23:24:40',83,NULL,20,'2026-06-07 21:30:04','2026-06-15 23:24:40'),(197,1,'2 vol. 90 chapter - Side Story. Lexuror (3)\nkenga\n09.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282078',NULL,'2026-06-15 23:24:40',50,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(198,2,'2 vol. 91 chapter - Side Story. Artificial Sun (1)\nkenga\n10.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282361',NULL,'2026-06-15 23:24:40',528,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(199,3,'2 vol. 92 chapter - Side Story. Artificial Sun (2)\nkenga\n10.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282364',NULL,'2026-06-15 23:24:40',1062,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(200,4,'2 vol. 93 chapter - Side Story. Chimera (1)\nkenga\n11.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282560',NULL,'2026-06-15 23:24:40',280,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(201,5,'2 vol. 94 chapter - Side Story. Chimera (2)\nkenga\n11.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282561',NULL,'2026-06-15 23:24:40',542,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(202,6,'2 vol. 95 chapter - Side Story. Chimera (3)\nkenga\n12.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282785',NULL,'2026-06-15 23:24:40',960,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(203,7,'2 vol. 96 chapter - Side Story. Chimera (4)\nkenga\n12.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 282786',NULL,'2026-06-15 23:24:40',630,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(204,8,'2 vol. 97 chapter - Side Story. Chimera (5)\nkenga\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283173',NULL,'2026-06-15 23:24:40',325,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(205,9,'2 vol. 98 chapter - Side Story. Transcendent (1)\nkenga\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283176',NULL,'2026-06-15 23:24:40',707,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(206,10,'2 vol. 99 chapter - Side Story. Transcendent (2)\nkenga\n14.01.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 283180',NULL,'2026-06-15 23:24:40',1032,NULL,21,'2026-06-07 21:30:05','2026-06-15 23:24:40'),(207,1,'5 vol. 1 chapter - Acceptance (1)\nSataBog\n23.05.2026','<p>Day la <strong>PROLOGUE</strong> mien phi.</p><p>Phai hien full content.</p>',NULL,'2026-06-15 23:24:40',133,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(208,2,'6 vol. 1 chapter - Everyday Life (1)\nSataBog\n03.06.2026','\"Mmm...\"\n\nDoh Yihyun let out a low sound and slowly opened his eyes.\n\nBright sunlight streamed through the half-open curtains.\n\nI overslept again.\n\nEven when he pressed his fingertips against his aching eyes, the fatigue refused to fade.\n\nIf anything, his eyelids only grew heavier.\n\nRecently, he had begun treating his unstable Omega trait using Seo Jungwoon\'s pheromones.',NULL,'2026-06-15 23:24:40',235,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(209,3,'5 vol. 2 chapter - Acceptance (2)\nSataBog\n23.05.2026','\'Imprinting.\'\n\nInstead, Doh Yihyun focused on the word the doctor had muttered.\n\nUnlike Omegas, who changed to the point that they could only sense the pheromones of the Alpha they had imprinted on, Alphas became sensitive to the pheromones of every trait once they imprinted.\n\nIf the doctor’s earlier hypothesis was correct—that Yihyun had originally been an unmanifested Alpha before changing into an Omega—\n\nif that was why medically inexplicable phenomena were occurring—\n\nYihyun lowered his gaze and fell into thought for a moment.\n\nHe had started reacting hypersensitively to pheromones immediately after becoming pregnant.',NULL,'2026-06-15 23:24:40',139,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(210,4,'5 vol. 3 chapter - Acceptance (3)\nSataBog\n24.05.2026','The moment he admitted that he missed Seo Jungwoon, his desire had begun spiraling completely out of control.\n\nEven before that, his thoughts had already been filled with Seo Jungwoon, but now it felt as if he had become an idiot incapable of thinking about anything else.\n\nDoh Yihyun spent the entire day unable to do anything, absently turning his dark phone over and over in his hands like a man possessed. The problem was that it no longer stopped at vaguely thinking about him.\n\nHe wanted to feel Seo Jungwoon’s warm body temperature.\n\nHe wanted to kiss those soft lips, breathe in those sweet pheromones until his lungs were full, then drench him in his own scent in return. He wanted to lean in so close that those clear gray brown eyes reflected no one but himself.\n\n\"Mr. Yihyun.\"\n\nSeo Jungwoon’s low voice sounded from behind him.',NULL,'2026-06-15 23:24:40',319,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(211,5,'5 vol. 4 chapter - Acceptance (4)\nSataBog\n24.05.2026','Noi dung chuong (dev placeholder).',NULL,'2026-06-15 23:24:40',697,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(212,6,'5 vol. 5 chapter - Acceptance (5)\nSataBog\n24.05.2026','Fortunately, the bright window was behind him.\n\nThe darkness hid his expression.\n\nDoh Yihyun himself could not even begin to guess what kind of face he was making right now.\n\nWhen he failed to answer, Seo Jungwoon’s straight brows twisted faintly.\n\nHis lips parted, then closed again several times.\n\nMeeting Doh Yihyun here so unexpectedly seemed to have scattered all his thoughts.\n\n\"Why did you leave?\"',NULL,'2026-06-15 23:24:40',671,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(213,7,'5 vol. 6 chapter - Acceptance (6)\nSataBog\n25.05.2026','Seo Jungwoon’s face twisted miserably. Grievance spilled openly from his storming gray brown eyes.\n\nAnd shamelessly enough, Doh Yihyun felt a sharp surge of joy.\n\n“You’re always calm, but I kept getting more anxious as time passed. I hated feeling like the person I knew myself to be was disappearing.”\n\nYihyun slowly forced out the thoughts drifting through his head. It was far too vague to call an answer to a confession.\n\nJungwoon listened silently. It was rare for Yihyun to reveal what he was thinking first.\n\n“More than anything...”\n\nYihyun hesitated.',NULL,'2026-06-15 23:24:40',278,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(214,8,'5 vol. 7 chapter - Acceptance (7)\nSataBog\n25.05.2026','Unable to tear his eyes away from the brightly glowing Seo Jungwoon, Doh Yihyun raised a hand to cover his cheek and mouth.\n\n“What are you talking about? Yihyun 씨 is the prettiest person in the world.”\n\nCompletely unconcerned, Jungwoon pressed a trail of tiny kisses against the back of Yihyun’s hand.\n\nRendered speechless, Yihyun stared at him uncertainly.\n\nEvery time Jungwoon called him pretty or cute, he had naturally assumed it was empty flattery.\n\nBut had he truly meant all of it?\n\nJungwoon looked in the mirror every morning. Yihyun seriously questioned his standards of beauty.',NULL,'2026-06-15 23:24:40',1077,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(215,9,'5 vol. 8 chapter - Acceptance (8)\nSataBog\n25.05.2026','He could not take his eyes off Jungwoon’s face.\n\n“They’re already gone.”\n\nJungwoon swept an irritated gaze over Yihyun’s now clean skin.\n\nOnly after leaving countless bite marks along the soft inner thighs did he finally swallow Yihyun’s cock whole.\n\n“Haah, ah, ngh...”\n\nYihyun let out moans barely louder than breathing.\n\nIt had been so long since his cock had been touched like this that climax rushed up frighteningly fast.',NULL,'2026-06-15 23:24:40',191,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(216,10,'5 vol. 9 chapter - Acceptance (9)\nSataBog\n26.05.2026','It felt like he might tumble beneath the waves.\n\n“Don’t worry. I’ll never let you slip away.”\n\nFeeling Doh Yihyun’s body go rigid, Seo Jungwoon wrapped an arm firmly around his chest. His hard cock slid in and out of Yihyun again in slow, smooth strokes.\n\n“Haah.”\n\nJungwoon gently kneaded Yihyun’s chest, fuller and softer than before, while biting down on the nape of his neck that was spilling fig scented pheromones into the air.\n\n“Ah—hnng.”\n\nWhenever Jungwoon crushed the swollen nipples between his fingertips, Yihyun shuddered helplessly. When sharp teeth sank into his skin, a chill ran down his spine with the dizzying sensation of being devoured alive. Each time, the walls inside him clung even tighter around the cock buried deep within.',NULL,'2026-06-15 23:24:40',868,NULL,22,'2026-06-07 21:30:07','2026-06-15 23:24:40'),(217,1,'176 chapter\nSataBog\n20.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 290810',NULL,'2026-06-15 23:24:40',757,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(218,2,'177 chapter\nSataBog\n20.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 290809',NULL,'2026-06-15 23:24:40',885,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(219,3,'178 chapter\nSataBog\n26.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 291911',NULL,'2026-06-15 23:24:40',1195,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(220,4,'179 chapter\nSataBog\n27.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 292057',NULL,'2026-06-15 23:24:40',480,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(221,5,'180 chapter\nSataBog\n28.02.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 292373',NULL,'2026-06-15 23:24:40',334,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(222,6,'181 chapter\nSataBog\n05.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 293239',NULL,'2026-06-15 23:24:40',390,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(223,7,'182 chapter\nSataBog\n07.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 293643',NULL,'2026-06-15 23:24:40',332,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(224,8,'183 chapter\nSataBog\n07.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 293642',NULL,'2026-06-15 23:24:40',876,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(225,9,'184 chapter\nSataBog\n12.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 294711',NULL,'2026-06-15 23:24:40',621,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(226,10,'185 chapter\nSataBog\n13.03.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 294981',NULL,'2026-06-15 23:24:40',463,NULL,23,'2026-06-07 21:30:08','2026-06-15 23:24:40'),(227,1,'Chapter 153\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77257',NULL,'2026-06-15 23:24:40',268,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(228,2,'Chapter 154\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77258',NULL,'2026-06-15 23:24:40',591,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(229,3,'Chapter 155\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77259',NULL,'2026-06-15 23:24:40',253,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(230,4,'Chapter 156\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77260',NULL,'2026-06-15 23:24:40',327,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(231,5,'Chapter 157\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77261',NULL,'2026-06-15 23:24:40',632,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(232,6,'Chapter 158\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77262',NULL,'2026-06-15 23:24:40',67,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(233,7,'Chapter 159\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77263',NULL,'2026-06-15 23:24:40',651,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(234,8,'Chapter 160\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77264',NULL,'2026-06-15 23:24:40',156,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(235,9,'Chapter 161\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77265',NULL,'2026-06-15 23:24:40',813,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(236,10,'Chapter 162\nsolee_79\n28.06.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 77266',NULL,'2026-06-15 23:24:40',880,NULL,24,'2026-06-07 21:30:10','2026-06-15 23:24:40'),(237,1,'1817 chapter\nSejong\n17.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224721',NULL,'2026-06-15 23:24:40',582,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(238,2,'1818 chapter\nSejong\n17.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224722',NULL,'2026-06-15 23:24:40',223,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(239,3,'1819 chapter\nSejong\n17.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 224724',NULL,'2026-06-15 23:24:40',683,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(240,4,'1820 chapter\nSejong\n19.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 225090',NULL,'2026-06-15 23:24:40',525,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(241,5,'1821 chapter\nSejong\n19.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 225092',NULL,'2026-06-15 23:24:40',484,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(242,6,'1822 chapter\nSejong\n20.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 225274',NULL,'2026-06-15 23:24:40',212,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(243,7,'1823 chapter\nSejong\n26.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 226625',NULL,'2026-06-15 23:24:40',276,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(244,8,'1824 chapter\nSejong\n26.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 226626',NULL,'2026-06-15 23:24:40',1061,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(245,9,'1825 chapter\nSejong\n26.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 226627',NULL,'2026-06-15 23:24:40',229,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(246,10,'1826 chapter\nSejong\n26.05.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 226628',NULL,'2026-06-15 23:24:40',1076,NULL,25,'2026-06-07 21:30:11','2026-06-15 23:24:40'),(247,1,'1 vol. 445 chapter - The other powerful beings frowned, but ultimately did not fall out. They also knew Tu Shan Zhu Nian\'s identity; his elder brother, Tu Shan Lan Song,\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258413',NULL,'2026-06-15 23:24:40',494,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(248,2,'1 vol. 446 chapter - What kind of person is the young master?\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258414',NULL,'2026-06-15 23:24:40',753,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(249,3,'1 vol. 447 chapter - He has a fiancée?\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258415',NULL,'2026-06-15 23:24:40',48,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(250,4,'1 vol. 448 chapter - The Mastermind\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258416',NULL,'2026-06-15 23:24:40',1193,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(251,5,'1 vol. 449 chapter - Yang Yao\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258417',NULL,'2026-06-15 23:24:40',152,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(252,6,'1 vol. 450 chapter - Separation Again\ninnOK\n03.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258418',NULL,'2026-06-15 23:24:40',913,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(253,7,'1 vol. 451 chapter - Everyone is Gone\ninnOK\n04.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258658',NULL,'2026-06-15 23:24:40',480,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(254,8,'1 vol. 452 chapter - The Woman Who Didn\'t Live\ninnOK\n04.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258681',NULL,'2026-06-15 23:24:40',96,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(255,9,'1 vol. 453 chapter - Royal Infighting\ninnOK\n04.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258682',NULL,'2026-06-15 23:24:40',304,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(256,10,'1 vol. 454 chapter - The Key Arrival\ninnOK\n04.10.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 258683',NULL,'2026-06-15 23:24:40',538,NULL,26,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(257,1,'Departure and Encounter\nSantos\n14.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198037',NULL,'2026-06-15 23:24:40',1185,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(258,2,'The Former Student Party and the Abandoned Mine Labyrinth\nSantos\n14.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198096',NULL,'2026-06-15 23:24:40',293,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(259,3,'Labyrinth Exploration and First Combat\nSantos\n14.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198097',NULL,'2026-06-15 23:24:40',640,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(260,4,'Tricks and Dungeon Cuisine\nSantos\n14.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198098',NULL,'2026-06-15 23:24:40',1109,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(261,5,'Mining Points and a Proposal\nSantos\n14.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198101',NULL,'2026-06-15 23:24:40',166,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(262,6,'The lucky four and Yuku\'s skill\nSantos\n15.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198124',NULL,'2026-06-15 23:24:40',369,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(263,7,'Unfounded Worries and the Decision of the Party Leader\nSantos\n15.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198126',NULL,'2026-06-15 23:24:40',315,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(264,8,'Simon\'s Miscalculation and Misunderstanding (Thunder Pike’s Perspective)\nSantos\n15.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198127',NULL,'2026-06-15 23:24:40',197,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(265,9,'A Celebration and a Grateful Heart\nSantos\n15.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198128',NULL,'2026-06-15 23:24:40',816,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(266,10,'A Suspicious Quest and Mamal\'s Warning\nSantos\n15.01.2025','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 198129',NULL,'2026-06-15 23:24:40',487,NULL,27,'2026-06-07 21:30:12','2026-06-15 23:24:40'),(267,1,'19.1 chapter\nsolee_79\n17.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309530',NULL,'2026-06-15 23:24:40',812,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(268,2,'19.2 chapter\nsolee_79\n17.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309533',NULL,'2026-06-15 23:24:40',413,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(269,3,'20 chapter\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309811',NULL,'2026-06-15 23:24:40',998,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(270,4,'21 chapter\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309812',NULL,'2026-06-15 23:24:40',470,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(271,5,'22 chapter\nsolee_79\n18.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 309813',NULL,'2026-06-15 23:24:40',1188,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(272,6,'23 chapter\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310122',NULL,'2026-06-15 23:24:40',562,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(273,7,'24 chapter\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310123',NULL,'2026-06-15 23:24:40',399,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(274,8,'25 chapter\nsolee_79\n19.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310124',NULL,'2026-06-15 23:24:40',635,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(275,9,'26 chapter\nsolee_79\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310414',NULL,'2026-06-15 23:24:40',931,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(276,10,'27 chapter\nsolee_79\n20.05.2026','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 310415',NULL,'2026-06-15 23:24:40',743,NULL,28,'2026-06-07 21:30:14','2026-06-15 23:24:40'),(277,1,'Her smile was Breathtaking\nSantos\n29.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 150708',NULL,'2026-06-15 23:24:40',780,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(278,2,'The cold school beauty is history\nsolee_79\n29.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 150823',NULL,'2026-06-15 23:24:40',1126,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(279,3,'31 chapter\nsolee_79\n30.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151211',NULL,'2026-06-15 23:24:40',737,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(280,4,'32 chapter\nsolee_79\n30.09.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151212',NULL,'2026-06-15 23:24:40',599,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(281,5,'33 chapter\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151379',NULL,'2026-06-15 23:24:40',917,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(282,6,'34 chapter\nsolee_79\n01.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151380',NULL,'2026-06-15 23:24:40',947,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(283,7,'35 chapter\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151741',NULL,'2026-06-15 23:24:40',795,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(284,8,'36 chapter\nsolee_79\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151742',NULL,'2026-06-15 23:24:40',685,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(285,9,'37 chapter\nsolee_79\n04.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151980',NULL,'2026-06-15 23:24:40',301,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(286,10,'38 chapter\nsolee_79\n04.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151982',NULL,'2026-06-15 23:24:40',917,NULL,29,'2026-06-07 21:30:15','2026-06-15 23:24:40'),(287,1,'Fingers Intertwined\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151822',NULL,'2026-06-15 23:24:40',442,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(288,2,'A Two-Way ChoiceSantos03.10.2024','<p>“Wellmy Ernest. I’ve heard that this all started when you fell into the river as a child. Is that right?” the lord of magic asked.</p><p>Wellmy thought back to that day. It was her second-oldest memory with Iora—among the few that she still remembered vividly. The oldest, of course, was the day they first met.</p><p><i>How pretty.</i></p><p>When she’d first laid eyes on Iora, Wellmy had been shocked to see that such a beautiful girl existed in the same world as she did. Furthermore, she’d been so kind that Wellmy had no way of knowing what Iora had thought of her on that fateful day.</p><p>Regardless, Iora was nice and always played with her. At the time, the elderly housekeeper, who had worked as the late Lady Ernest’s waiting maid, often watched over them.</p><p>That second memory—Wellmy’s fall into the river—had come shortly after the housekeeper left. Due to her advanced age, she had become unable to move about as she once had, and she had reluctantly retired from her duties.</p><p>Before she left, she’d patted both girls on the head and said, “Do be good to one another, my little ladies.”</p><p>Two months later, in the winter, she passed away.</p><p>Wellmy had always loved picking up pretty stones. On the day she’d fallen into the river, she had invited her sister and their new maid, Orea, to go with her. She spotted a rock she liked, somewhere a little hard to reach on the riverbank, and tried to go get it. Iora tried to stop her, saying that it was too dangerous, but Wellmy didn’t heed her warning, replying that she would be fine. The next instant, she stepped on a slippery moss-covered rock, lost her footing, and fell into the river. The water was shallow, so she didn’t get swept away or anything of the sort, but she was drenched. Later that day, she spiked a fever.</p><p>As she lay on her bed, barely conscious, she heard her parents blame Iora for the accident.</p><p>“No... Iora tried to stop me,” she said, but they ignored her.</p><p>Her vision blurry, she looked up at them. A shudder ran down her spine. Their eyes were <i>smiling</i>.</p><p><br>&nbsp;</p><p>It was almost as if they were happy to finally have a reason to be cruel to Iora. Wellmy didn’t understand why, but she could see the devilish smiles lurking beneath their angry masks.</p><p><i>Who are these people?</i></p><p>To Wellmy, it seemed as if her parents were possessed by demons. Iora had her head hung low, a miserable look on her face, so she hadn’t noticed the darkness in their expressions.</p><p>Eventually, their parents seemed to have had their fill of insulting and slapping their daughter, and they left the room. As for Iora, she remained by Wellmy’s side all night long with Orea, nursing her sister back to health.</p><p>Iora was so kind. So brave.</p><p>“I’m sorry,” she whispered to Wellmy, her cheeks red from the slaps their mother had given her. It looked painful.</p><p><br>&nbsp;</p><p><i>I’m scared.</i></p><p>Wellmy was terrified of her parents—of these people who had feigned anger on behalf of their daughter, yet had abandoned her when she was running a fever. But more than anything, she was scared of what they would do to Iora.</p><p>In the ballroom, Wellmy threw a brief glance at her sister, who had finally escaped their parents’ clutches, before shifting her attention back to the lord of magic. “I did, and our parents naturally scolded my sister for it. After all, it was her fault that I fell in the first place,” she lied.</p><p>“Really? The maid Iora brought with her told us a different story,” the lord of magic replied.</p><p>The maid in question was none other than Orea, the maid who had been with them when Wellmy had fallen into the river, and the only servant Iora had taken with her to the lord of magic’s estate. She was two years their elder.</p><p>Thinking back on the accident, Wellmy recalled how their parents had begun treating the poor maid horribly from that day onward, just as they had her sister. This was why, at the time, Wellmy had suggested that Orea should move into the detached building with Iora.</p><p>The lord of magic fixed his gaze behind Carla and Leo, and a young woman with black hair stepped forward, calmly eyeing Wellmy.</p><p>“Oh, Orea. Why did you tell such lies?” Wellmy asked, making sure to grimace to really sell her act.</p><p>“I did not lie, Lady Wellmy. On that day, you refused to heed your sister’s warning and fell into the river all on your own,” Orea replied, her voice clear and strong.</p><p>Wellmy shifted her gaze to the lord of magic. “Do you truly believe the words of an incompetent servant like her? I did not think you to be that sort of person, Lord Aides.”</p><p>The lord of magic had warned her not to call him by his first name, yet she kept doing it. She wondered how that made him feel.</p><p>He didn’t address it and moved on with his accusations. “When you began persecuting Iora, you stole all of her belongings, did you not?”</p><p>Wellmy was unmistakably the one who’d given her parents that idea.</p><p style=\"text-align:justify;\">After the accident, their parents had become crueler and crueler to Iora with each passing day. The first thing they’d done was take her belongings away from her.</p><p>It had all started when Wellmy gazed at her sister’s necklace and innocently remarked, “No matter how many times I look at it, it’s still so pretty.”</p><p>Before Iora could reply, Wellmy’s mother chimed in.</p><p><br>&nbsp;</p><p>“It truly is a beautiful necklace. I am sure it would look far better on you, Wellmy.”</p><p>The little girl hadn’t meant it like <i>that</i>. Her eyes shot wide open in shock, while Iora paled.</p><p>“It’s a memento from my mother,” Iora said, on the verge of tears, but the new Lady Ernest paid her no mind.</p><p>She snatched the necklace and handed it to her daughter. “From today onward, it belongs to you.”</p><p>Wellmy wanted to protest, <i>No! It’s Iora’s! </i>But she could easily imagine what would happen if she were to smuggle the necklace back to her sister: Their mother would claim that she had stolen it.</p><p>As such, she averted her gaze from the pitiful look on Iora’s face, took the necklace, returned to her room, and placed it at the very bottom of her jewelry box. She made a silent promise to return it to her sister once they were both adults—once they were out of that house.</p><p>From that day onward, all of Iora’s dresses and possessions became Wellmy’s. She figured that there would be no point in keeping the clothes, as her sister would likely have grown too much to fit into them again by the time she escaped, but Wellmy made sure to stow every single accessory away.</p><p style=\"text-align:justify;\">On the day Iora left for the lord of magic’s estate, Wellmy exchanged as many of her own belongings as she could for jewels and stuffed them into a bag. She, of course, made sure to include the necklace that had belonged to Iora’s mother. Then, she went to find Orea, and handed her the bag.</p><p>“Hide this among Iora’s luggage to make it look like she stole it,” she ordered with the most vicious smile she could muster.</p><p>As it turned out, her little scheme had borne fruit, and she could now reply to the lord of magic’s accusation with confidence.</p><p>“<i>We </i>stole <i>her </i>belongings? Not the other way around?” she asked, secretly pleased with herself.</p><p>Why? Because, as she’d hoped, Iora was currently wearing the necklace her mother had left her.</p><p>“That necklace was given to <i>me</i>, Lord Aides,” she continued. “So why does my sister have it? She must have stolen it when she left the estate.”</p><p>Murmurs simmered among the gathered crowd, but the lord of magic simply dismissed Wellmy’s accusation with a laugh. “All of the jewels and accessories Iora brought were concealed with magic and had a name inscribed on them: ‘Iora Ernest.’”</p><p>The crowd grew even louder at his words.</p><p>As for Wellmy, she made a show of gritting her teeth and furrowing her brow. “Gordley!” she exclaimed.</p><p><br>&nbsp;</p><p>She always brought Gordley along whenever she went out to buy jewelry.</p><p>Likewise, when gem dealers were invited to the Ernest estate, she’d always ordered the butler to stay in the room. Naturally, she had done the same when she had gone to exchange her jewels for money.</p><p>What no one knew was that Wellmy herself had inscribed Iora’s name on the precious stones in preparation for this exact situation, so that her beloved sister would have some wealth to her name. Based on her reaction, people would likely assume that the butler was at fault. They might blame him at first, but would quickly forgive him once they witnessed the rest of this condemnation show. They would come to see it as a desperate act from a loyal butler supporting the legitimate successor of their family.</p><p>“You’re even going as far as to accuse Iora of crimes she didn’t commit. How pathetic. And just like every other pathetic schemer, you didn’t think your lies through very well.”</p><p>Wellmy inwardly replied to the lord of magic’s cruel smile with one of her own. On the surface, though, she merely grimaced, feigning frustration.</p><p>The condemnation scene wasn’t anywhere near done. This was only the beginning.</p><p style=\"text-align:center;\">※※※</p><p>“Not only did you steal from Iora,” the lord of magic resumed, “but you also made her dye her hair, forced her to wear glasses to hide her face, dressed her in shabby clothes, and relegated her to working like a servant, did you not? Then, you sequestered her in a detached building of the estate.”</p><p>These were all facts. Wellmy had indeed influenced her parents to make all of these decisions.</p><p>It had all started when she was twelve. Back then, her parents had been treating Iora worse than a servant, making her do chores that even maids would have been uncomfortable with. Consequently, Wellmy’s poor sister had been constantly exhausted.</p><p>The only person who had tried to help Iora back then had been Orea, their waiting maid. Their father had replaced nearly all of the household staff after the death of his first wife. Only Gordley, the butler, had remained. All the other new employees had turned a blind eye to Iora’s suffering.</p><p><i>At this rate, Iora is going to die, </i>Wellmy had realized in horror.</p><p>Every time her sister made even the smallest of mistakes, their parents would yell and deprive her of food.</p><p>Wellmy had been desperate to save her sister. She had tried to make roundabout comments about how sorry she felt for her sister in front of the</p><p><br>&nbsp;</p><p>demons that were her parents, to no avail.</p><p>“What a kind girl you are, Wellmy. Iora, on the other hand...” they would say. In the end, it had only given them more reasons to talk badly of Iora.</p><p>That was when Wellmy had come to realize that, to protect her sister, she would need to act opposite of her instincts: pretend to be on their parents’ side and make it seem as if she, too, was bullying Iora.</p><p>Two years from then, the sisters would be enrolling in the noble academy.</p><p>Wellmy had a governess, so she would be fine, but Iora did not. She would likely lag academically compared to her peers, and her grades might not be up to par. But even if she struggled at school, people were bound to notice her beauty and her potential with magic the moment they saw the violet hue of her irises.</p><p>Wellmy’s first thought had been to order her sister to fumble all of her spells on purpose in class, but that might not have been enough. Despite being the daughter of a count, Iora didn’t have anyone to protect her. What if she caught the eye of someone malicious?</p><p>The moment that thought had crossed Wellmy’s mind, she’d decided that she had to hide her sister’s beauty from the rest of the world.</p><p>“Father, Iora’s hair color is a torture to look at.” It was so beautiful that anyone would feel compelled to chase it with their eyes.</p><p>“Mother, Iora is glaring at me. Could it be that she has poor eyesight, perhaps?” She couldn’t let others see her sister’s bright, sparkling eyes.</p><p>When Wellmy saw how emaciated and unkempt her sister had become, she’d spoken to her parents one more time.</p><p>“Father, mother, I can’t bear to look at Iora anymore. She’s so dirty!” In truth, all she wanted was to see her sister dressed in beautiful clothes.</p><p>But by that point, such abuses had been her only way to protect Iora.</p><p>“Why don’t we make her live in the detached building?” she’d suggested.</p><p>Everything had gone according to her plan. She’d even added that she didn’t like their waiting maid and sent her to live with Iora. Wellmy had trusted that Orea would be able to provide some protection for her sister at least. Then, she’d asked her mother to forbid the other servants from going to the detached building.</p><p>It had been the first time she had managed to protect her sister from their parents. Reflecting on her past achievements, Wellmy smiled at the lord of magic. “There seems to have been a misunderstanding, Lord Aides. My sister <i>asked </i>to learn how to perform the duties of a servant. We merely assisted her in that pursuit. She also moved to the detached building of her own volition. I presume that she didn’t want to see us anymore.”</p><p>The man snorted. “At least you have gotten one thing right. Iora likely</p><p><br>&nbsp;</p><p>wanted to stay far away from you. But how do you explain the fact that your parents had her live in that building with no access to firewood or blankets and refused to let her see the doctor even when she fell ill due to the cold?”</p><p>“Th-That’s, um, because Iora hates the doctor,” Wellmy said, intentionally stammering.</p><p>“Does she, now? When she arrived at my estate, she was perfectly calm when I called the doctor to examine her. In fact, the two of them got along quite nicely. Iora is very well-read, so they had plenty to discuss.”</p><p>Wellmy did not doubt that they had. After all, her sister didn’t dislike the doctor—that was merely another lie.</p><p>Iora had fallen ill once. Orea came to inform their parents that their daughter had spiked a fever, but they dismissed her. Even when Gordley told them that she was in a bad state, they refused to budge.</p><p>Back then, Wellmy racked her brain to find a way to save her sister. Her parents frequently left the house to attend tea parties and banquets,</p><p>usually going to the latter as a couple. The night following the day Iora spiked a fever, they were due to attend yet another event.</p><p>That was when Wellmy made her move.</p><p>She wrote a letter to the doctor and slipped a small gem her mother had given her into the envelope. Then, she instructed Gordley to tell Orea to surreptitiously deliver it to the doctor and ask him to come at night. Why them? Because they were on Iora’s side. Of course, she forbade them from telling a soul who had given them the order.</p><p>She also had them smuggle unused blankets for Iora to use and gave them another small gem to buy plenty of firewood to heat the detached building.</p><p style=\"text-align:justify;\">The demons never went to see Iora, so they would never notice that anything was amiss. And on the off chance that they did, Wellmy trusted that Gordley would come up with an explanation that sounded convincing enough.</p><p>When their parents left that night, they gave orders for the kitchen staff not to feed Iora.</p><p>“If she’s just going to sleep, she doesn’t need to eat.”</p><p>Thus, Wellmy had to hurriedly come up with a plan to ensure Iora would have at least some sustenance.</p><p>She hid one of the pieces of bread she had been served at dinner and, after the servants had taken their own meals, headed to the kitchen and said, “I’m still hungry. Give me some soup.”</p><p>The cook warned her that there was essentially only broth left, but did as she demanded, handing her a tray with a bowl of soup on it.</p><p>Wellmy crumbled the bread that she had hidden and mixed it into the broth to make bread porridge. Then, she headed to the detached building and</p><p><br>&nbsp;</p><p>thrust the tray at Orea.</p><p>“Feed this to my good-for-nothing sister,” Wellmy ordered as the girl stared at her with wide, confused eyes. “This trash is perfect for her.”</p><p>With that, she turned around and returned to the main mansion.</p><p>Later that night, Wellmy watched from the window as a carriage parked in front of the estate, and a man dressed like a doctor emerged from it. Some time later, Gordley sneakily escorted him back to the gate, and the man left.</p><p>Relieved, Wellmy headed to bed.</p><p>When they received news that Iora’s fever had broken, her parents didn’t even bother to hide their disappointment.</p><p>“What a shame,” they said.</p><p>One thing was very clear in Wellmy’s mind: These people wanted Iora to die. But she still didn’t know why they were treating her so harshly.</p><p>From that point on, Wellmy continued to help her sister, but in a roundabout way so that no one would suspect her involvement. She was especially proud of herself for getting her parents to assign a private tutor to Iora.</p><p>“Mother, my governess keeps finding fault with my work,” she complained one day. “I can’t take it anymore! Assign her to Iora and find me a nicer one!”</p><p style=\"text-align:justify;\">The governess Wellmy’s mother had hired for her was a brilliant woman. While strict, she was an excellent etiquette instructor and properly supervised Wellmy’s studies.</p><p style=\"text-align:justify;\"><i>She’ll ensure that Iora is cultured enough to avoid any embarrassment at school, </i>Wellmy hoped.</p><p>Out loud, she simply insinuated that her mother could use the governess to torment Iora further. Her plan was a success, and Iora finally had access to proper education. As for Wellmy’s new teacher, she was rather mediocre, but the girl couldn’t care less. She didn’t need an education.</p><p>With only a year left before she and Iora enrolled at the noble academy, Wellmy had made up her mind. She would help her sister escape this family, even if it meant dooming herself in the process.</p><p style=\"text-align:center;\">※※※</p><p>“And if it wasn’t bad enough, you and your parents used their money exclusively on yourselves, spending coins as if they grew on trees,” the lord of magic went on. “I have documents to prove it.”</p><p>“Oh, so now you intend to judge us for how we spend <i>our own </i>fortune?” Wellmy retorted. “Besides, we’re not the ones who squandered the money—</p><p><br>&nbsp;</p><p style=\"text-align:justify;\">Iora is! Buying all of these expensive magic items...”</p><p style=\"text-align:justify;\">At Aides’s words, a servant quickly made his way toward them, carrying two massive books. The lord of magic took the volumes and turned his gaze to Count Ernest, Wellmy’s father, a look of exasperation on his face.</p><p>“The purchase of these magic items is indeed recorded here, alongside the purchases of dresses and jewelry,” he said. “I do not know who sent Count Ernest’s account books to me, but I have noticed that there are some entries which show a certain amount in one book, and a completely different amount in the other.”</p><p>Wellmy’s father realized what the lord of magic was getting at, and his face instantly drained of color. Some of the other guests had also understood and they stared at him in shock.</p><p>Her father had a second, fraudulent account book.</p><p>Aides didn’t know who had sent it to him, but it had, of course, been none other than Wellmy herself, though she had kept her identity a secret.</p><p>Back when Iora was living at the Ernest estate, their father had foisted many of his duties onto her: recording expenses in his account book, writing letters to the administrators of their father’s dominion on his behalf, and summarizing the demands of their people to decide which were to be prioritized or dismissed. Any duty that hadn’t involved negotiating or rubbing elbows with other nobles had fallen to her. Maintaining a territory wasn’t glamorous, but it was necessary work for any feudal lord.</p><p>Gordley sometimes assisted Iora, but he had his own duties to attend to and couldn’t sneak off to the detached building too often.</p><p>It was from that point onward that Iora began suffering from lack of sleep.</p><p>Wellmy noticed that something was amiss when part of her father’s work was assigned to her, under the guise of helping her practice bookkeeping.</p><p><i>But why would father have me do just some of the bookkeeping and Iora the rest? </i>she wondered. <i>He’ll have to check two different sets of records instead of one.</i></p><p>While recording the expenses and income allowed Count Ernest to visualize his financial situation more clearly, wouldn’t it have been less effort for him to have Iora write down all of the numbers and ensure they aligned afterward?</p><p>That was when it hit Wellmy: <i>Is there a </i>reason <i>he can’t let Iora handle it all...?</i></p><p>To confirm her suspicions, she deliberately slipped one of the receipts she was supposed to record into her sister’s pile, thinking that Iora would go to Gordley if something was amiss. Just to be safe, she made sure to keep an eye on her sister.</p><p><br>&nbsp;</p><p>To Wellmy’s surprise, she later saw Iora leave the detached building.</p><p>A chill ran down her spine. She hurriedly made her way to their father’s study and, as she babbled to him about nonsense, Iora entered the room.</p><p>“There are two tax declarations from the same region, but they show different figures,” she said.</p><p><i>I knew it. </i>Count Ernest doctored the records of his income.</p><p>Before he could say anything, Wellmy flashed Iora a condescending smile and said, “Dear sister, do you truly think that you have any right to criticize father’s work?”</p><p><i>Don’t say anything else. Please, </i>she pleaded inwardly.</p><p>If she offended their father and he decided not to allow Iora to attend the noble academy, Iora would never be able to escape. Their parents would keep her in captivity for the rest of her life. She had made a big mistake by coming to confront their father directly.</p><p>As expected, while Wellmy’s intervention mitigated his fury to some extent, Count Ernest bellowed at Iora never to step foot inside the main mansion ever again, panic evident on his face.</p><p>From that point onward, he grew a little more prudent with his scheming. However, as he didn’t suspect Wellmy of having found him out, it had been a piece of cake for her to pull out their recent record books and make copies of them. Iora had been too busy handling her other duties, and Wellmy had access to the real, undoctored account books. As such, she had made it her mission to gather proof of their father’s wrongdoings to use when the time came.</p><p>“The one who filled this record book—the official, public one, so to say— is <i>you</i>, Wellmy Ernest,” the lord of magic said, his lips curling into a faint smile. Like a hunter about to close on his prey, he didn’t give Wellmy any time to retort before adding, “You knew it, didn’t you? That your father was committing tax evasion and submitting false returns.”</p><p>“I-I have no idea what you are talking about! My father would never do such a thing!” Wellmy exclaimed.</p><p style=\"text-align:justify;\">She was good at playing the fool. Besides, she had a general idea of what the lord of magic would say. After all, she was the one who had orchestrated everything—from her sister’s betrothal to the lord of magic gaining access to her father’s records.</p><p>“He ‘would never do such a thing,’ you say? What about the magic items you claim Iora selfishly purchased with the family’s money, then? Every single one of them is of unknown origin, and they all have traces of curses having been placed on them. Moreover, I have several witnesses who can confirm that the buyer of these items was a short, stocky middle-aged</p><p><br>&nbsp;</p><p>nobleman with a small mustache.” Aides paused, then resumed.</p><p>“Interestingly enough, someone has removed the curses from each of the items. But who could the cursed items have been meant for in the first place? Oh, come to think of it, you have recently named Wellmy your heir, haven’t you, Count Ernest?”</p><p>This time, the atmosphere in the banquet hall shifted drastically. Before, the partygoers had simply been curious about the unfolding drama, but now that they’d realized what Count Ernest had tried to do to his own daughter, their disapproval was palpable.</p><p>The lord of magic’s implications had been so limpid that even Wellmy’s fool of a father had understood them. “Wh-Wha...?! I-I didn’t do it! Don’t look at me like that!” he exclaimed, his face as pale as a sheet.</p><p>A short, stocky middle-aged nobleman with a small mustache. This was more or less an exact description of Count Ernest.</p><p><i>With that wording and reaction, you have basically confirmed everyone’s suspicions, father.</i></p><p>Fighting the urge to laugh, Wellmy schooled her expression into one of confusion. “I-It was Iora! She was the one trying to curse our father!”</p><p>“Impossible,” the lord of magic refuted. “The magic items had all been placed in Iora’s room. Her waiting maid and the estate’s butler have confirmed it. These types of items are designed to spread the curse to their surroundings.”</p><p>Of course, this was true. Despite Wellmy’s claims, she was well aware that her father had tried to kill her sister with the cursed items. After all, she was the one who’d lifted the curses from all of them after their father had ordered Gordley to place them in Iora’s room.</p><p>People born with purple eyes could perform any type of magic. Those with golden eyes excelled at offensive spells, while silver irises indicated a talent for healing. Though inferior to her counterparts, Wellmy, with her crimson eyes, had the best foundation for what was known as support magic. At school, she’d hidden her abilities, but she had actually been practicing curse-lifting since the first time she’d seen her father purchase an item to kill her sister. At this point, she was more or less able to lift any curse known to mankind. When she’d started at the noble academy, she had been in poor health for a while due to all the curse-lifting she’d had to do before returning the items to her sister’s room, but the symptoms had all ceased since.</p><p>Needless to say, buying and selling cursed items was incredibly illegal, and the lord of magic didn’t hesitate to lay Count Ernest’s crimes bare for all to see. Wellmy wouldn’t have expected any less from him. She’d entrusted</p><p><br>&nbsp;</p><p>her sister to him exactly because she knew that was the type of person he was. “What a foolish crime you have committed, Lord Ernest,” the lord of</p><p>magic said.</p><p>That man, infamous for his chauvinistic and misanthropic tendencies, loathed curses. He was the one who’d ordered a complete reform of magic items, after rising to the top of the Department of Magical Affairs and studying the matter in great detail to crack down on them. His reputation as a cruel and callous man had been entirely made up by disgruntled nobles, furious to have lost the ability to use curses to kill those standing in their way.</p><p>Before tonight, Wellmy had only met him once at a party, yet she had instantly been sure of it: the lord of magic wasn’t the man society had painted him to be.</p><p style=\"text-align:center;\">※※※</p><p>Young nobles made their society debut once they came of age at sixteen. In other words, it was halfway through their education at the academy, which they attended from fourteen to eighteen.</p><p>From the moment Wellmy stepped into the school, she focused all her efforts on keeping Arvine’s attention on her, and not on her sister. He was so disappointed by his fiancée’s appearance that it was easy to win him over.</p><p><i>That boy is no good for her.</i></p><p>At that time, Wellmy had already been aware of the fact that she had a unique ability, one that no one else possessed: She could intuitively see others’ true natures.</p><p>She didn’t know how it worked or why she had it, but it was thanks to that ability that she had been able to see through her parents’ façade that fateful night after she’d fallen into the river.</p><p style=\"text-align:justify;\">The difference in Arvine’s reaction when he’d seen Iora compared to when he’d watched Wellmy introduce herself, her head bowed, had been blatant. Wellmy hadn’t missed the glimmer of lust in his eyes when he’d looked at her.</p><p style=\"text-align:justify;\"><i>He only cares about looks.</i></p><p>Wellmy had already reached this conclusion years ago, when he’d asked to marry Iora after seeing her only once.</p><p>Arvine was the second son of a count, which meant he likely had far better marriage prospects than the daughter of a house in decline. Yet, he’d insisted on marrying Iora for her appearance. That was rather puzzling, considering that he himself wasn’t bad-looking and didn’t seem <i>that </i>stupid. In a way, he was an honest boy—but that was all there was to him. Perhaps he only saw</p><p><br>&nbsp;</p><p>women as tools to satisfy his desires and couldn’t have cared less about their other qualities.</p><p>Needless to say, Wellmy couldn’t entrust her sister’s well-being to someone like him.</p><p>She also began wondering how to behave among others and how to interact with them.</p><p><i>I don’t need friends.</i></p><p>She didn’t want even a semblance of camaraderie with other noble children. Instead, she decided to <i>use </i>them. To further her goal of keeping Arvine as far away from Iora as possible, she had deliberately surrounded herself with sycophantic young lords and ladies who loved to gossip and speak behind others’ backs. All she’d had to do was pretend to hate her sister and flirt ostentatiously with Arvine, and her “friends” did the rest, spreading nasty rumors about both Iora and herself. Wellmy was incredibly grateful for their cooperation—not that they had any idea she had orchestrated it all.</p><p>A young noble girl whose fiancé had been stolen by her own sister.</p><p>Despite being the same age, the two of them looked nothing alike. This was prime fodder for gossip.</p><p>Arvine being Iora’s fiancé came with some positives, though: It had the advantage of keeping other boys at bay. Besides, he was so weak to Wellmy’s charms that it allowed her to easily craft the narrative she wanted, despite how much it pained her to see her sister suffer both at home and at school.</p><p>A decent individual—not one by noble standards, but a proper person with common sense—would have understood Iora’s true worth after only minutes of conversation. Wellmy carefully selected nobles who fit that criteria and who wouldn’t allow themselves to be influenced by rumors.</p><p>One of them was Karla, the daughter of a viscount.</p><p>Despite seeming meek at first glance, she was a very determined young woman. Though ambitious, she chose her friends carefully and kept a suitable distance from them. This left Wellmy with a good impression.</p><p>When they first met, Wellmy had already assembled an entourage of gossip-loving minions. Seeing as some of them hailed from powerful houses, Karla tried to get closer to her group. Wellmy wasted no time investigating her background. Karla’s family was rapidly gaining influence thanks to their thriving business and had connections with wealthy commoner merchants as well as certain margraves from the border provinces. Karla’s father might have only been a viscount, but it would have been unwise to underestimate him. He had enough support that it wouldn’t surprise Wellmy if he were granted the title of count in the near future, without needing to butter up other, more powerful nobles.</p><p><br>&nbsp;</p><p><i>She’ll do perfectly, </i>Wellmy thought.</p><p>Karla was a good judge of character, but always behaved with tact. Yet, she didn’t hesitate to criticize Wellmy harshly in front of her entire posse.</p><p>“Lord Arvine is betrothed to your sister. I don’t believe either of you has anything to gain from the way you’re behaving,” she said.</p><p><i>“I don’t believe either of you has anything to gain from the way you’re behaving.”</i></p><p>From an outsider’s perspective, it might have very much been the case. To others, it simply looked like one sister was surrounded by foolish yes-men, while the other was alone and friendless because of all the bad rumors circulating.</p><p><i>Iora needs someone like her by her side.</i></p><p>“If you want to play Goody Two-shoes so badly, how about you go keep my sister company?” Wellmy retorted with a cold smile.</p><p>In reality, it was exactly what she’d been hoping for. But how did Karla interpret her words?</p><p style=\"text-align:justify;\">She stared at Wellmy, then glanced at her entourage, who’d been watching the exchange with cruel grins on their lips, and left without another word. She would never approach them again. Wellmy assumed that she must’ve decided she had nothing to gain from associating with them.</p><p style=\"text-align:justify;\">Several days later, Karla started spending time with Iora. Wellmy didn’t know what the two of them had talked about, but her plan had been a success.</p><p><i>Good.</i></p><p style=\"text-align:justify;\">Karla would likely shoo away any bad egg who tried to approach her sister, and anyone she deemed worthy of attention would become a good friend to Iora.</p><p>Wellmy couldn’t care less about her own relationships. She’d vanish from high society soon enough.</p><p>That was right; even back then, she had started planning her own doom.</p><p>Wellmy only made one mistake during her time at the noble academy: She let a boy get too close to her sister—Leo, the son of a baron.</p><p>The moment she laid eyes on him, she knew he would be trouble. He wasn’t a bad person, and Wellmy knew he wouldn’t make Iora unhappy. But the way he looked at Wellmy, as if he could see through her, had felt dangerous.</p><p>At some point, the boy appeared at Iora’s side and began spending time with her and Karla. He’d likely noticed her sister’s good heart, which Wellmy was fine with. What wouldn’t have been acceptable was for him to encourage Iora to dress up, or to plant the idea in her mind to show her true beauty to the world.</p><p><br>&nbsp;</p><p>If she did, Wellmy’s plan would be all for naught.</p><p>Wellmy needed to hide her sister’s true appearance until at least graduation day. If Arvine or another boy set his sights on Iora before she made her society debut, if she revealed her true beauty and caught someone’s eye... Leo wouldn’t be able to protect her, especially not from Arvine. Being Iora’s fiancé, he had every right to tell Leo to buzz off. So far, he’d only used his position to torment Iora, but if his loathing turned into desire, Wellmy wouldn’t put it past him to proceed with the marriage despite them still being students.</p><p>Right now, she was doing everything in her power to make her parents and her sister’s fiancé like her, but she would be no match for Iora if her sister were to regain her beauty. Wellmy understood this better than anyone else.</p><p>For years, anxiety gnawed at her. How relieved she was when their graduation day arrived, and no boy had made a move on her sister.</p><p>At last, it was time for their debutante ball and for Wellmy’s plan to enter its next phase.</p><p style=\"text-align:center;\">※※※</p><p><i>The time has finally come.</i></p><p>Having made Arvine promise to break his engagement to Iora, Wellmy began searching for a suitable partner for her sister.</p><p>Whenever a single noble lady attended a party, she would be escorted by her father or (if she had any) a brother. As Count Ernest usually accompanied Wellmy, she had no choice but to leave her sister in Arvine’s hands, at least while they made their entrance. He was her fiancé, after all. Needless to say, Wellmy was far from happy about it.</p><p>Usually, Arvine would leave Iora’s side the moment they entered the party hall to join Wellmy. However, Count Ernest and his wife always insisted that Iora stay with Wellmy to enhance her younger sister’s reputation, which meant Iora never left her side. Of course, she wasn’t allowed to attend parties alone.</p><p><i>Hmm... I can’t find a good one, </i>Wellmy thought as she surveyed the party hall.</p><p>Tonight was their debutante ball. As these were hosted by the royal family, the head of every noble family was expected to attend with their partner. One needed a very good reason to decline the invitation. If a couple had children of marriageable age, it was customary to bring them along.</p><p>But to Wellmy’s dismay, none of the young noblemen at the party seemed to be a good suitor for her sister. There were a few brothers accompanying</p><p><br>&nbsp;</p><p>their sisters at the party, but all the promising young men already had fiancées of their own.</p><p>Wellmy needed to find a young man who boasted both influence and popularity, and who wasn’t betrothed. Most men would see little point in marrying Iora in her current state, but Wellmy trusted that, once they learned her sister’s true nature, everything would be fine. After all, Iora was smart and beautiful, with gorgeous purple eyes.</p><p>Of course, Wellmy had known all along that finding such a man would be akin to finding a needle in a haystack. Yet she couldn’t help but be disappointed by the lack of promising candidates at the party. She took a step forward but, in her distraction, bumped into someone who had just entered the venue.</p><p>“Ah!”</p><p>“Apologies, my lady. Are you hurt?” a deep, calm voice asked.</p><p><br>&nbsp;</p><p>Her attention drawn, Wellmy looked up at the man she had bumped into.</p><p>Her gaze met periwinkle eyes, filled with intelligence and confidence, and she felt as if she might get sucked right in. His face was blank, but Wellmy could tell from the look in his eyes that he was genuinely worried about her well­being without any ulterior motive. When they collided, he had wrapped an arm around her waist to steady her. The gesture was neither obscene nor overly forceful—he was merely supporting her. He was absurdly good-looking, with flowing silver hair. Wellmy would realize some time later that his hair only added to his mysterious charm.</p><p style=\"text-align:justify;\">For a split second, Wellmy let her surprise show on her face, but she quickly put her mask back on: Wellmy Ernest, the shameless, boy-crazy young lady.</p><p style=\"text-align:justify;\">Pretending to be spellbound by the man’s appearance, she spoke up in a honeyed tone, “I’m all right, my lord. I’m incredibly sorry for bumping into you.”</p><p>The hint of worry immediately vanished from the man’s eyes, replaced by contempt. His awfully handsome face looked as cold as that of a demon.</p><p>“Good. I shall now take my leave.”</p><p>His hand let go of Wellmy, and he left without so much as saying goodbye.</p><p>Wellmy stared at his retreating back. She could discern one’s true nature with a single glance and, right now, her instincts were screaming at her.</p><p><i>He will do perfectly.</i></p><p>Arvine had noticed Wellmy’s eyes wandering to the man, and he began sulking. She comforted him to the best of her ability. The moment he left her alone, she took the opportunity to casually ask her mother about the man she’d bumped into. He was so handsome that he stood out even among the throngs of partygoers.</p><p>“Oh, the lord of magic? He’s the head of the Ormirage margravial house,” Lady Ernest told her. “The crown has conferred upon him the title of Archmage for his many contributions and incredible magic abilities. That’s why everyone calls him the ‘lord of magic.’ Rumor has it that he is a cold and cruel man who hates noble society and despises women. He’s handsome, powerful, and rich, but alas... What a shame.”</p><p>Not only was he such an outstanding mage that he had been granted a title for it, but he had also risen to the top of the Department of Magical Affairs at a young age due to his groundbreaking research and investigations into magic-related crimes. As for his chauvinist tendencies... Wellmy believed them to only be an act. His earlier expression didn’t belong to a man who would abandon a woman in need without remorse.</p><p><br>&nbsp;</p><p>He avoided women. But why? Perhaps he was tired of being pursued only for his looks, and he allowed these rumors to circulate on purpose. At least, that was how it seemed to Wellmy.</p><p>Marquis Aides Ormirage. The cruel and heartless lord of magic.</p><p><i>At last, I’ve found the perfect man to entrust my sister to.</i></p>',NULL,'2026-06-15 23:24:40',168,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(289,3,'An Elaborate Confession\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151824',NULL,'2026-06-15 23:24:40',25,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(290,4,'Experience of Being Tricked\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151825',NULL,'2026-06-15 23:24:40',979,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(291,5,'Meng Yuan Return the Money\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151826',NULL,'2026-06-15 23:24:40',707,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(292,6,'Shock Without Joy\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151827',NULL,'2026-06-15 23:24:40',589,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(293,7,'The Online Relationship\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151828',NULL,'2026-06-15 23:24:40',1032,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(294,8,'Crossdressing Big Shot\nSantos\n03.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 151829',NULL,'2026-06-15 23:24:40',419,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(295,9,'Four Couples\nSantos\n06.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 159180',NULL,'2026-06-15 23:24:40',1162,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40'),(296,10,'I Am Very Happy\nSantos\n10.10.2024','Noi dung chuong chua co trong ban HTML offline.\n\nSource: Novelight chapter 160042',NULL,'2026-06-15 23:24:40',361,NULL,30,'2026-06-07 21:30:16','2026-06-15 23:24:40');
/*!40000 ALTER TABLE `chapters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `characters_user_id_foreign` (`user_id`),
  CONSTRAINT `characters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_article`
--

DROP TABLE IF EXISTS `collection_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_article` (
  `collection_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`collection_id`,`article_id`),
  KEY `collection_article_article_id_foreign` (`article_id`),
  CONSTRAINT `collection_article_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collection_article_collection_id_foreign` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_article`
--

LOCK TABLES `collection_article` WRITE;
/*!40000 ALTER TABLE `collection_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `collections_user_id_foreign` (`user_id`),
  CONSTRAINT `collections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_reports`
--

DROP TABLE IF EXISTS `comment_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_reports_comment_id_user_id_unique` (`comment_id`,`user_id`),
  KEY `comment_reports_user_id_foreign` (`user_id`),
  CONSTRAINT `comment_reports_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_reports`
--

LOCK TABLES `comment_reports` WRITE;
/*!40000 ALTER TABLE `comment_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_votes`
--

DROP TABLE IF EXISTS `comment_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `value` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_votes_comment_id_user_id_unique` (`comment_id`,`user_id`),
  KEY `comment_votes_user_id_foreign` (`user_id`),
  CONSTRAINT `comment_votes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_votes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_votes`
--

LOCK TABLES `comment_votes` WRITE;
/*!40000 ALTER TABLE `comment_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '0',
  `replies_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_id_foreign` (`user_id`),
  KEY `comments_article_id_foreign` (`article_id`),
  KEY `comments_parent_id_foreign` (`parent_id`),
  CONSTRAINT `comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,309,18,NULL,'chào ae',0,1,'2026-06-07 21:33:20','2026-06-10 21:07:09'),(2,309,18,1,'chào người ae',0,0,'2026-06-07 22:02:18','2026-06-07 22:02:18'),(3,309,26,NULL,'ádasd',0,0,'2026-06-10 21:10:17','2026-06-10 21:10:17');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Trung Quốc','Chinese',1,'2026-06-17 20:49:07','2026-06-17 20:49:07'),(2,'Nhật Bản','Japanese',2,'2026-06-17 20:49:07','2026-06-17 20:49:07'),(3,'Hàn Quốc','Korean',3,'2026-06-17 20:49:07','2026-06-17 20:49:07'),(4,'Việt Nam','Vietnamese',4,'2026-06-17 20:49:07','2026-06-17 20:49:07'),(5,'Âu - Mỹ','Western',5,'2026-06-17 20:49:07','2026-06-17 20:49:07'),(6,'Khác','Other',99,'2026-06-17 20:49:07','2026-06-17 20:49:07');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_packages`
--

DROP TABLE IF EXISTS `credit_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'credit',
  `coins` int unsigned NOT NULL,
  `subscription_days` smallint unsigned NOT NULL DEFAULT '0',
  `daily_credits` int unsigned NOT NULL DEFAULT '0',
  `price_vnd` int unsigned NOT NULL,
  `price_usd` decimal(8,2) NOT NULL DEFAULT '0.00',
  `price_display` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_packages`
--

LOCK TABLES `credit_packages` WRITE;
/*!40000 ALTER TABLE `credit_packages` DISABLE KEYS */;
INSERT INTO `credit_packages` VALUES (1,'Gói Cơ bản','credit',500,0,0,50000,5.00,'50.000đ','media/payments/500_xKtb4nU.jpg',0,1,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(2,'Gói Mọt sách','credit',1000,0,0,100000,10.00,'100.000đ','media/payments/1000.jpg',0,2,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(3,'Gói Tường thuật','credit',2100,0,0,200000,20.00,'200.000đ','media/payments/2100.jpg',1,3,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(4,'Gói Phê bình','credit',4450,0,0,400000,40.00,'400.000đ','media/payments/4450.jpg',0,4,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(5,'Gói Tuyệt vời','credit',8500,0,0,700000,70.00,'700.000đ','media/payments/8500.jpg',0,5,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(6,'Gói Hoàng gia','credit',12500,0,0,1000000,100.00,'1.000.000đ','media/payments/12500.jpg',0,6,1,'2026-06-06 18:17:00','2026-06-06 18:17:00'),(7,'Thành viên Premium','subscription',30,30,5,0,30.00,'',NULL,0,0,1,'2026-06-08 21:39:52','2026-06-08 21:39:52');
/*!40000 ALTER TABLE `credit_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sepay',
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deposits_transaction_id_unique` (`transaction_id`),
  KEY `deposits_user_id_foreign` (`user_id`),
  CONSTRAINT `deposits_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES (1,309,5.00,'paypal','1WP05962WW3587533','completed','02N17643VR990672W','PayPal: Gói Cơ bản (500 xu)','2026-06-06 22:59:23','2026-06-06 22:59:23'),(2,309,30.00,'paypal','5RJ81542LA6153040','completed','5UY9401688857650K','PayPal: Thành viên Premium (subscription 30 days, 5 credits/day)','2026-06-08 21:41:48','2026-06-08 21:41:48');
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_articles`
--

DROP TABLE IF EXISTS `faq_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_vi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_vi` longtext COLLATE utf8mb4_unicode_ci,
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` bigint unsigned NOT NULL DEFAULT '0',
  `comment_count` int unsigned NOT NULL DEFAULT '0',
  `comments_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faq_articles_category_id_slug_unique` (`category_id`,`slug`),
  KEY `faq_articles_slug_index` (`slug`),
  KEY `faq_articles_is_pinned_index` (`is_pinned`),
  KEY `faq_articles_is_active_index` (`is_active`),
  CONSTRAINT `faq_articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_articles`
--

LOCK TABLES `faq_articles` WRITE;
/*!40000 ALTER TABLE `faq_articles` DISABLE KEYS */;
INSERT INTO `faq_articles` VALUES (1,1,'google-password','How can I find out my login password after registering via Google?','Làm sao biết mật khẩu sau khi đăng ký bằng Google?','<p>If you registered via Google, use the password reset flow with the same email address to create a local password.</p>','<p>Nếu bạn đăng ký bằng Google, hãy dùng chức năng quên mật khẩu với cùng email để tạo mật khẩu đăng nhập nội bộ.</p>',0,4,0,1,1,10,'2026-06-09 15:50:49','2026-06-09 19:04:28'),(2,2,'contact-moderator','How can I contact a moderator or an administrator?','Làm sao liên hệ moderator hoặc quản trị viên?','<p>Please use the feedback page or the related discussion thread if you need support.</p>','<p>Vui lòng dùng trang góp ý hoặc chủ đề thảo luận liên quan nếu bạn cần hỗ trợ.</p>',0,3,0,1,1,10,'2026-06-09 15:50:49','2026-06-09 19:04:31');
/*!40000 ALTER TABLE `faq_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_categories`
--

DROP TABLE IF EXISTS `faq_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_vi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `description_vi` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fa-circle-question',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faq_categories_slug_unique` (`slug`),
  KEY `faq_categories_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_categories`
--

LOCK TABLES `faq_categories` WRITE;
/*!40000 ALTER TABLE `faq_categories` DISABLE KEYS */;
INSERT INTO `faq_categories` VALUES (1,'account','Account','Tài khoản',NULL,NULL,'fa-circle-question',10,1,'2026-06-09 15:50:49','2026-06-09 19:03:23'),(2,'general','General','Chung','General website questions.','Các câu hỏi chung về website.','fa-circle-question',20,1,'2026-06-09 15:50:49','2026-06-09 15:50:49');
/*!40000 ALTER TABLE `faq_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_comment_votes`
--

DROP TABLE IF EXISTS `faq_comment_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_comment_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `value` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faq_comment_votes_comment_id_user_id_unique` (`comment_id`,`user_id`),
  KEY `faq_comment_votes_user_id_foreign` (`user_id`),
  CONSTRAINT `faq_comment_votes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `faq_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `faq_comment_votes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_comment_votes`
--

LOCK TABLES `faq_comment_votes` WRITE;
/*!40000 ALTER TABLE `faq_comment_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_comment_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_comments`
--

DROP TABLE IF EXISTS `faq_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `article_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '0',
  `reply_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faq_comments_user_id_foreign` (`user_id`),
  KEY `faq_comments_parent_id_foreign` (`parent_id`),
  KEY `faq_comments_article_id_created_at_index` (`article_id`,`created_at`),
  CONSTRAINT `faq_comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `faq_articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `faq_comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `faq_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `faq_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_comments`
--

LOCK TABLES `faq_comments` WRITE;
/*!40000 ALTER TABLE `faq_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_settings`
--

DROP TABLE IF EXISTS `faq_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faq_settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_settings`
--

LOCK TABLES `faq_settings` WRITE;
/*!40000 ALTER TABLE `faq_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_categories`
--

DROP TABLE IF EXISTS `forum_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_vi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `description_vi` text COLLATE utf8mb4_unicode_ci,
  `section_label_en` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `section_label_vi` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fa-comments',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_categories_slug_unique` (`slug`),
  KEY `forum_categories_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_categories`
--

LOCK TABLES `forum_categories` WRITE;
/*!40000 ALTER TABLE `forum_categories` DISABLE KEYS */;
INSERT INTO `forum_categories` VALUES (1,'news-and-announcements','News and Announcements','Tin tức và thông báo','Stay up to date with the latest news about our website updates!','Theo dõi các cập nhật mới nhất của website.','DEVELOPERS\' INFORMATION','THÔNG TIN TỪ BAN QUẢN TRỊ','fa-comments',10,1,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(2,'bugs-and-issues','Bugs and Issues','Lỗi và sự cố','Problems, bugs and errors related to the site','Báo lỗi, sự cố và các vấn đề liên quan đến website.','DEVELOPERS\' INFORMATION','THÔNG TIN TỪ BAN QUẢN TRỊ','fa-comments',20,1,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(3,'communication','Communication','Trò chuyện','Just talking with our whole family','Không gian trao đổi chung của cộng đồng.','GENERAL','CHUNG','fa-comments',30,1,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(4,'team-recruitment','Team Recruitment','Tuyển thành viên','Search for members to join the team of translators','Tìm thành viên tham gia các nhóm dịch.','GENERAL','CHUNG','fa-comments',40,1,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(5,'articles','Articles','Bài viết','Interesting news from the world of light novels','Tin tức thú vị về light novel và cộng đồng đọc truyện.','GENERAL','CHUNG','fa-comments',50,1,'2026-06-09 15:50:49','2026-06-09 15:50:49');
/*!40000 ALTER TABLE `forum_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_comment_votes`
--

DROP TABLE IF EXISTS `forum_comment_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_comment_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `value` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_comment_votes_comment_id_user_id_unique` (`comment_id`,`user_id`),
  KEY `forum_comment_votes_user_id_foreign` (`user_id`),
  CONSTRAINT `forum_comment_votes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `forum_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forum_comment_votes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_comment_votes`
--

LOCK TABLES `forum_comment_votes` WRITE;
/*!40000 ALTER TABLE `forum_comment_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_comment_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_comments`
--

DROP TABLE IF EXISTS `forum_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '0',
  `reply_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_comments_user_id_foreign` (`user_id`),
  KEY `forum_comments_parent_id_foreign` (`parent_id`),
  KEY `forum_comments_post_id_created_at_index` (`post_id`,`created_at`),
  CONSTRAINT `forum_comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `forum_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forum_comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `forum_posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forum_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_comments`
--

LOCK TABLES `forum_comments` WRITE;
/*!40000 ALTER TABLE `forum_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_posts`
--

DROP TABLE IF EXISTS `forum_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_vi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_en` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_vi` longtext COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` bigint unsigned NOT NULL DEFAULT '0',
  `comment_count` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_posts_category_id_slug_unique` (`category_id`,`slug`),
  KEY `forum_posts_user_id_foreign` (`user_id`),
  KEY `forum_posts_slug_index` (`slug`),
  KEY `forum_posts_status_index` (`status`),
  KEY `forum_posts_is_pinned_index` (`is_pinned`),
  KEY `forum_posts_is_active_index` (`is_active`),
  CONSTRAINT `forum_posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `forum_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forum_posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_posts`
--

LOCK TABLES `forum_posts` WRITE;
/*!40000 ALTER TABLE `forum_posts` DISABLE KEYS */;
INSERT INTO `forum_posts` VALUES (1,1,NULL,'a-book-is-gone-read-this-first','A book is GONE? Read this first!','Không thấy truyện? Đọc bài này trước!','<p><strong>Hello!</strong></p><p>As you know, books can sometimes disappear from the platform for various reasons. Before reporting a book as missing, please try searching for the book title and checking the Chapters section first.</p><p><em>P.S. Please do not advertise other websites here.</em></p>','<p><strong>Xin chào!</strong></p><p>Một số truyện có thể tạm biến mất vì nhiều lý do. Trước khi báo thiếu truyện, vui lòng thử tìm lại tên truyện và kiểm tra mục Chapters trước.</p><p><em>Lưu ý: vui lòng không quảng cáo website khác tại đây.</em></p>','approved',1,0,2,0,1,'2026-06-09 15:50:49','2026-06-09 16:43:06'),(2,1,NULL,'introducing-the-premium-pack','Introducing the Premium Pack!','Giới thiệu gói Premium!','<p>Premium Pack information and update notes can be managed from this admin page.</p>','<p>Thông tin gói Premium và các ghi chú cập nhật có thể quản trị tại trang này.</p>','approved',1,0,0,0,1,'2026-06-09 15:50:49','2026-06-09 15:50:49');
/*!40000 ALTER TABLE `forum_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_settings`
--

DROP TABLE IF EXISTS `forum_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_settings`
--

LOCK TABLES `forum_settings` WRITE;
/*!40000 ALTER TABLE `forum_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genres` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `genres_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES (1,'Fantasy',NULL,NULL),(2,'Comedy',NULL,NULL),(3,'Action',NULL,NULL),(4,'Romance',NULL,NULL),(5,'Adventure',NULL,NULL),(6,'Slice of Life',NULL,NULL),(7,'Sci-Fi',NULL,NULL),(8,'Mecha',NULL,NULL),(9,'Supernatural',NULL,NULL),(10,'Mystery',NULL,NULL),(11,'Drama',NULL,NULL),(12,'Mature',NULL,NULL),(13,'Yaoi',NULL,NULL),(14,'Adult',NULL,NULL),(15,'Harem',NULL,NULL),(16,'Psychological',NULL,NULL),(17,'Seinen',NULL,NULL),(18,'Shoujo',NULL,NULL),(19,'Tragedy',NULL,NULL),(20,'School Life',NULL,NULL),(21,'Wuxia',NULL,NULL),(22,'Martial Arts',NULL,NULL),(23,'Ecchi',NULL,NULL),(24,'Shounen',NULL,NULL);
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_items_parent_id_foreign` (`parent_id`),
  KEY `menu_items_menu_id_parent_id_order_index` (`menu_id`,`parent_id`,`order`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,16,NULL,'Home','messages.nav.home','/','fa fa-home','_self',0,1,'2026-06-04 14:40:13','2026-06-09 18:16:49'),(2,16,NULL,'Browse','messages.nav.browse','#browse','fa fa-layer-group','_self',1,1,'2026-06-04 14:40:13','2026-06-09 18:16:49'),(3,16,NULL,'Search','messages.nav.search','#search','fa fa-search','_self',2,1,'2026-06-04 14:40:13','2026-06-09 18:16:49'),(6,17,NULL,'Home','messages.nav.home','/','fa fa-home','_self',1,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(7,17,NULL,'Browse','messages.nav.browse','#browse','fa fa-layer-group','_self',2,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(8,17,NULL,'Latest','messages.nav.new','/moi-cap-nhat','fa fa-bolt','_self',3,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(9,17,NULL,'Completed','messages.nav.completed','/da-hoan-thanh','fa fa-check-circle','_self',4,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(10,18,NULL,'Feedback','messages.footer.feedback','/feedback',NULL,'_self',1,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(11,18,NULL,'Terms of Use','messages.footer.terms','/terms',NULL,'_self',2,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(12,18,NULL,'DMCA','messages.footer.dmca','/dmca',NULL,'_self',3,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(13,18,NULL,'Rules','messages.footer.rules','/rules',NULL,'_self',4,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(14,18,NULL,'FAQ','messages.footer.faq','/faq',NULL,'_self',5,1,'2026-06-04 14:40:13','2026-06-04 14:40:13'),(18,16,NULL,'FAQ',NULL,'/faq','','_self',4,1,'2026-06-09 18:16:43','2026-06-09 18:16:49'),(19,16,NULL,'Forum',NULL,'/forum','','_self',3,1,'2026-06-09 18:16:43','2026-06-09 18:16:49');
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_name_unique` (`name`),
  UNIQUE KEY `menus_location_unique` (`location`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (16,'header','Header chính','2026-06-04 14:40:13','2026-06-04 14:40:13'),(17,'mobile','Menu mobile','2026-06-04 14:40:13','2026-06-04 14:40:13'),(18,'footer','Footer','2026-06-04 14:40:13','2026-06-04 14:40:13'),(19,'browse','Dropdown Browse','2026-06-04 14:40:13','2026-06-04 14:40:13');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2024_04_01_114538_create_authors_table',1),(6,'2024_04_01_114538_create_genres_table',1),(7,'2024_04_01_114540_create_menus_table',1),(8,'2024_04_02_114635_create_articles_table',1),(9,'2024_04_12_114538_create_chapters_table',1),(10,'2024_04_12_114539_create_articles_authors_table',1),(11,'2024_04_12_114539_create_articles_genres_table',1),(12,'2024_04_12_114539_create_bookmarks_table',1),(13,'2024_04_12_114539_create_comments_table',1),(15,'2024_04_15_143402_add_column_to_users_table',2),(17,'2024_04_16_103920_add_column_to_articles_table',3),(19,'2024_04_16_104935_create_banned_users_table',4),(20,'2024_05_22_192724_add_column_to_users_table',5),(21,'2025_07_03_130513_create_sepay_table',6),(22,'2025_07_03_150454_create_deposits_table',6),(23,'2025_07_04_151533_add_affi_columns_to_articles_table',6),(24,'2025_07_04_223447_add_points_to_users_table',6),(25,'2025_07_06_161838_create_settings_table',6),(26,'2025_07_06_161858_create_user_vips_table',6),(27,'2025_07_07_163940_create_affiliate_links_table',6),(28,'2026_06_03_152701_add_novelight_fields_to_articles_and_genres',7),(29,'2026_06_03_223814_add_background_to_users',8),(30,'2026_06_03_233325_add_google_id_to_users',9),(31,'2026_06_04_091157_create_community_entities',10),(32,'2026_06_04_113618_create_seo_settings_table',11),(33,'2026_06_04_115034_create_seo_metas_table',12),(34,'2026_06_04_000001_add_comment_features',13),(35,'2026_06_04_010001_create_menus_tables',14),(36,'2026_06_04_010002_restructure_menus_table',15),(37,'2026_06_05_000001_add_article_detail_block_settings_to_articles',16),(38,'2026_06_05_100000_create_ads_table',17),(39,'2026_06_05_110000_add_after_click_to_ads_table',18),(40,'2026_06_06_100000_create_credit_packages_table',19),(41,'2026_06_06_120000_create_reading_histories_table',20),(42,'2026_06_08_000001_add_subscription_fields_to_credit_packages_table',21),(43,'2026_06_08_000002_add_daily_credit_tracking_to_user_vips_table',21),(44,'2026_06_08_100000_add_credit_settings_to_articles',21),(45,'2026_06_08_100001_add_credit_cost_to_chapters',21),(46,'2026_06_08_100002_create_chapter_unlocks_table',21),(47,'2026_06_08_000003_create_slugs_table',22),(48,'2026_06_09_000001_create_static_pages_table',23),(49,'2026_06_09_000002_extend_static_pages_for_blog',24),(50,'2026_06_09_000003_seed_static_blog_pages',25),(51,'2026_06_09_100000_add_status_to_static_pages',26),(52,'2026_06_09_110000_add_section_label_to_static_pages',26),(53,'2026_06_09_120000_create_forum_tables',27),(54,'2026_06_09_120001_create_faq_tables',27),(55,'2026_06_09_120002_migrate_data_from_static_pages_to_forum_faq',27),(56,'2026_06_10_000001_add_status_to_bookmarks',28),(57,'2026_06_10_000002_add_inline_config_to_ads_and_create_ad_items',29),(58,'2026_06_10_000003_create_chapter_bookmarks_and_reports',30),(60,'2026_06_10_000005_create_chapter_likes',31),(61,'2026_06_10_000006_create_payment_settings',32),(62,'2026_06_12_000001_add_published_at_to_chapters',33),(63,'2026_06_14_000001_make_user_description_nullable',34),(64,'2026_06_15_000001_add_is_user_submitted_to_articles',35),(65,'2026_06_15_000002_create_notifications_and_chapter_notified',36),(66,'2026_06_17_000001_create_countries_table',37),(67,'2026_06_18_000001_create_achievements_tables',38),(68,'2026_06_19_001159_create_team_members_table',39),(69,'2026_06_19_001204_add_team_id_to_articles_table',39),(70,'2026_06_19_003100_update_team_members_role_enum',40),(71,'2026_06_19_020000_add_status_to_teams_table',41);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('lxq.2309@gmail.com','$2y$12$92KZtjNfNF1sBk/0wQiJqewVWLkDvlZ1Sc.9SsEiUSQXp/7SbAYq.','2024-05-01 00:37:00');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_settings`
--

DROP TABLE IF EXISTS `payment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `paypal_mode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `paypal_sandbox_client_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_live_client_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_sandbox_secret` text COLLATE utf8mb4_unicode_ci,
  `paypal_sandbox_webhook_id` text COLLATE utf8mb4_unicode_ci,
  `paypal_live_secret` text COLLATE utf8mb4_unicode_ci,
  `paypal_live_webhook_id` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_settings`
--

LOCK TABLES `payment_settings` WRITE;
/*!40000 ALTER TABLE `payment_settings` DISABLE KEYS */;
INSERT INTO `payment_settings` VALUES (2,'sandbox',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-11 00:10:41','2026-06-11 00:10:41');
/*!40000 ALTER TABLE `payment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_histories`
--

DROP TABLE IF EXISTS `reading_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reading_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `article_id` bigint unsigned NOT NULL,
  `chapter_id` bigint unsigned NOT NULL,
  `chapter_number` int unsigned NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reading_histories_user_id_chapter_id_unique` (`user_id`,`chapter_id`),
  KEY `reading_histories_article_id_foreign` (`article_id`),
  KEY `reading_histories_chapter_id_foreign` (`chapter_id`),
  KEY `reading_histories_user_id_article_id_index` (`user_id`,`article_id`),
  KEY `reading_histories_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `reading_histories_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reading_histories_chapter_id_foreign` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reading_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_histories`
--

LOCK TABLES `reading_histories` WRITE;
/*!40000 ALTER TABLE `reading_histories` DISABLE KEYS */;
INSERT INTO `reading_histories` VALUES (1,309,30,296,10,'2026-06-09 18:59:32','2026-06-08 21:54:15','2026-06-09 18:59:32'),(2,309,30,292,6,'2026-06-12 13:51:13','2026-06-09 18:57:48','2026-06-12 13:51:13'),(3,309,30,293,7,'2026-06-12 13:50:34','2026-06-09 18:57:51','2026-06-12 13:50:34'),(4,309,30,294,8,'2026-06-09 18:59:30','2026-06-09 18:57:53','2026-06-09 18:59:30'),(5,309,30,290,4,'2026-06-12 13:51:19','2026-06-09 18:59:25','2026-06-12 13:51:19'),(6,309,30,291,5,'2026-06-12 13:51:17','2026-06-09 18:59:27','2026-06-12 13:51:17'),(7,309,30,295,9,'2026-06-09 18:59:31','2026-06-09 18:59:31','2026-06-09 18:59:31'),(8,309,26,247,1,'2026-06-10 21:10:13','2026-06-10 21:10:03','2026-06-10 21:10:13'),(9,309,26,248,2,'2026-06-10 21:10:16','2026-06-10 21:10:09','2026-06-10 21:10:16'),(10,309,26,249,3,'2026-06-10 22:37:48','2026-06-10 21:10:12','2026-06-10 22:37:48'),(11,309,26,250,4,'2026-06-10 21:10:17','2026-06-10 21:10:16','2026-06-10 21:10:17'),(12,309,21,197,1,'2026-06-10 23:32:22','2026-06-10 22:54:51','2026-06-10 23:32:22'),(13,309,30,288,2,'2026-06-12 14:16:07','2026-06-12 13:40:52','2026-06-12 14:16:07'),(14,309,30,289,3,'2026-06-12 13:51:20','2026-06-12 13:50:29','2026-06-12 13:51:20');
/*!40000 ALTER TABLE `reading_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_metas`
--

DROP TABLE IF EXISTS `seo_metas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_metas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `seoable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seoable_id` bigint unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `canonical_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `noindex` tinyint(1) NOT NULL DEFAULT '0',
  `nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `focus_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_score` tinyint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_metas_seoable_type_seoable_id_index` (`seoable_type`,`seoable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_metas`
--

LOCK TABLES `seo_metas` WRITE;
/*!40000 ALTER TABLE `seo_metas` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_metas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_settings`
--

DROP TABLE IF EXISTS `seo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_settings`
--

LOCK TABLES `seo_settings` WRITE;
/*!40000 ALTER TABLE `seo_settings` DISABLE KEYS */;
INSERT INTO `seo_settings` VALUES (1,'site_name','Truyen Tranh','general','2026-06-04 11:37:38','2026-06-04 11:37:38'),(2,'title_separator',' · ','general','2026-06-04 11:37:38','2026-06-04 11:37:38'),(3,'default_description','Đọc truyện online: light novel, web novel, ngôn tình, tiên hiệp. Cập nhật nhanh nhất.','general','2026-06-04 11:37:38','2026-06-04 11:37:38'),(4,'default_keywords','đọc truyện, light novel, web novel, truyện online','general','2026-06-04 11:37:38','2026-06-04 11:37:38'),(5,'default_og_image','/static/core/images/no_cover.webp','general','2026-06-04 11:37:38','2026-06-04 11:37:38'),(6,'og_locale','vi_VN','social','2026-06-04 11:37:38','2026-06-04 11:37:38'),(7,'facebook_page_url','','social','2026-06-04 11:37:38','2026-06-04 11:37:38'),(8,'facebook_app_id','','social','2026-06-04 11:37:38','2026-06-04 11:37:38'),(9,'twitter_username','','social','2026-06-04 11:37:38','2026-06-04 11:37:38'),(10,'google_analytics_id','','advanced','2026-06-04 11:37:38','2026-06-04 11:37:38'),(11,'google_tag_manager','','advanced','2026-06-04 11:37:38','2026-06-04 11:37:38'),(12,'google_site_verify','','advanced','2026-06-04 11:37:38','2026-06-04 11:37:38'),(13,'bing_site_verify','','advanced','2026-06-04 11:37:38','2026-06-04 11:37:38'),(14,'robots_txt_extra','','advanced','2026-06-04 11:37:38','2026-06-04 11:37:38');
/*!40000 ALTER TABLE `seo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sepay_transactions`
--

DROP TABLE IF EXISTS `sepay_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sepay_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gateway` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transactionDate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subAccount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transferType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transferAmount` bigint NOT NULL,
  `referenceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sepay_transactions`
--

LOCK TABLES `sepay_transactions` WRITE;
/*!40000 ALTER TABLE `sepay_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sepay_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_meta_key_unique` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (8,'chapter_footer_text1','Chapter written by',NULL,NULL),(9,'chapter_footer_text2','SITE',NULL,NULL),(10,'chapter_footer_link','https://inet.vn/',NULL,NULL),(11,'bank1_account_name',NULL,NULL,NULL),(12,'bank1_account_number',NULL,NULL,NULL),(13,'bank1_name',NULL,NULL,NULL),(17,'page_forum_title_en',NULL,NULL,NULL),(18,'page_forum_content_en',NULL,NULL,NULL),(19,'page_faq_title_en',NULL,NULL,NULL),(20,'page_faq_content_en',NULL,NULL,NULL),(21,'page_faq_account_title_en',NULL,NULL,NULL),(22,'page_faq_account_content_en',NULL,NULL,NULL),(23,'page_faq_general_title_en',NULL,NULL,NULL),(24,'page_faq_general_content_en',NULL,NULL,NULL),(25,'page_rules_title_en',NULL,NULL,NULL),(26,'page_rules_content_en',NULL,NULL,NULL),(27,'page_forum_title_vi',NULL,NULL,NULL),(28,'page_forum_content_vi',NULL,NULL,NULL),(29,'page_faq_title_vi',NULL,NULL,NULL),(30,'page_faq_content_vi',NULL,NULL,NULL),(31,'page_faq_account_title_vi',NULL,NULL,NULL),(32,'page_faq_account_content_vi',NULL,NULL,NULL),(33,'page_faq_general_title_vi',NULL,NULL,NULL),(34,'page_faq_general_content_vi',NULL,NULL,NULL),(35,'page_rules_title_vi',NULL,NULL,NULL),(36,'page_rules_content_vi',NULL,NULL,NULL),(37,'chapter_footer_image','chapter_footer/9FyZlmkR5lUWELhQ4kEepNuS2j44BFpxs8yVzgUx.jpg',NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slugs`
--

DROP TABLE IF EXISTS `slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slugs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sluggable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sluggable_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slugs_type_slug_unique` (`type`,`slug`),
  UNIQUE KEY `slugs_type_model_unique` (`type`,`sluggable_type`,`sluggable_id`),
  KEY `slugs_sluggable_type_sluggable_id_index` (`sluggable_type`,`sluggable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slugs`
--

LOCK TABLES `slugs` WRITE;
/*!40000 ALTER TABLE `slugs` DISABLE KEYS */;
INSERT INTO `slugs` VALUES (1,'article','00000001-demon-king','App\\Models\\Article',1,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(2,'article','12-oclock-marionette','App\\Models\\Article',2,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(3,'article','30-years-have-passed-since-the-prologue','App\\Models\\Article',3,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(4,'article','86-eighty-six-light-novel','App\\Models\\Article',4,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(5,'article','a-destiny-that-must-die','App\\Models\\Article',5,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(6,'article','a-former-gangster-bosss-possession-of-a-housekeeper-in-an-r-19-novel','App\\Models\\Article',6,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(7,'article','a-fortune-telling-princess','App\\Models\\Article',7,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(8,'article','a-knight-who-eternally-regresses','App\\Models\\Article',8,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(9,'article','a-letter-from-keanu-reeves','App\\Models\\Article',9,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(10,'article','a-mastermind-no-im-just-the-live-in-son-in-law','App\\Models\\Article',10,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(11,'article','a-painting-of-the-villainess-as-a-young-lady','App\\Models\\Article',11,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(12,'article','a-practical-guide-to-evil','App\\Models\\Article',12,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(13,'article','a-secretly-capable-child-is-seeking-for-her-dad','App\\Models\\Article',13,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(14,'article','a-transmigrators-privilege','App\\Models\\Article',14,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(15,'article','a-villain-but-not-a-villain','App\\Models\\Article',15,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(16,'article','a-wicked-husband','App\\Models\\Article',16,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(17,'article','a-wimps-strategy-guide-to-conquer-the-tower','App\\Models\\Article',17,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(18,'article','a-witch-lives-in-geppettos-doll-workshop','App\\Models\\Article',18,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(19,'article','a-wizards-farming-life-in-another-world','App\\Models\\Article',19,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(20,'article','absolute-regression','App\\Models\\Article',20,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(21,'article','academys-undercover-professor-light-novel','App\\Models\\Article',21,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(22,'article','accidental-baby','App\\Models\\Article',22,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(23,'article','acidic-scent-light-novel','App\\Models\\Article',23,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(24,'article','adopting-disaster','App\\Models\\Article',24,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(25,'article','affinitychaos','App\\Models\\Article',25,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(26,'article','after-having-babies-with-my-wives-in-a-dream-they-all-came-true','App\\Models\\Article',26,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(27,'article','after-leaving-the-a-rank-party-i-aim-for-the-deep-part-of-the-labyrinth-with-my-former-students-light-novel','App\\Models\\Article',27,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(28,'article','after-rebirth-the-real-young-master-began-to-maintain-his-health','App\\Models\\Article',28,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(29,'article','after-the-99th-confession-the-cold-school-beautys-personality-collapsed','App\\Models\\Article',29,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(30,'article','after-the-secrets-of-the-passerby-were-leaked-he-was-cherished-by-the-entire-family-of-antagonists','App\\Models\\Article',30,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(31,'genre','fantasy','App\\Models\\Genre',1,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(32,'genre','comedy','App\\Models\\Genre',2,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(33,'genre','action','App\\Models\\Genre',3,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(34,'genre','romance','App\\Models\\Genre',4,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(35,'genre','adventure','App\\Models\\Genre',5,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(36,'genre','slice-of-life','App\\Models\\Genre',6,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(37,'genre','sci-fi','App\\Models\\Genre',7,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(38,'genre','mecha','App\\Models\\Genre',8,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(39,'genre','supernatural','App\\Models\\Genre',9,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(40,'genre','mystery','App\\Models\\Genre',10,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(41,'genre','drama','App\\Models\\Genre',11,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(42,'genre','mature','App\\Models\\Genre',12,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(43,'genre','yaoi','App\\Models\\Genre',13,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(44,'genre','adult','App\\Models\\Genre',14,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(45,'genre','harem','App\\Models\\Genre',15,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(46,'genre','psychological','App\\Models\\Genre',16,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(47,'genre','seinen','App\\Models\\Genre',17,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(48,'genre','shoujo','App\\Models\\Genre',18,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(49,'genre','tragedy','App\\Models\\Genre',19,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(50,'genre','school-life','App\\Models\\Genre',20,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(51,'genre','wuxia','App\\Models\\Genre',21,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(52,'genre','martial-arts','App\\Models\\Genre',22,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(53,'genre','ecchi','App\\Models\\Genre',23,'2026-06-08 22:11:03','2026-06-08 22:11:03'),(54,'genre','shounen','App\\Models\\Genre',24,'2026-06-08 22:11:03','2026-06-08 22:11:03');
/*!40000 ALTER TABLE `slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_page_comments`
--

DROP TABLE IF EXISTS `static_page_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_page_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `static_page_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `static_page_comments_static_page_id_foreign` (`static_page_id`),
  KEY `static_page_comments_user_id_foreign` (`user_id`),
  KEY `static_page_comments_parent_id_foreign` (`parent_id`),
  CONSTRAINT `static_page_comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `static_page_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `static_page_comments_static_page_id_foreign` FOREIGN KEY (`static_page_id`) REFERENCES `static_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `static_page_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_page_comments`
--

LOCK TABLES `static_page_comments` WRITE;
/*!40000 ALTER TABLE `static_page_comments` DISABLE KEYS */;
INSERT INTO `static_page_comments` VALUES (1,7,309,NULL,'oke chứ',0,'2026-06-09 17:59:14','2026-06-09 17:59:14');
/*!40000 ALTER TABLE `static_page_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_pages`
--

DROP TABLE IF EXISTS `static_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `page_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'custom',
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_vi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_en` longtext COLLATE utf8mb4_unicode_ci,
  `content_vi` longtext COLLATE utf8mb4_unicode_ci,
  `excerpt_en` text COLLATE utf8mb4_unicode_ci,
  `excerpt_vi` text COLLATE utf8mb4_unicode_ci,
  `comments_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` bigint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `section_label_en` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `section_label_vi` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `static_pages_slug_unique` (`slug`),
  KEY `static_pages_parent_id_foreign` (`parent_id`),
  KEY `static_pages_page_type_index` (`page_type`),
  KEY `static_pages_is_active_index` (`is_active`),
  KEY `static_pages_user_id_foreign` (`user_id`),
  KEY `static_pages_status_index` (`status`),
  CONSTRAINT `static_pages_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `static_pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `static_pages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_pages`
--

LOCK TABLES `static_pages` WRITE;
/*!40000 ALTER TABLE `static_pages` DISABLE KEYS */;
INSERT INTO `static_pages` VALUES (1,NULL,NULL,'forum','forum','Forum',NULL,NULL,NULL,NULL,NULL,0,0,0,1,'approved',0,NULL,NULL,'2026-06-09 15:30:55','2026-06-09 15:30:55'),(2,1,NULL,'forum_category','news-and-announcements','News and Announcements','Tin tức và thông báo',NULL,NULL,'Stay up to date with the latest news about our website updates!','Theo dõi các cập nhật mới nhất của website.',0,0,0,1,'approved',10,'DEVELOPERS\' INFORMATION','THÔNG TIN TỪ BAN QUẢN TRỊ','2026-06-09 15:50:49','2026-06-09 15:50:49'),(3,1,NULL,'forum_category','bugs-and-issues','Bugs and Issues','Lỗi và sự cố',NULL,NULL,'Problems, bugs and errors related to the site','Báo lỗi, sự cố và các vấn đề liên quan đến website.',0,0,0,1,'approved',20,'DEVELOPERS\' INFORMATION','THÔNG TIN TỪ BAN QUẢN TRỊ','2026-06-09 15:50:49','2026-06-09 15:50:49'),(4,1,NULL,'forum_category','communication','Communication','Trò chuyện',NULL,NULL,'Just talking with our whole family','Không gian trao đổi chung của cộng đồng.',0,0,0,1,'approved',30,'GENERAL','CHUNG','2026-06-09 15:50:49','2026-06-09 15:50:49'),(5,1,NULL,'forum_category','team-recruitment','Team Recruitment','Tuyển thành viên',NULL,NULL,'Search for members to join the team of translators','Tìm thành viên tham gia các nhóm dịch.',0,0,0,1,'approved',40,'GENERAL','CHUNG','2026-06-09 15:50:49','2026-06-09 15:50:49'),(6,1,NULL,'forum_category','articles','Articles','Bài viết',NULL,NULL,'Interesting news from the world of light novels','Tin tức thú vị về light novel và cộng đồng đọc truyện.',0,0,0,1,'approved',50,'GENERAL','CHUNG','2026-06-09 15:50:49','2026-06-09 15:50:49'),(7,2,NULL,'forum_post','a-book-is-gone-read-this-first','A book is GONE? Read this first!','Không thấy truyện? Đọc bài này trước!','<p><strong>Hello!</strong></p><p>As you know, books can sometimes disappear from the platform for various reasons. Before reporting a book as missing, please try searching for the book title and checking the Chapters section first.</p><p><em>P.S. Please do not advertise other websites here.</em></p>','<p><strong>Xin chào!</strong></p><p>Một số truyện có thể tạm biến mất vì nhiều lý do. Trước khi báo thiếu truyện, vui lòng thử tìm lại tên truyện và kiểm tra mục Chapters trước.</p><p><em>Lưu ý: vui lòng không quảng cáo website khác tại đây.</em></p>',NULL,NULL,1,1,4,1,'approved',10,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 17:59:15'),(8,2,NULL,'forum_post','introducing-the-premium-pack','Introducing the Premium Pack!','Giới thiệu gói Premium!','<p>Premium Pack information and update notes can be managed from this admin page.</p>','<p>Thông tin gói Premium và các ghi chú cập nhật có thể quản trị tại trang này.</p>',NULL,NULL,1,1,0,1,'approved',20,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(9,NULL,NULL,'faq','faq','Answers to frequently asked questions and problems','Câu hỏi thường gặp và các vấn đề phổ biến','','',NULL,NULL,0,0,0,1,'approved',0,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(10,9,NULL,'faq_category','account','Account','Tài khoản',NULL,NULL,'Login, registration and profile questions.','Câu hỏi về đăng nhập, đăng ký và hồ sơ.',0,0,0,1,'approved',10,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(11,9,NULL,'faq_category','general','General','Chung',NULL,NULL,'General website questions.','Các câu hỏi chung về website.',0,0,0,1,'approved',20,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(12,10,NULL,'faq_article','google-password','How can I find out my login password after registering via Google?','Làm sao biết mật khẩu sau khi đăng ký bằng Google?','<p>If you registered via Google, use the password reset flow with the same email address to create a local password.</p>','<p>Nếu bạn đăng ký bằng Google, hãy dùng chức năng quên mật khẩu với cùng email để tạo mật khẩu đăng nhập nội bộ.</p>',NULL,NULL,1,0,2,1,'approved',10,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 16:44:03'),(13,11,NULL,'faq_article','contact-moderator','How can I contact a moderator or an administrator?','Làm sao liên hệ moderator hoặc quản trị viên?','<p>Please use the feedback page or the related discussion thread if you need support.</p>','<p>Vui lòng dùng trang góp ý hoặc chủ đề thảo luận liên quan nếu bạn cần hỗ trợ.</p>',NULL,NULL,1,0,0,1,'approved',10,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49'),(14,NULL,NULL,'rules','rules','General Site Rules and Ban Reasons','Nội quy chung và lý do khóa tài khoản','<p>These rules apply to all user-generated content, including comments, avatars, profile backgrounds, and usernames.</p>','<p>Nội quy này áp dụng cho toàn bộ nội dung do người dùng tạo, bao gồm bình luận, avatar, ảnh nền hồ sơ và tên hiển thị.</p>',NULL,NULL,1,0,0,1,'approved',0,NULL,NULL,'2026-06-09 15:50:49','2026-06-09 15:50:49');
/*!40000 ALTER TABLE `static_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'Male Protagonist','2026-06-07 21:29:45','2026-06-07 21:29:45'),(2,'Monsters','2026-06-07 21:29:45','2026-06-07 21:29:45'),(3,'Special Abilities','2026-06-07 21:29:45','2026-06-07 21:29:45'),(4,'Comedic Undertone','2026-06-07 21:29:45','2026-06-07 21:29:45'),(5,'Demons','2026-06-07 21:29:45','2026-06-07 21:29:45'),(6,'Weak to Strong','2026-06-07 21:29:45','2026-06-07 21:29:45'),(7,'Demon Lord','2026-06-07 21:29:45','2026-06-07 21:29:45'),(8,'Fantasy Creatures','2026-06-07 21:29:45','2026-06-07 21:29:45'),(9,'Lottery','2026-06-07 21:29:45','2026-06-07 21:29:45'),(10,'Magical Technology','2026-06-07 21:29:45','2026-06-07 21:29:45'),(11,'Succubus','2026-06-07 21:29:45','2026-06-07 21:29:45'),(12,'Transmigration','2026-06-07 21:29:46','2026-06-07 21:29:46'),(13,'Magic','2026-06-07 21:29:46','2026-06-07 21:29:46'),(14,'Family Conflict','2026-06-07 21:29:46','2026-06-07 21:29:46'),(15,'Handsome Male Lead','2026-06-07 21:29:46','2026-06-07 21:29:46'),(16,'Female Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(17,'Nobles','2026-06-07 21:29:46','2026-06-07 21:29:46'),(18,'Time Skip','2026-06-07 21:29:46','2026-06-07 21:29:46'),(19,'Contracts','2026-06-07 21:29:46','2026-06-07 21:29:46'),(20,'Alchemy','2026-06-07 21:29:46','2026-06-07 21:29:46'),(21,'Gods','2026-06-07 21:29:46','2026-06-07 21:29:46'),(22,'Revenge','2026-06-07 21:29:46','2026-06-07 21:29:46'),(23,'Multiple POV','2026-06-07 21:29:46','2026-06-07 21:29:46'),(24,'European Ambience','2026-06-07 21:29:46','2026-06-07 21:29:46'),(25,'Couple Growth','2026-06-07 21:29:46','2026-06-07 21:29:46'),(26,'Childhood Love','2026-06-07 21:29:46','2026-06-07 21:29:46'),(27,'Summoning Magic','2026-06-07 21:29:46','2026-06-07 21:29:46'),(28,'Magic Beasts','2026-06-07 21:29:46','2026-06-07 21:29:46'),(29,'Power Couple','2026-06-07 21:29:46','2026-06-07 21:29:46'),(30,'Adopted Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(31,'Divine Protection','2026-06-07 21:29:46','2026-06-07 21:29:46'),(32,'Saving the World','2026-06-07 21:29:46','2026-06-07 21:29:46'),(33,'Overpowered Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(34,'Religions','2026-06-07 21:29:46','2026-06-07 21:29:46'),(35,'Kind Love Interests','2026-06-07 21:29:46','2026-06-07 21:29:46'),(36,'Mind Control','2026-06-07 21:29:46','2026-06-07 21:29:46'),(37,'Complex Family Relationships','2026-06-07 21:29:46','2026-06-07 21:29:46'),(38,'Beautiful Female Lead','2026-06-07 21:29:46','2026-06-07 21:29:46'),(39,'Necromancer','2026-06-07 21:29:46','2026-06-07 21:29:46'),(40,'Saints','2026-06-07 21:29:46','2026-06-07 21:29:46'),(41,'Evil Gods','2026-06-07 21:29:46','2026-06-07 21:29:46'),(42,'Godly Powers','2026-06-07 21:29:46','2026-06-07 21:29:46'),(43,'Protagonist with Multiple Bodies','2026-06-07 21:29:46','2026-06-07 21:29:46'),(44,'Adapted to Manhwa','2026-06-07 21:29:46','2026-06-07 21:29:46'),(45,'Coma','2026-06-07 21:29:46','2026-06-07 21:29:46'),(46,'Mystery','2026-06-07 21:29:46','2026-06-07 21:29:46'),(47,'Harem','2026-06-07 21:29:46','2026-06-07 21:29:46'),(48,'Reincarnation','2026-06-07 21:29:46','2026-06-07 21:29:46'),(49,'Determined Protagoni','2026-06-07 21:29:46','2026-06-07 21:29:46'),(50,'Past Trauma','2026-06-07 21:29:46','2026-06-07 21:29:46'),(51,'Clever Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(52,'Fantasy World','2026-06-07 21:29:46','2026-06-07 21:29:46'),(53,'Academy','2026-06-07 21:29:46','2026-06-07 21:29:46'),(54,'Royalty','2026-06-07 21:29:46','2026-06-07 21:29:46'),(55,'School Life','2026-06-07 21:29:46','2026-06-07 21:29:46'),(56,'Dragons','2026-06-07 21:29:46','2026-06-07 21:29:46'),(57,'Politics','2026-06-07 21:29:46','2026-06-07 21:29:46'),(58,'Terrorists','2026-06-07 21:29:46','2026-06-07 21:29:46'),(59,'Wars','2026-06-07 21:29:46','2026-06-07 21:29:46'),(60,'Ruthless Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(61,'Calm Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(62,'Yandere','2026-06-07 21:29:46','2026-06-07 21:29:46'),(63,'Dense Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(64,'Evil Organizations','2026-06-07 21:29:46','2026-06-07 21:29:46'),(65,'Heroes','2026-06-07 21:29:46','2026-06-07 21:29:46'),(66,'Misunderstandings','2026-06-07 21:29:46','2026-06-07 21:29:46'),(67,'Assassins','2026-06-07 21:29:46','2026-06-07 21:29:46'),(68,'Tragic Past','2026-06-07 21:29:46','2026-06-07 21:29:46'),(69,'Possession','2026-06-07 21:29:46','2026-06-07 21:29:46'),(70,'Strong to Stronger','2026-06-07 21:29:46','2026-06-07 21:29:46'),(71,'Cold Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(72,'Harsh Training','2026-06-07 21:29:46','2026-06-07 21:29:46'),(73,'Hiding True Identity','2026-06-07 21:29:46','2026-06-07 21:29:46'),(74,'Mysterious Past','2026-06-07 21:29:46','2026-06-07 21:29:46'),(75,'Organized Crime','2026-06-07 21:29:46','2026-06-07 21:29:46'),(76,'Pragmatic Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(77,'Schemes And Conspiracies','2026-06-07 21:29:46','2026-06-07 21:29:46'),(78,'Reincarnated in Another World','2026-06-07 21:29:46','2026-06-07 21:29:46'),(79,'Past Plays a Big Role','2026-06-07 21:29:46','2026-06-07 21:29:46'),(80,'Protagonist Strong from the Start','2026-06-07 21:29:46','2026-06-07 21:29:46'),(81,'Proactive Protagonist','2026-06-07 21:29:46','2026-06-07 21:29:46'),(82,'Multiple Transported Individuals','2026-06-07 21:29:46','2026-06-07 21:29:46'),(83,'Multiple Reincarnated Individuals','2026-06-07 21:29:46','2026-06-07 21:29:46'),(84,'S*aves','2026-06-07 21:29:46','2026-06-07 21:29:46'),(85,'Reincarnated in a Game World','2026-06-07 21:29:46','2026-06-07 21:29:46'),(86,'Award-winning Work','2026-06-07 21:29:46','2026-06-07 21:29:46'),(87,'Firearms','2026-06-07 21:29:46','2026-06-07 21:29:46'),(88,'Student-Teacher Relationship','2026-06-07 21:29:46','2026-06-07 21:29:46'),(89,'Military','2026-06-07 21:29:47','2026-06-07 21:29:47'),(90,'Post-apocalyptic','2026-06-07 21:29:47','2026-06-07 21:29:47'),(91,'Discrimination','2026-06-07 21:29:47','2026-06-07 21:29:47'),(92,'Guilds','2026-06-07 21:29:49','2026-06-07 21:29:49'),(93,'Psychic Powers','2026-06-07 21:29:49','2026-06-07 21:29:49'),(94,'Conditional Power','2026-06-07 21:29:49','2026-06-07 21:29:49'),(95,'Dungeons','2026-06-07 21:29:49','2026-06-07 21:29:49'),(96,'Secret Identity','2026-06-07 21:29:49','2026-06-07 21:29:49'),(97,'Destiny','2026-06-07 21:29:49','2026-06-07 21:29:49'),(98,'Secret Organizations','2026-06-07 21:29:49','2026-06-07 21:29:49'),(99,'Devoted Love Interests','2026-06-07 21:29:49','2026-06-07 21:29:49'),(100,'Near-Death Experience','2026-06-07 21:29:49','2026-06-07 21:29:49'),(101,'Possessive Characters','2026-06-07 21:29:49','2026-06-07 21:29:49'),(102,'Limited Lifespan','2026-06-07 21:29:49','2026-06-07 21:29:49'),(103,'Younger Love Interests','2026-06-07 21:29:49','2026-06-07 21:29:49'),(104,'Curses','2026-06-07 21:29:49','2026-06-07 21:29:49'),(105,'Suicides','2026-06-07 21:29:49','2026-06-07 21:29:49'),(106,'Hiding True Abilities','2026-06-07 21:29:49','2026-06-07 21:29:49'),(107,'Hunters','2026-06-07 21:29:49','2026-06-07 21:29:49'),(108,'R-15','2026-06-07 21:29:49','2026-06-07 21:29:49'),(109,'Modern Day','2026-06-07 21:29:50','2026-06-07 21:29:50'),(110,'R-18','2026-06-07 21:29:50','2026-06-07 21:29:50'),(111,'Cooking','2026-06-07 21:29:50','2026-06-07 21:29:50'),(112,'Smut','2026-06-07 21:29:50','2026-06-07 21:29:50'),(113,'Omegaverse','2026-06-07 21:29:50','2026-06-07 21:29:50'),(114,'Mob Protagonist','2026-06-07 21:29:50','2026-06-07 21:29:50'),(115,'Straight Uke','2026-06-07 21:29:50','2026-06-07 21:29:50'),(116,'Love Interest Falls in Love First','2026-06-07 21:29:50','2026-06-07 21:29:50'),(117,'Transported to Another World','2026-06-07 21:29:50','2026-06-07 21:29:50'),(118,'F*llatio','2026-06-07 21:29:50','2026-06-07 21:29:50'),(119,'Gangs','2026-06-07 21:29:50','2026-06-07 21:29:50'),(120,'Aristocracy','2026-06-07 21:29:51','2026-06-07 21:29:51'),(121,'Adopted Children','2026-06-07 21:29:51','2026-06-07 21:29:51'),(122,'Family','2026-06-07 21:29:51','2026-06-07 21:29:51'),(123,'Ghosts','2026-06-07 21:29:51','2026-06-07 21:29:51'),(124,'Siblings','2026-06-07 21:29:51','2026-06-07 21:29:51'),(125,'Seeing Things Other Humans Can\'t','2026-06-07 21:29:51','2026-06-07 21:29:51'),(126,'Sword And Magic','2026-06-07 21:29:52','2026-06-07 21:29:52'),(127,'Elves','2026-06-07 21:29:52','2026-06-07 21:29:52'),(128,'Second Chance','2026-06-07 21:29:52','2026-06-07 21:29:52'),(129,'Sword Wielder','2026-06-07 21:29:52','2026-06-07 21:29:52'),(130,'Mercenaries','2026-06-07 21:29:52','2026-06-07 21:29:52'),(131,'Army','2026-06-07 21:29:52','2026-06-07 21:29:52'),(132,'Soldiers','2026-06-07 21:29:52','2026-06-07 21:29:52'),(133,'Knights','2026-06-07 21:29:52','2026-06-07 21:29:52'),(134,'Loyal Subordinates','2026-06-07 21:29:52','2026-06-07 21:29:52'),(135,'Death','2026-06-07 21:29:52','2026-06-07 21:29:52'),(136,'Strategic Battles','2026-06-07 21:29:52','2026-06-07 21:29:52'),(137,'Hard-Working Protagonist','2026-06-07 21:29:52','2026-06-07 21:29:52'),(138,'Fearless Protagonist','2026-06-07 21:29:52','2026-06-07 21:29:52'),(139,'Time Loop','2026-06-07 21:29:52','2026-06-07 21:29:52'),(140,'Strength-based Social Hierarchy','2026-06-07 21:29:52','2026-06-07 21:29:52'),(141,'Determined Protagonist','2026-06-07 21:29:52','2026-06-07 21:29:52'),(142,'Boss-Subordinate Relationship','2026-06-07 21:29:52','2026-06-07 21:29:52'),(143,'Wealthy Characters','2026-06-07 21:29:52','2026-06-07 21:29:52'),(144,'Business Management','2026-06-07 21:29:52','2026-06-07 21:29:52'),(145,'Obsessive Love','2026-06-07 21:29:52','2026-06-07 21:29:52'),(146,'First Love','2026-06-07 21:29:52','2026-06-07 21:29:52'),(147,'Unrequited Love','2026-06-07 21:29:52','2026-06-07 21:29:52'),(148,'Adapted to Drama','2026-06-07 21:29:52','2026-06-07 21:29:52'),(149,'Tsundere','2026-06-07 21:29:52','2026-06-07 21:29:52'),(150,'Businessmen','2026-06-07 21:29:52','2026-06-07 21:29:52'),(151,'Unconditional Love','2026-06-07 21:29:52','2026-06-07 21:29:52'),(152,'Adapted to Manhua','2026-06-07 21:29:52','2026-06-07 21:29:52'),(153,'Child Abuse','2026-06-07 21:29:52','2026-06-07 21:29:52'),(154,'Doting Love Interests','2026-06-07 21:29:52','2026-06-07 21:29:52'),(155,'Depression','2026-06-07 21:29:52','2026-06-07 21:29:52'),(156,'Protagonist Falls in Love First','2026-06-07 21:29:52','2026-06-07 21:29:52'),(157,'Popular Love Interests','2026-06-07 21:29:52','2026-06-07 21:29:52'),(158,'Cold Love Interests','2026-06-07 21:29:52','2026-06-07 21:29:52'),(159,'Different Social Status','2026-06-07 21:29:52','2026-06-07 21:29:52'),(160,'Adapted to Drama CD','2026-06-07 21:29:52','2026-06-07 21:29:52'),(161,'Inferiority Complex','2026-06-07 21:29:52','2026-06-07 21:29:52'),(162,'Transported into a Game World','2026-06-07 21:29:53','2026-06-07 21:29:53'),(163,'Marriage of Convenience','2026-06-07 21:29:53','2026-06-07 21:29:53'),(164,'Artists','2026-06-07 21:29:54','2026-06-07 21:29:54'),(165,'Modern Knowledge','2026-06-07 21:29:54','2026-06-07 21:29:54'),(166,'Hated Protagonist','2026-06-07 21:29:54','2026-06-07 21:29:54'),(167,'Previous Life Talent','2026-06-07 21:29:54','2026-06-07 21:29:54'),(168,'Apathetic Protagonist','2026-06-07 21:29:54','2026-06-07 21:29:54'),(169,'Love Rivals','2026-06-07 21:29:54','2026-06-07 21:29:54'),(170,'Villainess Noble Girls','2026-06-07 21:29:54','2026-06-07 21:29:54'),(171,'Antihero Protagonist','2026-06-07 21:29:55','2026-06-07 21:29:55'),(172,'Coming of Age','2026-06-07 21:29:55','2026-06-07 21:29:55'),(173,'Child Protagonist','2026-06-07 21:29:55','2026-06-07 21:29:55'),(174,'Cute Protagonist','2026-06-07 21:29:55','2026-06-07 21:29:55'),(175,'Time Travel','2026-06-07 21:29:55','2026-06-07 21:29:55'),(176,'Hidden Abilities','2026-06-07 21:29:55','2026-06-07 21:29:55'),(177,'Game Elements','2026-06-07 21:29:57','2026-06-07 21:29:57'),(178,'Slow Romance','2026-06-07 21:29:57','2026-06-07 21:29:57'),(179,'Age Regression','2026-06-07 21:29:57','2026-06-07 21:29:57'),(180,'Familial Love','2026-06-07 21:29:57','2026-06-07 21:29:57'),(181,'Age Progression','2026-06-07 21:29:57','2026-06-07 21:29:57'),(182,'Charming Protagonist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(183,'Caring Protagonist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(184,'Cruel Characters','2026-06-07 21:29:57','2026-06-07 21:29:57'),(185,'Friendship','2026-06-07 21:29:57','2026-06-07 21:29:57'),(186,'Doting Parents','2026-06-07 21:29:57','2026-06-07 21:29:57'),(187,'Artifacts','2026-06-07 21:29:57','2026-06-07 21:29:57'),(188,'Healers','2026-06-07 21:29:57','2026-06-07 21:29:57'),(189,'Strong Love Interests','2026-06-07 21:29:57','2026-06-07 21:29:57'),(190,'Depictions of Cruelty','2026-06-07 21:29:57','2026-06-07 21:29:57'),(191,'Childhood Friends','2026-06-07 21:29:57','2026-06-07 21:29:57'),(192,'Doting Older Siblings','2026-06-07 21:29:57','2026-06-07 21:29:57'),(193,'Priests','2026-06-07 21:29:57','2026-06-07 21:29:57'),(194,'Playful Protagonist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(195,'Helpful Protagonist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(196,'Sadistic Characters','2026-06-07 21:29:57','2026-06-07 21:29:57'),(197,'Herbalist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(198,'Pharmacist','2026-06-07 21:29:57','2026-06-07 21:29:57'),(199,'Clingy Lover','2026-06-07 21:30:00','2026-06-07 21:30:00'),(200,'Character Growth','2026-06-07 21:30:00','2026-06-07 21:30:00'),(201,'Loneliness','2026-06-07 21:30:00','2026-06-07 21:30:00'),(202,'Sharing A Body','2026-06-07 21:30:00','2026-06-07 21:30:00'),(203,'Bullying','2026-06-07 21:30:00','2026-06-07 21:30:00'),(204,'Identity Crisis','2026-06-07 21:30:00','2026-06-07 21:30:00'),(205,'Emotionally Weak Protagonist','2026-06-07 21:30:00','2026-06-07 21:30:00'),(206,'Male Yandere','2026-06-07 21:30:01','2026-06-07 21:30:01'),(207,'Appearance Changes','2026-06-07 21:30:01','2026-06-07 21:30:01'),(208,'Drugs','2026-06-07 21:30:01','2026-06-07 21:30:01'),(209,'Genius Protagonist','2026-06-07 21:30:01','2026-06-07 21:30:01'),(210,'Poor Protagonist','2026-06-07 21:30:01','2026-06-07 21:30:01'),(211,'Lovers Reunited','2026-06-07 21:30:01','2026-06-07 21:30:01'),(212,'Older Love Interests','2026-06-07 21:30:01','2026-06-07 21:30:01'),(213,'Weak Protagonist','2026-06-07 21:30:01','2026-06-07 21:30:01'),(214,'Timid Protagonist','2026-06-07 21:30:02','2026-06-07 21:30:02'),(215,'Cautious Protagonist','2026-06-07 21:30:02','2026-06-07 21:30:02'),(216,'Awkward Protagonist','2026-06-07 21:30:02','2026-06-07 21:30:02'),(217,'Arrogant Characters','2026-06-07 21:30:03','2026-06-07 21:30:03'),(218,'Betrayal','2026-06-07 21:30:03','2026-06-07 21:30:03'),(219,'Jealousy','2026-06-07 21:30:03','2026-06-07 21:30:03'),(220,'Dolls/Puppets','2026-06-07 21:30:03','2026-06-07 21:30:03'),(221,'Puppeteers','2026-06-07 21:30:03','2026-06-07 21:30:03'),(222,'Farming','2026-06-07 21:30:04','2026-06-07 21:30:04'),(223,'Found Family','2026-06-07 21:30:04','2026-06-07 21:30:04'),(224,'Spirits','2026-06-07 21:30:04','2026-06-07 21:30:04'),(225,'Teachers','2026-06-07 21:30:04','2026-06-07 21:30:04'),(226,'Wizards','2026-06-07 21:30:04','2026-06-07 21:30:04'),(227,'Spirit Users','2026-06-07 21:30:04','2026-06-07 21:30:04'),(228,'Romantic Subplot','2026-06-07 21:30:04','2026-06-07 21:30:04'),(229,'Late Romance','2026-06-07 21:30:04','2026-06-07 21:30:04'),(230,'Power Struggle','2026-06-07 21:30:05','2026-06-07 21:30:05'),(231,'Acting','2026-06-07 21:30:05','2026-06-07 21:30:05'),(232,'Cunning Protagonist','2026-06-07 21:30:05','2026-06-07 21:30:05'),(233,'Vampires','2026-06-07 21:30:05','2026-06-07 21:30:05'),(234,'Mysterious Illness','2026-06-07 21:30:05','2026-06-07 21:30:05'),(235,'Fallen Nobility','2026-06-07 21:30:05','2026-06-07 21:30:05'),(236,'Mature Protagonist','2026-06-07 21:30:05','2026-06-07 21:30:05'),(237,'Investigations','2026-06-07 21:30:05','2026-06-07 21:30:05'),(238,'Magic Formations','2026-06-07 21:30:05','2026-06-07 21:30:05'),(239,'Demi-Humans','2026-06-07 21:30:05','2026-06-07 21:30:05'),(240,'Kingdoms','2026-06-07 21:30:05','2026-06-07 21:30:05'),(241,'Unreliable Narrator','2026-06-07 21:30:05','2026-06-07 21:30:05'),(242,'Mystery Solving','2026-06-07 21:30:05','2026-06-07 21:30:05'),(243,'Conflicting Loyalties','2026-06-07 21:30:05','2026-06-07 21:30:05'),(244,'Charismatic Protagonist','2026-06-07 21:30:05','2026-06-07 21:30:05'),(245,'Gunfighters','2026-06-07 21:30:05','2026-06-07 21:30:05'),(246,'Human Experimentation','2026-06-07 21:30:05','2026-06-07 21:30:05'),(247,'Spies','2026-06-07 21:30:05','2026-06-07 21:30:05'),(248,'Loner Protagonist','2026-06-07 21:30:05','2026-06-07 21:30:05'),(249,'Shapeshifters','2026-06-07 21:30:05','2026-06-07 21:30:05'),(250,'Trickster','2026-06-07 21:30:05','2026-06-07 21:30:05'),(251,'Werebeasts','2026-06-07 21:30:05','2026-06-07 21:30:05'),(252,'Secretive Protagonist','2026-06-07 21:30:05','2026-06-07 21:30:05'),(253,'Jack of All Trades','2026-06-07 21:30:05','2026-06-07 21:30:05'),(254,'Multiple Identities','2026-06-07 21:30:05','2026-06-07 21:30:05'),(255,'Mpreg','2026-06-07 21:30:07','2026-06-07 21:30:07'),(256,'Persistent Love Interests','2026-06-07 21:30:07','2026-06-07 21:30:07'),(257,'Office Romance','2026-06-07 21:30:07','2026-06-07 21:30:07'),(258,'Yaoi','2026-06-07 21:30:08','2026-06-07 21:30:08'),(259,'Childcare','2026-06-07 21:30:10','2026-06-07 21:30:10'),(260,'Tragedy','2026-06-07 21:30:10','2026-06-07 21:30:10'),(261,'Cute Children','2026-06-07 21:30:10','2026-06-07 21:30:10'),(262,'Righteous Protagonist','2026-06-07 21:30:10','2026-06-07 21:30:10'),(263,'Cultivation','2026-06-07 21:30:11','2026-06-07 21:30:11'),(264,'Cheats','2026-06-07 21:30:12','2026-06-07 21:30:12'),(265,'Pregnancy','2026-06-07 21:30:12','2026-06-07 21:30:12'),(266,'System','2026-06-07 21:30:12','2026-06-07 21:30:12'),(267,'Dreams','2026-06-07 21:30:12','2026-06-07 21:30:12'),(268,'Polygamy','2026-06-07 21:30:12','2026-06-07 21:30:12'),(269,'Adapted to Anime','2026-06-07 21:30:12','2026-06-07 21:30:12'),(270,'Adapted to Manga','2026-06-07 21:30:12','2026-06-07 21:30:12'),(271,'Selfless Protagonist','2026-06-07 21:30:12','2026-06-07 21:30:12'),(272,'Livestreaming','2026-06-07 21:30:12','2026-06-07 21:30:12'),(273,'Adventurers','2026-06-07 21:30:12','2026-06-07 21:30:12'),(274,'Underestimated Protagonist','2026-06-07 21:30:12','2026-06-07 21:30:12'),(275,'Shounen Ai','2026-06-07 21:30:13','2026-06-07 21:30:13'),(276,'Poor to Rich','2026-06-07 21:30:13','2026-06-07 21:30:13'),(277,'Accelerated Growth','2026-06-07 21:30:13','2026-06-07 21:30:13'),(278,'Abandoned Children','2026-06-07 21:30:13','2026-06-07 21:30:13'),(279,'Abusive Characters','2026-06-07 21:30:13','2026-06-07 21:30:13'),(280,'Kidnappings','2026-06-07 21:30:13','2026-06-07 21:30:13'),(281,'Programmer','2026-06-07 21:30:13','2026-06-07 21:30:13'),(282,'Sibling Rivalry','2026-06-07 21:30:13','2026-06-07 21:30:13'),(283,'Rebellion','2026-06-07 21:30:13','2026-06-07 21:30:13'),(284,'Absent Parents','2026-06-07 21:30:13','2026-06-07 21:30:13'),(285,'Artificial Intelligence','2026-06-07 21:30:13','2026-06-07 21:30:13'),(286,'Long Separations','2026-06-07 21:30:13','2026-06-07 21:30:13'),(287,'Sickly Characters','2026-06-07 21:30:13','2026-06-07 21:30:13'),(288,'Dead Protagonist','2026-06-07 21:30:13','2026-06-07 21:30:13'),(289,'Aggressive Characters','2026-06-07 21:30:13','2026-06-07 21:30:13'),(290,'Love Triangles','2026-06-07 21:30:13','2026-06-07 21:30:13'),(291,'Nightmares','2026-06-07 21:30:13','2026-06-07 21:30:13'),(292,'Lazy Protagonist','2026-06-07 21:30:13','2026-06-07 21:30:13'),(293,'Carefree Protagonist','2026-06-07 21:30:13','2026-06-07 21:30:13'),(294,'Mistaken Identity','2026-06-07 21:30:13','2026-06-07 21:30:13'),(295,'Engineer','2026-06-07 21:30:13','2026-06-07 21:30:13'),(296,'Living Alone','2026-06-07 21:30:13','2026-06-07 21:30:13'),(297,'H*ndjob','2026-06-07 21:30:13','2026-06-07 21:30:13'),(298,'Sleeping','2026-06-07 21:30:13','2026-06-07 21:30:13'),(299,'System Administrator','2026-06-07 21:30:14','2026-06-07 21:30:14'),(300,'Level System','2026-06-07 21:30:14','2026-06-07 21:30:14'),(301,'Brother Complex','2026-06-07 21:30:15','2026-06-07 21:30:15'),(302,'Mature','2026-06-07 21:30:15','2026-06-07 21:30:15'),(303,'Honest Protagonist','2026-06-07 21:30:15','2026-06-07 21:30:15'),(304,'Maids','2026-06-07 21:30:15','2026-06-07 21:30:15'),(305,'Celebrities','2026-06-07 21:30:15','2026-06-07 21:30:15'),(306,'Incest','2026-06-07 21:30:15','2026-06-07 21:30:15'),(307,'Fast Cultivation','2026-06-07 21:30:15','2026-06-07 21:30:15'),(308,'Lucky Protagonist','2026-06-07 21:30:15','2026-06-07 21:30:15'),(309,'Famous Protagonist','2026-06-07 21:30:15','2026-06-07 21:30:15'),(310,'Fast Learner','2026-06-07 21:30:15','2026-06-07 21:30:15'),(311,'First-time Interc**rse','2026-06-07 21:30:15','2026-06-07 21:30:15'),(312,'Love at First Sight','2026-06-07 21:30:15','2026-06-07 21:30:15'),(313,'R*pe Victim Becomes Lover','2026-06-07 21:30:15','2026-06-07 21:30:15'),(314,'Enemies Become Allies','2026-06-07 21:30:15','2026-06-07 21:30:15'),(315,'Secrets','2026-06-07 21:30:15','2026-06-07 21:30:15'),(316,'Sudden Strength Gain','2026-06-07 21:30:15','2026-06-07 21:30:15'),(317,'Sister Complex','2026-06-07 21:30:15','2026-06-07 21:30:15'),(318,'Early Romance','2026-06-07 21:30:15','2026-06-07 21:30:15'),(319,'C*nnilingus','2026-06-07 21:30:15','2026-06-07 21:30:15'),(320,'Sudden Wealth','2026-06-07 21:30:15','2026-06-07 21:30:15'),(321,'Cousins','2026-06-07 21:30:15','2026-06-07 21:30:15'),(322,'Nurses','2026-06-07 21:30:15','2026-06-07 21:30:15'),(323,'Reverse R*pe','2026-06-07 21:30:15','2026-06-07 21:30:15'),(324,'Seduction','2026-06-07 21:30:15','2026-06-07 21:30:15'),(325,'Showbiz','2026-06-07 21:30:16','2026-06-07 21:30:16'),(326,'Quirky Characters','2026-06-07 21:30:16','2026-06-07 21:30:16'),(327,'Amnesia','2026-06-07 21:30:16','2026-06-07 21:30:16'),(328,'Parody','2026-06-07 21:30:16','2026-06-07 21:30:16'),(329,'Sharp-tongued Characters','2026-06-07 21:30:16','2026-06-07 21:30:16'),(330,'Fated Lovers','2026-06-07 21:30:16','2026-06-07 21:30:16'),(331,'Shy Characters','2026-06-07 21:30:16','2026-06-07 21:30:16'),(332,'Time Paradox','2026-06-07 21:30:16','2026-06-07 21:30:16');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_members`
--

DROP TABLE IF EXISTS `team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `role` enum('leader','admin','editor','member') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requested_by` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_members_team_id_user_id_unique` (`team_id`,`user_id`),
  KEY `team_members_user_id_foreign` (`user_id`),
  KEY `team_members_requested_by_foreign` (`requested_by`),
  KEY `team_members_approved_by_foreign` (`approved_by`),
  CONSTRAINT `team_members_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `team_members_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `team_members_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_members`
--

LOCK TABLES `team_members` WRITE;
/*!40000 ALTER TABLE `team_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `site` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `donation_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `donation_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teams_user_id_foreign` (`user_id`),
  CONSTRAINT `teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_achievements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `achievement_id` bigint unsigned NOT NULL,
  `unlocked_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_achievements_user_id_achievement_id_unique` (`user_id`,`achievement_id`),
  KEY `user_achievements_achievement_id_foreign` (`achievement_id`),
  CONSTRAINT `user_achievements_achievement_id_foreign` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_achievements`
--

LOCK TABLES `user_achievements` WRITE;
/*!40000 ALTER TABLE `user_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_vips`
--

DROP TABLE IF EXISTS `user_vips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_vips` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `package_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_days` int NOT NULL,
  `package_coins` int NOT NULL,
  `daily_credits` int unsigned NOT NULL DEFAULT '0',
  `last_daily_credit_at` timestamp NULL DEFAULT NULL,
  `start_at` timestamp NULL DEFAULT NULL,
  `end_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_vips_user_id_foreign` (`user_id`),
  CONSTRAINT `user_vips_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_vips`
--

LOCK TABLES `user_vips` WRITE;
/*!40000 ALTER TABLE `user_vips` DISABLE KEYS */;
INSERT INTO `user_vips` VALUES (1,309,'Thành viên Premium',30,30,5,'2026-06-08 21:41:48','2026-06-08 21:41:48','2026-07-08 21:41:48','2026-06-08 21:41:48','2026-06-08 21:41:48');
/*!40000 ALTER TABLE `user_vips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` timestamp NULL DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `background` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `gender` tinyint(1) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `should_re_login` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` int NOT NULL DEFAULT '0',
  `points` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_google_id_index` (`google_id`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (201,'pollich.remington',NULL,'shaina44@example.org',NULL,'2024-04-15 08:04:55','5811 Reichel Forks Suite 879\nNikolausborough, SD 57373','$2y$12$vtZFf4UnjZRm2yOKewoyFOYj/.Xh1P.SqOP6EhPENpuwsWZEB.EMy','2005-02-05 23:39:25','/storage/images/users/201.jpg?v=1781423470',NULL,NULL,1,'XuKZfNCvlw',0,'1996-06-01 02:39:28','2026-06-14 14:59:13',1,0),(202,'fblock','Jazmyne Kilback','aufderhar.alfreda@example.net',NULL,'2024-04-15 08:04:56','1286 Watson Points\nWest Jaqueline, NY 78621-7055','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-05-20 14:27:36','Qui quos voluptas aliquam sunt odio enim. Ad sit suscipit soluta sit eaque odio eaque. Ex quae nesciunt sit minus asperiores.',NULL,'Laudantium soluta totam quia sunt voluptatem. Iure quae et molestias fuga dolor autem. Quas dolores incidunt aut quam consequatur incidunt fugit. Vero aut odit repudiandae explicabo.',1,'VXemDSt8wn',0,'2004-08-30 16:27:49','2003-01-26 17:16:34',0,0),(203,'tdach','Roma Dach','maria.kerluke@example.net',NULL,'2024-04-15 08:04:56','74405 Hansen Plain\nWest Ellsworth, AZ 91033','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-11-10 20:02:23','Sit eum blanditiis voluptatem quia. Similique voluptatem ea accusantium quis praesentium aut sint. Animi voluptas error quo voluptas at tempore.',NULL,'Recusandae ea quo debitis tenetur aliquam dolorem. Cupiditate ut rerum quia ut. Perferendis aut laudantium assumenda et. Dolores quo ut dolores voluptatum.',0,'niuViyJxqs',0,'1998-04-25 01:33:04','2005-02-20 06:55:42',0,0),(204,'dgoyette','Cara Turner','brionna44@example.net',NULL,'2024-04-15 08:04:56','56560 Alexanne Park\nNorth Maggiechester, SC 36663','$2y$12$MXnX8wrCTaDIOUfURBHLyOVkxF3hoFi4JD0iYX2qWxtSH4qicbBOW','1997-10-01 23:30:21','Eaque excepturi aspernatur ipsa iste. Quia adipisci sunt qui et aut qui ea. Blanditiis rerum iusto qui exercitationem.',NULL,'Tenetur omnis nesciunt sequi odio placeat asperiores molestiae. Nihil qui soluta voluptatem occaecati officia. Praesentium dicta tenetur cumque culpa.',0,'vG7WhjbRNe',0,'2003-05-26 02:18:50','2026-06-04 14:47:29',2,0),(205,'dovie15','Julia Jaskolski','angelina.streich@example.com',NULL,'2024-04-15 08:04:56','58689 Murray Island\nSimonismouth, DE 24231','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-02-06 06:55:42','Ea corrupti corrupti earum quia doloremque rerum qui. Omnis nostrum nulla officia. Officiis rem tempora molestiae qui.',NULL,'Est tempore voluptates numquam quo tempore provident impedit quis. Voluptates ullam eos optio qui. Et repellat eligendi quae eaque aut.',0,'qVKXcyt5kR',0,'2002-12-19 22:21:51','2001-02-12 16:48:43',0,0),(206,'cyril.brown','Allan Harvey','alessandro48@example.net',NULL,'2024-04-15 08:04:56','523 Rohan Dam Apt. 900\nAriannashire, NM 43098-1451','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-03-31 22:49:22','Excepturi omnis quo maiores rem eum omnis sed. Odit omnis ad alias iste. Eaque optio quis omnis unde nostrum tempore atque magnam. Doloribus dolor repellendus enim minus ut.',NULL,'Qui fugit eius atque est et. Earum et est voluptate ea est reiciendis consequatur. Nam facilis illo eos aut sint. Maxime tenetur quas debitis dicta.',0,'yTpZVwq2LJ',0,'2001-06-18 13:06:58','2005-02-25 22:05:40',0,0),(207,'roxane.mueller','Anya Koepp','cartwright.josiah@example.com',NULL,'2024-04-15 08:04:56','19426 Paige Wall\nCassinshire, NV 45175','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-10-06 15:16:59','Voluptatem asperiores vitae itaque et quisquam animi sint. Consequatur quidem at ut. In eaque eum consequatur reiciendis.',NULL,'Molestiae voluptatibus esse id. Recusandae alias dolore fuga blanditiis dolor aut est. Esse eos minima provident qui rerum nesciunt et cumque.',1,'QJjYmWNJO0',0,'1998-02-03 20:36:22','1997-08-11 05:38:46',2,0),(208,'adriel26','Georgianna Weimann','pwaters@example.com',NULL,'2024-04-15 08:04:56','934 Bogan Plaza Apt. 870\nNorth Mariah, AK 78480-5713','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-10-31 01:48:03','Qui sint et voluptatem est ut velit totam dolor. Consequuntur nostrum culpa natus harum illo in eos. Fugiat minima vitae soluta est doloremque qui.',NULL,'Cupiditate illum ut dolorum ipsam. Mollitia in corrupti doloribus id ipsam consequatur non. Ducimus quia non quibusdam perspiciatis tenetur dicta aperiam tenetur.',0,'PyihtZdCfO',0,'1997-01-23 03:00:06','2005-06-26 14:36:57',0,0),(209,'matt20','Cyrus Cassin','peyton27@example.net',NULL,'2024-04-15 08:04:56','703 Trinity Forge\nSouth Huntermouth, MA 47901-4714','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-06-03 12:42:36','Tempore sint eveniet sequi veritatis eum eligendi. Amet dolores ut voluptas harum tenetur debitis perferendis rerum. Rem sit quidem nisi. Doloremque ut voluptates libero sit repellendus recusandae.',NULL,'Pariatur maiores tenetur ut et unde. Ipsam eum qui porro rerum et a. Modi voluptatibus illum autem recusandae aut quia quis. Atque iste enim nemo.',1,'GKaXA4EO2y',0,'2001-05-13 04:50:39','2005-08-14 14:43:02',0,0),(210,'ddouglas','Miss Samanta Graham DDS','cremin.myrl@example.com',NULL,'2024-04-15 08:04:56','2223 Keara Meadow\nPort Paulinemouth, MD 10095','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-11-30 03:20:51','Soluta maxime est consequatur quos. Ipsam odio vel perspiciatis pariatur unde dolores. Repudiandae ratione enim quia sed et.',NULL,'Nam repudiandae aut quidem laboriosam ut eos nulla. Ullam dicta voluptas dolorem cumque autem earum alias. Est iure repudiandae vel. Quod qui neque voluptas sint aut consequatur.',1,'AbnPsCOVDP',0,'2001-04-16 17:43:51','2003-11-14 15:09:15',2,0),(211,'maiya37','Prof. Garnet Harvey','towne.wilhelmine@example.com',NULL,'2024-04-15 08:04:56','7396 Spinka Mountain Apt. 011\nLake Bernardville, CA 93530','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-07-19 09:39:41','Qui aut sequi quia beatae harum ut. Amet corrupti sit sequi atque delectus et aperiam. Aut dolorum quia est nesciunt alias.',NULL,'Doloremque aut magni aut omnis suscipit. Exercitationem numquam ducimus voluptas eos laboriosam. Et vel ut sed est est cupiditate. Voluptas magnam hic et nisi cum cum.',1,'ze3C0YQTdu',0,'2004-01-25 07:04:39','1999-08-25 22:08:07',2,0),(212,'breitenberg.sierra','Mrs. Elnora Stiedemann','harris.keon@example.org',NULL,'2024-04-15 08:04:56','84271 Mckenzie Shoal Apt. 279\nBlancatown, OR 37516-0430','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-01-12 04:07:08','Neque et et eaque laborum. Ut non enim consequuntur nisi. Sit et voluptatem neque non deserunt. Voluptas porro ut voluptas iste. Sint rem doloribus quia illum. Quo sit rerum voluptatem.',NULL,'Enim rem tenetur assumenda corrupti vel ab. Nobis voluptas autem doloremque ut perspiciatis architecto omnis.',1,'2E54BujF87',0,'1996-11-01 04:04:08','1996-01-17 09:24:39',1,0),(213,'barbara99','Ms. Raina Goldner MD','oran.jacobson@example.com',NULL,'2024-04-15 08:04:56','2210 Hintz Lodge Suite 419\nNorth Traceymouth, MD 04658','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-04-16 12:18:13','Ab voluptas itaque doloremque libero quas provident sit. Rerum neque est consequuntur eligendi asperiores maxime. Hic rerum in aliquid quis est eligendi.',NULL,'Repudiandae hic laboriosam velit illum eum est eos dolore. Exercitationem officiis aut sit itaque quaerat. Minima eos esse et voluptatem adipisci.',0,'EPS5EcQ4sd',0,'2000-05-11 06:24:13','2002-03-16 16:21:35',1,0),(214,'addison63','Dr. Ruthie Schmitt','jasmin01@example.org',NULL,'2024-04-15 08:04:56','821 Monroe Mall Apt. 484\nHermannborough, IA 18192','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-02-15 03:35:33','Nesciunt ad vitae et et qui quisquam. Deleniti asperiores ullam illo. Voluptatum ex ipsam itaque id non tempore exercitationem. Voluptatem placeat dolor atque autem quas.',NULL,'Aspernatur soluta adipisci deleniti. Perferendis placeat et id voluptatum odio consequuntur est quia. Ipsa cum distinctio porro nesciunt in. Laudantium rem officiis ut et.',1,'WULh1pwCVg',0,'1996-08-20 07:41:11','1997-08-15 01:02:23',1,0),(215,'dooley.raymundo','Prof. Camron Torphy','groberts@example.org',NULL,'2024-04-15 08:04:56','5635 Nat Drives Suite 628\nGorczanyside, AK 98196-1459','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-11-22 19:15:27','Corporis enim quam quas ut a libero facilis. Reprehenderit commodi quam deserunt consequatur ut. Reprehenderit fugit ratione nesciunt qui voluptatem.',NULL,'Similique at neque eos impedit fugiat ipsa. Voluptatem impedit corrupti labore nostrum. Earum expedita soluta ea quo tempore.',0,'NrJXHtLVif',0,'1994-04-18 00:06:36','1997-09-22 05:58:44',2,0),(216,'koepp.jammie','Dr. Andy Batz','eriberto51@example.com',NULL,'2024-04-15 08:04:56','7452 Jones Brooks Suite 978\nMcKenziefurt, MA 13500-6890','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-09-01 05:00:02','Qui necessitatibus deserunt voluptatibus odit dicta exercitationem. Fuga est maiores eaque dolores. Rerum ex velit ut et.',NULL,'Ullam inventore dolor blanditiis. Earum hic sit voluptatem sit ipsam iusto numquam aut. Iste sed quo eos assumenda sit. Quae atque velit eum accusantium. Eaque quis nihil expedita et.',0,'6kmujRUzKK',0,'1997-12-10 14:59:51','2003-04-07 10:51:56',1,0),(217,'cwitting','Milton Effertz','ueffertz@example.org',NULL,'2024-04-15 08:04:56','39623 Alanis Vista\nVeumton, OR 07306','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-12-23 01:17:42','Numquam qui eveniet omnis labore voluptatum. Ratione eaque ullam iure sunt cumque iste. In quasi sit sunt excepturi reiciendis et.',NULL,'Nulla suscipit hic non aut. Rerum omnis nesciunt harum sed nam ea velit. Est accusantium blanditiis sit sed.',1,'VnmAUW2226',0,'2001-03-30 06:03:21','1996-02-08 17:14:33',2,0),(218,'clement.olson','Neal Kautzer','buford81@example.org',NULL,'2024-04-15 08:04:56','672 Cartwright Lake Suite 457\nNorth Jensen, NY 45263-5974','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-03-06 01:45:35','Perspiciatis pariatur tenetur corrupti odit cupiditate placeat et. Aut sequi accusantium adipisci minima unde optio nemo culpa. In asperiores aperiam qui ut. Esse ut vero fugiat ad.',NULL,'Quo molestiae adipisci pariatur. Est libero in reiciendis autem provident earum. Quis aliquid et laudantium est ex. Reprehenderit earum odio qui sit autem natus.',1,'fcztOJh8Ue',0,'1999-04-24 12:33:28','2002-12-05 16:54:51',1,0),(219,'nbrown','Solon O\'Connell','gunner50@example.net',NULL,'2024-04-15 08:04:56','39409 Kelvin Ranch\nLake Traceybury, SD 35888','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-01-14 21:55:09','Totam quia sunt et et est. Recusandae dignissimos consequatur eligendi adipisci voluptates dolores. Odio commodi error adipisci.',NULL,'Dicta explicabo ex rerum nisi. Perspiciatis molestias et alias nulla. Quae perspiciatis omnis soluta esse nihil. Quidem nesciunt et omnis et et voluptatem.',0,'paW2158a1i',0,'1998-06-30 04:57:31','2000-04-06 16:20:16',0,0),(220,'schaden.rocio','Mrs. Estel Pfannerstill DVM','jhilpert@example.org',NULL,'2024-04-15 08:04:56','2058 Felicity Isle Apt. 434\nSouth Rheatown, NH 58324-9280','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-03-12 08:14:43','Nemo consequatur molestiae amet. Eum earum repellat voluptatum natus eius et quaerat sit. Nam soluta reprehenderit nisi enim ut molestias.',NULL,'Non quis qui nisi. Consequatur nemo accusantium autem qui doloribus magni. Et harum voluptas nihil molestias quibusdam numquam ut.',0,'xtXUoKex1D',0,'1997-11-06 20:11:03','1995-02-10 22:05:22',1,0),(221,'romaguera.demetrius','Roselyn Schimmel','hermann12@example.com',NULL,'2024-04-15 08:04:56','65215 Roob Cliff\nSouth Damion, NH 37891-1273','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-02-02 00:48:39','Et ducimus natus nesciunt modi vitae vel quos. Deserunt repellat exercitationem architecto delectus facilis est. Qui omnis consequatur dolor itaque non tenetur.',NULL,'Quia voluptate officiis quod voluptatem. Similique illo at dicta et omnis. Mollitia aut amet aliquid molestiae est quae earum. Similique ex et nulla voluptas quo excepturi ea iste.',0,'QaLZTD4PDa',0,'2000-05-29 10:55:45','1994-05-26 19:08:00',2,0),(222,'krajcik.julian','Lucienne Schumm','schultz.alejandra@example.net',NULL,'2024-04-15 08:04:56','17875 Aidan Village Suite 998\nNorth Estrella, NC 39607-9020','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-09-21 12:54:34','Consequatur voluptas vitae laboriosam modi neque recusandae. Libero sit dolores quisquam sunt vel et. Debitis ipsam suscipit enim.',NULL,'Facilis facere corrupti voluptas dolores. Suscipit voluptatem consequatur iusto explicabo ut. Et provident ratione qui adipisci a rerum laborum.',1,'qhbL7ZSbBB',0,'1999-01-31 03:27:48','1998-12-02 21:54:12',2,0),(223,'lcollins','Enrique Cronin','xconn@example.org',NULL,'2024-04-15 08:04:56','9847 Tracy Canyon Apt. 625\nKovacekville, ME 15646-8370','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2006-01-15 23:13:16','Quidem rerum et eligendi. Error rerum earum quia et consequuntur saepe et. Quod natus eos vitae aspernatur. Voluptate aperiam omnis ducimus itaque sed necessitatibus sint.',NULL,'Laudantium officia ea provident ut. Vel et atque voluptatem. Necessitatibus dicta quaerat ullam fugit repellat et. Expedita eaque veritatis molestias quia sint laborum.',0,'Woxi648xjE',0,'2005-06-10 19:32:10','1995-09-07 16:25:31',2,0),(224,'spencer.tanya','Jeramy Leannon','hirthe.jaquan@example.org',NULL,'2024-04-15 08:04:56','592 Little Cliff Apt. 771\nSouth Birdie, HI 34333','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-07-12 17:00:52','Ipsa commodi illo at. Reprehenderit ad fugit blanditiis ea est. Incidunt modi veniam voluptatem voluptas. Et ut omnis eos reiciendis. Cum temporibus quia deserunt et quos.',NULL,'Qui excepturi nemo rerum nihil qui. Necessitatibus in tempora sed assumenda ut asperiores. Est blanditiis sed qui eveniet accusamus magnam vitae id. Et minima earum aut quos eum omnis aliquid quod.',1,'KCmk9N7eQz',0,'1994-06-20 19:47:05','2003-08-31 02:38:19',2,0),(225,'rippin.adeline','Leila Schaden','oreilly.charlotte@example.org',NULL,'2024-04-15 08:04:56','94779 Schumm Square\nSamirstad, AR 28727-2295','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-04-22 13:24:15','Nulla tempore doloremque quis perferendis nobis quis. Commodi et officia qui quia iste vero cum. Et est earum maiores laboriosam animi temporibus. Sit magni consequatur iste quasi at magnam velit.',NULL,'Nihil non laboriosam iste commodi qui. Ratione soluta sequi sed commodi. Culpa sed velit ipsum aut quo. Nam qui dolores saepe temporibus dicta.',0,'5RsWhY6HgP',0,'1996-03-02 13:04:56','2000-11-30 17:52:43',0,0),(226,'flavio.schumm','Julianne Satterfield III','ludie57@example.net',NULL,'2024-04-15 08:04:56','2684 Sheila Courts\nMyahfort, MD 56532-4313','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-02-16 16:41:05','Aliquid nesciunt doloribus ipsa ipsum voluptatem. Praesentium quasi aut fugiat neque sunt quam. Placeat tempore accusantium dolore.',NULL,'Magnam qui amet ea veritatis. Nesciunt autem est sunt et quis est. Quis modi quia magni voluptatum. Id molestiae nisi dolorum hic reiciendis.',0,'YaCCvGl9td',0,'1999-05-30 19:04:43','1997-12-31 22:57:52',0,0),(227,'torey70','Asia Gottlieb','ykilback@example.org',NULL,'2024-04-15 08:04:56','26742 Nader Tunnel\nLake Malcolm, MD 78055-6953','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-02-20 16:23:58','Enim voluptatem qui reprehenderit dolores officiis praesentium. Dolor culpa expedita nostrum amet quisquam aut.',NULL,'Dolorum et et numquam ut eveniet. Magnam nihil aut est aut mollitia. Omnis sunt vel architecto voluptatem. Consequatur atque quo est asperiores rem.',0,'Rq9XbkIHma',0,'1995-05-23 03:55:20','1996-11-13 09:39:34',0,0),(228,'mckayla.jenkins','Olaf Russel','wilkinson.lynn@example.com',NULL,'2024-04-15 08:04:56','680 Steuber Forge Apt. 410\nCierraburgh, IA 38035-5126','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-07-13 03:00:59','Voluptas aliquid perspiciatis nesciunt deserunt harum autem. Tempore deleniti et et est laborum. Voluptatem voluptatem praesentium sit fuga voluptatum quo.',NULL,'Illum itaque consequuntur eligendi labore provident voluptatem. Aut nulla tenetur et harum maxime. In animi sapiente rerum sed fuga dignissimos.',1,'Hg2veycHsq',0,'2001-11-01 06:09:47','2000-10-24 20:56:55',2,0),(229,'luettgen.christ','Mertie Koepp MD','dbins@example.org',NULL,'2024-04-15 08:04:56','4419 Eula Brooks Suite 724\nChesterton, AZ 80398','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-06-01 03:11:27','Doloribus ducimus vel voluptatem cum blanditiis officiis. Architecto ipsa vel itaque cupiditate. Reprehenderit eaque explicabo fugit ut aliquid. Sequi aut voluptas natus.',NULL,'Quo nulla ut minus ducimus enim. Sunt autem ut doloremque voluptatem. Ut laborum dignissimos nobis excepturi. Labore rerum tempore omnis autem.',1,'DNqizoMHpF',0,'1995-02-20 14:34:48','1999-09-03 09:38:20',0,0),(230,'eking','Hope Dicki','moen.zaria@example.com',NULL,'2024-04-15 08:04:56','5124 Crist Parkway\nPort Tiffany, AK 34355','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-01-16 22:00:14','Culpa voluptatem aspernatur aliquam. In sint iure quidem nihil et enim corrupti voluptas. Ab similique molestias optio sequi aut omnis quibusdam.',NULL,'Expedita accusantium quia qui voluptatem nisi. Excepturi doloremque harum labore minus. Nostrum distinctio optio corrupti omnis. Aut voluptas odio provident dolorum quas accusantium quos recusandae.',0,'B0AMkKyrPW',0,'2003-02-22 08:32:38','1995-02-14 12:57:43',2,0),(231,'summer03','Ulises Nikolaus','cruickshank.melisa@example.net',NULL,'2024-04-15 08:04:56','27711 Wehner Mount\nDachstad, ME 61118-2593','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-03-24 22:54:31','Amet nihil minus corporis illum sequi. Eum omnis ut neque et. Repellat modi ut ratione qui sapiente.',NULL,'Reiciendis ipsam aut esse exercitationem qui animi possimus. Quia nobis ipsa nihil est. Soluta libero assumenda et.',1,'Zp5ikpuXf3',0,'2002-03-06 18:29:20','2005-08-31 16:06:39',1,0),(232,'trogahn','Prof. Salvador Rempel','qthompson@example.com',NULL,'2024-04-15 08:04:56','147 Purdy Motorway\nSouth Bethel, NH 11508','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-12-16 17:06:41','Repudiandae id totam et ea. Ducimus rem quasi veritatis sed et sit.',NULL,'Est commodi occaecati porro. Ut et ratione praesentium ad ut sit. Qui officia ipsum saepe sed sequi.',1,'DcxKLQ528K',0,'2004-05-25 17:42:09','1994-11-28 22:57:25',1,0),(233,'berge.thad','Brandt Windler','collins.ulises@example.net',NULL,'2024-04-15 08:04:56','6246 Kreiger Lights\nNew Seth, ME 87493','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-11-30 12:43:15','Quo dolores excepturi dicta eaque omnis. Voluptas illum quas occaecati maiores totam. Quas ea quis laboriosam neque. Vel ut fugit voluptatem similique commodi eum.',NULL,'Alias similique maiores fugiat quis ullam sunt eligendi saepe. Et perferendis dicta voluptatem dignissimos est repudiandae soluta. Nisi neque optio dolores quos.',1,'9yqxu4NDna',0,'2001-12-01 04:34:26','1995-05-10 23:33:27',1,0),(234,'blueilwitz','Daisha Murphy III','marina.shanahan@example.org',NULL,'2024-04-15 08:04:56','5665 Nienow Burg Suite 276\nSouth Grantland, CO 00347-5244','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-06-29 23:13:00','Voluptatem quae ea repellat ut libero voluptate aut at. Quo dolor neque quasi error vel possimus. Harum rem ratione culpa et facilis occaecati.',NULL,'Possimus repellendus aspernatur reprehenderit omnis iure aut est. Cupiditate quia non distinctio aut et recusandae. Et nesciunt expedita maiores labore dolorem. Consectetur non aliquid placeat et ut.',0,'cxOyByM7cw',0,'1996-04-03 21:06:06','2003-08-11 04:00:25',1,0),(235,'ena.homenick','Dannie Turner','cole.carson@example.org',NULL,'2024-04-15 08:04:56','2564 Leif Club\nLemkeborough, CT 98132','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-03-04 12:17:24','Porro tempora et ipsam. Iure nam temporibus voluptatem nesciunt. Dolores aut saepe voluptate voluptas qui adipisci. Eum tempore fugit ipsa velit.',NULL,'Excepturi quam sed ut unde. Dolore vitae et voluptatem nobis quia ut nesciunt. Unde corrupti deleniti dolores et assumenda quos.',0,'0dgzgPMS40',0,'2001-05-13 00:42:54','2000-01-02 12:27:42',2,0),(236,'jemard','Anika Bosco','hrunolfsdottir@example.net',NULL,'2024-04-15 08:04:56','13585 Mann Fort\nToyton, KY 82163','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-10-10 21:58:29','Quo occaecati consequuntur cum eveniet. Et labore ipsa perferendis tempora cupiditate. Minima provident debitis accusantium atque expedita tempore.',NULL,'Inventore in delectus cum voluptas consectetur pariatur cumque. Ea et dolor minima nesciunt quo tenetur. Odio repellat atque quia nesciunt odit.',1,'QmsgjiEnMd',0,'1997-10-07 04:19:21','2001-10-21 11:21:59',1,0),(237,'mackenzie73','Muriel Gaylord','carmelo51@example.net',NULL,'2024-04-15 08:04:56','59707 Crawford Common\nNew Lavernstad, WI 01667','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-05-23 16:16:43','Quo corrupti ut nam nisi nulla et non culpa. Soluta eveniet quia id quia maiores quo enim cupiditate. At ducimus voluptatem ea sit sequi debitis. Animi itaque ipsum molestias fugiat omnis.',NULL,'Sed repellat tenetur beatae. Optio cum expedita quidem quisquam nobis voluptas sed assumenda. Ut officiis necessitatibus voluptas quo excepturi magni fugiat. Sit sed id ut.',0,'qMPJfQpAOs',0,'1998-06-08 12:40:51','1994-11-17 20:29:22',1,0),(238,'luciano62','Sibyl Bradtke','schultz.kamille@example.com',NULL,'2024-04-15 08:04:56','3426 Bryce Key\nNorth Zena, SC 90806','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-02-14 00:18:25','Facere quo porro rerum tempore dolor. Debitis nemo voluptatibus reprehenderit eveniet iure dolorum. Culpa unde itaque laudantium non. Beatae mollitia tempore iste rerum excepturi qui.',NULL,'In numquam harum est eius at rerum. Nihil sit fuga voluptas ea occaecati facilis qui. Vitae ea quas ullam reprehenderit dolores. Perspiciatis repellat iste et ex dolor sunt.',1,'uazWxNCMEp',0,'2001-11-13 08:01:22','1997-01-31 03:54:00',0,0),(239,'avonrueden','Jonas Hauck DVM','oda49@example.org',NULL,'2024-04-15 08:04:56','9310 Gutkowski Burgs Apt. 253\nEast Charity, VT 32443-9634','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-02-25 02:20:25','Eum labore id doloremque. Eos doloribus aut voluptas sint tempora aut. Voluptas doloremque in quo adipisci excepturi sunt.',NULL,'Eligendi ut nemo et sunt assumenda quisquam voluptas impedit. Aliquid laboriosam aspernatur et fugiat architecto maxime omnis. Consequuntur rerum exercitationem consectetur saepe ipsam aperiam.',1,'4LE3tfpm9A',0,'2004-11-06 09:14:07','2000-03-08 11:44:47',1,0),(240,'breitenberg.aurore','Cruz Marquardt','gustave03@example.com',NULL,'2024-04-15 08:04:56','2019 Sofia Center\nNew Aaron, OH 19114','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-01-01 08:21:49','Incidunt aut nisi accusantium exercitationem saepe odio modi. Commodi ratione perspiciatis deleniti. Consequatur et temporibus quasi.',NULL,'Aut id natus modi et pariatur consequatur odio. Ea libero qui dolore et ut qui ex. Eveniet excepturi voluptatum atque assumenda dicta ratione hic.',1,'wmq7ESJ4Od',0,'1998-03-03 19:44:03','2004-10-03 01:04:41',0,0),(241,'brionna67','Cindy Zboncak','alindgren@example.com',NULL,'2024-04-15 08:04:56','2780 Rempel Court\nNew Emmalee, FL 89911','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-08-27 14:57:09','Velit labore quas harum ut nihil nulla. Ut dignissimos ut aperiam sint vel autem cumque est. Et est officia omnis sunt amet nostrum.',NULL,'Officia culpa ipsa et laborum ipsam architecto repudiandae modi. Sint alias itaque eveniet veritatis soluta facere dolores. Omnis eum repellendus illo delectus.',1,'jliBag2F9t',0,'2003-04-21 11:17:50','2000-12-19 07:04:34',0,0),(242,'vlindgren','Carol Mayer','vida.yost@example.org',NULL,'2024-04-15 08:04:56','14139 Keeling Mission\nLake Lexus, MA 57007-9649','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-04-26 17:20:48','Doloribus distinctio officia ex non esse et. Pariatur autem ut repudiandae rerum repellendus voluptatibus dolore. Blanditiis ut sed quo minus. Voluptatem rerum quia optio architecto ut harum.',NULL,'Ab ut dolor esse. Vero illum minus totam et aut vel fuga. Neque et nemo occaecati modi voluptatem omnis. Aspernatur ipsa et hic corrupti nam.',1,'Q6Opsu5YXp',0,'2002-04-29 23:26:34','2004-04-17 07:48:32',2,0),(243,'rlang','Keanu Adams','schmeler.luz@example.com',NULL,'2024-04-15 08:04:56','348 Emie Brooks Suite 113\nDuncanmouth, IN 56065-2184','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-03-25 13:33:00','Amet repellat sunt quia est tempora itaque sed. Et itaque in aliquam eos repudiandae.',NULL,'Harum ex rerum rem quo saepe vel. Distinctio sunt rerum commodi ea velit similique.',0,'BqCdTqjS6I',0,'2004-11-09 23:52:17','2004-09-29 08:55:34',1,0),(244,'larry.kling','Hipolito Rutherford','elvis75@example.com',NULL,'2024-04-15 08:04:56','3748 Maurice Skyway\nMauricefurt, KY 33451-3648','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-01-05 00:27:01','Necessitatibus fuga doloremque nobis iste esse qui quos. Rerum iure cum nulla iusto vel sed consequatur. Voluptates dolores reiciendis qui iste animi. Soluta voluptas culpa placeat sit.',NULL,'Est eaque rerum labore et at. Ut impedit vitae consectetur excepturi ut vitae. Itaque corporis et quibusdam corporis nihil quas. Mollitia animi corrupti ut sint nihil.',0,'6VszZRHcLJ',0,'1997-11-08 13:10:36','2001-11-25 23:28:34',0,0),(245,'makenna53','Nedra Hackett','jweimann@example.org',NULL,'2024-04-15 08:04:56','853 Asa Creek\nDickensland, TX 36092-7220','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-06-26 21:19:33','Accusantium voluptatem praesentium dolorum velit quia sunt quibusdam. Maxime quia vel aut modi voluptatem. Ut et velit quisquam harum aut. Laudantium tempora inventore consequatur.',NULL,'Quas amet ratione excepturi consequatur. Nihil et rerum optio rem tempora animi modi.',1,'uhvnzHAtW6',0,'1997-09-08 18:29:59','2005-07-21 23:15:10',1,0),(246,'ddickinson','Oda Beier','carrie.lind@example.net',NULL,'2024-04-15 08:04:56','96945 Aida Cliff\nLarkinborough, MS 49387-8625','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-11-01 23:06:07','Blanditiis illo reprehenderit quae distinctio dolorem. Ea nemo eligendi sequi. Vero temporibus et perspiciatis deleniti reprehenderit omnis est.',NULL,'Sunt et dolorem facere. Dignissimos blanditiis consequatur odit et consequatur harum. Debitis ut autem fugit maiores soluta.',0,'znJOtpHdQs',0,'1996-09-20 23:28:46','1996-07-05 02:50:41',2,0),(247,'guadalupe.lynch','Miss Marian Kunde','xrobel@example.org',NULL,'2024-04-15 08:04:56','480 Cathryn Prairie\nWest Tobinstad, KY 16668-5146','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-08-29 08:25:06','Laboriosam repellendus ut reprehenderit aliquam eos deleniti numquam. Vel iure provident exercitationem temporibus. Sed ex saepe aut unde aperiam eaque quia.',NULL,'Suscipit autem quis ducimus. Quidem ut consequuntur sunt nemo. Ipsam aut aut officiis minima sed sit. Facere amet totam sequi et nihil cum. Voluptatem magni fugit voluptatem.',0,'P51heu20a4',0,'2002-02-17 06:47:34','2003-12-25 06:46:07',0,0),(248,'ywindler','Seamus Bauch','paxton.kris@example.com',NULL,'2024-04-15 08:04:56','978 Murazik Stream Apt. 887\nEast Eldon, NE 18987','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-01-05 06:18:19','Itaque neque vel ut veritatis recusandae aut. Laborum quasi ut saepe architecto. Quis in omnis dolor itaque molestiae sequi velit.',NULL,'A iusto eveniet libero quae. Provident at maxime nobis quia nihil iste libero. Minima illum minus et nisi aut et.',0,'QuEnFz4dsr',0,'1999-01-25 00:31:52','1996-12-21 18:47:02',2,0),(249,'lourdes.cassin','Henderson Marvin','borer.jasmin@example.org',NULL,'2024-04-15 08:04:56','426 Mills Knolls\nKlockoport, MD 10140-2302','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-08-04 11:01:05','Explicabo est atque aut tempora totam. Sed voluptatibus placeat et laudantium aut quis dolores. Hic quisquam deleniti nam sit. Eum vero aliquam quam quisquam unde.',NULL,'Possimus quidem deleniti et veritatis et culpa dignissimos. Vero et dolor ducimus. Aliquid eaque a labore dolor deserunt aut odit.',1,'syFFVrquzc',0,'1997-06-29 11:45:20','2003-09-14 06:15:44',1,0),(250,'irussel','Dr. Isabelle Doyle Jr.','hschoen@example.net',NULL,'2024-04-15 08:04:56','190 Ida Tunnel Suite 241\nWest Demetrishaven, HI 61061','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-01-04 00:41:39','Labore nihil assumenda perferendis aut perspiciatis natus adipisci. Neque similique quis dolorum. Dignissimos eos eaque iusto ut ab aspernatur. Tempora beatae sed qui hic architecto et.',NULL,'Quisquam repudiandae ab at ipsa eius est. Sit commodi provident ad et repellendus. Sed nesciunt facilis amet necessitatibus. Earum quo inventore voluptatibus in laudantium architecto.',1,'OyTDTmRa4M',0,'1996-01-19 20:15:32','1999-11-02 04:14:33',2,0),(251,'gutkowski.agustin','Prof. Don Monahan I','kody.spencer@example.net',NULL,'2024-04-15 08:04:56','55462 Rosenbaum Meadow Suite 551\nLake Helen, LA 73289','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-10-30 14:38:53','Aliquam est molestias harum quisquam perspiciatis. In molestiae autem rerum voluptatem sapiente. Voluptatibus corrupti et exercitationem ducimus rerum sed eos.',NULL,'Beatae ea dolorem nihil deserunt et laborum incidunt molestias. Sint et quo error modi alias. Enim quia vel quasi.',0,'i3YwBk87JA',0,'2001-03-11 09:51:31','2001-09-08 07:15:51',1,0),(252,'jonas.harber','Roberto Hermann','elisabeth.bernier@example.net',NULL,'2024-04-15 08:04:56','785 Rath Crossing Suite 505\nEdwardoview, WA 36254-2481','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-02-16 18:25:43','Et neque saepe culpa nobis aut. Magnam delectus a perferendis fuga ut corrupti. Quasi omnis aut necessitatibus. Quasi expedita in est eligendi adipisci.',NULL,'Dicta sint reprehenderit itaque neque sapiente ut sequi. Autem nam sed quos quia.',0,'pSQDRqIzgL',0,'1994-06-21 22:37:20','1996-01-17 20:11:25',2,0),(253,'kerluke.brandon','Oran McGlynn','rachelle.runte@example.org',NULL,'2024-04-15 08:04:56','46164 Keebler Forks Apt. 566\nLake Casperville, WI 81612-1747','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-01-17 15:45:42','Sunt autem possimus voluptates. Sed non dolor ex repudiandae qui commodi autem. Dolor minus placeat est libero ab sed et.',NULL,'Labore impedit ut occaecati nihil assumenda vitae. Consequuntur et minus ex aspernatur libero at.',1,'nyVIYXJD4l',0,'1995-05-29 02:53:00','2001-02-20 04:15:31',2,0),(254,'koepp.valerie','Vern Greenfelder','brekke.cedrick@example.net',NULL,'2024-04-15 08:04:56','3345 Mayert Stravenue Apt. 880\nSouth Malloryhaven, SC 05139','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-05-11 06:55:56','Provident illum soluta alias et labore autem. Cumque laborum atque sint quis consequatur culpa. Et natus sed sed fuga.',NULL,'Vero ea nesciunt nobis eum maxime repellat. Ad deleniti perspiciatis assumenda similique. Nesciunt dicta et natus cupiditate. Quos est qui quod distinctio et.',0,'PRbECJHrHN',0,'1994-07-24 13:30:55','2003-09-23 23:50:48',0,0),(255,'rau.marshall','Tamia Gleichner','walker99@example.net',NULL,'2024-04-15 08:04:56','267 Brown Lights\nDeckowfurt, MD 21820','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-08-15 15:36:23','Sit earum sed officia enim. Aut aliquam consequatur accusamus quia quasi. Ut quo expedita distinctio veritatis. Labore veniam praesentium explicabo temporibus et ut recusandae.',NULL,'Consequatur omnis quam officiis ea excepturi. Dolorem est eum velit qui exercitationem. Modi et rerum non vel cupiditate est occaecati hic.',0,'3kE7r7nNDo',0,'2002-04-03 06:03:23','1994-06-06 19:51:08',1,0),(256,'dhackett','Daisha Weimann','morris75@example.org',NULL,'2024-04-15 08:04:56','378 Gislason Crossing Suite 784\nPrudencemouth, AK 66190-8059','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-12-28 09:58:53','Nobis ut labore explicabo accusantium totam et qui. Quam in culpa nostrum optio neque quia culpa.',NULL,'Aperiam non assumenda reiciendis vitae odit odit. Ab nihil illum voluptas est sunt dolorem harum dolor. Qui modi molestiae atque error consequatur possimus assumenda.',0,'4gUGtgc3wR',0,'2003-12-18 21:44:41','1997-01-26 23:06:13',2,0),(257,'hugh.bechtelar','Jerod Powlowski','barrows.eleanora@example.com',NULL,'2024-04-15 08:04:56','56460 Smith Expressway\nSandyfurt, SD 46376','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-05-31 05:10:02','Fugiat sed autem provident perferendis necessitatibus. Et eligendi sit eaque dolorem impedit et. Cumque vitae et maxime. Officiis omnis fugiat dicta fugit dolorem voluptas.',NULL,'A fugit quia voluptatibus occaecati cumque. In quasi repudiandae officiis ut libero. Accusamus earum nisi impedit. Quod deserunt maxime assumenda vero eos delectus.',1,'CVQUOOXieq',0,'2002-01-26 05:03:03','1995-03-21 17:52:30',0,0),(258,'abdiel.kautzer','Dorothy Beer','ibalistreri@example.com',NULL,'2024-04-15 08:04:56','9699 Elmore Tunnel\nPort Greg, OK 42440-9193','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-03-30 23:02:40','Natus odio facilis quia quas sint. Quod ducimus magnam repudiandae vel nisi. Labore consequuntur quia cupiditate minus voluptatem mollitia. Inventore fuga sunt a sunt ratione.',NULL,'Ipsam quo voluptates impedit voluptas laudantium saepe. Qui rem est laudantium enim aut. Voluptas sed molestiae deleniti ut recusandae inventore voluptatem. Ut aut quia doloremque eius.',1,'K7CymN9gkM',0,'1994-12-18 11:35:58','1999-06-19 18:19:27',1,0),(259,'crist.elton','Mr. Guiseppe Donnelly','emie97@example.net',NULL,'2024-04-15 08:04:56','74005 Thomas Rue Apt. 314\nKuphalside, VA 17592','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-08-25 08:11:12','Dolorem hic dolores est culpa. Veritatis et laborum qui quis laudantium quisquam. Fuga quae omnis illum libero deleniti officia. Sed qui aut nesciunt id cumque harum nihil.',NULL,'Omnis repellendus est amet. Perspiciatis provident totam minima est quibusdam. Doloremque at asperiores quis expedita accusantium cum commodi provident.',0,'ySCfWNIzgM',0,'1996-04-24 19:27:05','1999-03-11 07:10:04',0,0),(260,'edwin79','Unique Altenwerth','salvador.corwin@example.com',NULL,'2024-04-15 08:04:56','9393 Purdy Avenue Suite 235\nNew Hectorfort, NH 88849-8881','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-09-12 16:10:55','Qui deserunt labore nostrum minima. Sint itaque rerum non suscipit officiis aut laborum. Quos velit harum inventore laborum.',NULL,'Est velit distinctio mollitia odio quidem repudiandae. Tempore asperiores dolor repellendus recusandae. Odio enim mollitia dignissimos aut. Sed totam qui impedit.',1,'MAJfHOlAbv',0,'2000-05-25 14:57:55','2006-03-06 01:17:43',1,0),(261,'roosevelt62','Maymie Stokes','zbruen@example.com',NULL,'2024-04-15 08:04:56','45643 Otto Glens Apt. 290\nNorth Ivy, WI 32303-7020','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-08-08 23:32:46','Nemo aut beatae quibusdam corrupti expedita ipsam. Tempore in dolor et ut laudantium. Rem vel repudiandae ab perspiciatis voluptate molestiae. Quod non blanditiis ab et et.',NULL,'Aliquid est explicabo in consequatur ut. Voluptas sint doloribus ut facilis doloribus. Debitis et quidem distinctio debitis maxime eius. Illo numquam veniam blanditiis ut.',0,'JObZRzwAnP',0,'1997-03-04 13:15:46','1996-01-19 13:51:23',2,0),(262,'ghickle','Dr. Charlie Bergstrom','kris.sonya@example.org',NULL,'2024-04-15 08:04:56','3392 Reinger Rapid Apt. 340\nDelphiaborough, SD 44571-7329','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-07-02 16:26:06','Hic exercitationem iste qui nostrum ducimus culpa. Voluptatem eveniet dolores ut ut. Itaque sit qui dolores eligendi nisi.',NULL,'Sunt excepturi sequi nulla id amet. Vel dolor similique ut sunt praesentium corporis facilis. Explicabo nisi est sit qui quaerat.',1,'1rrrnsNUIL',0,'1999-09-28 05:12:46','2003-08-02 08:11:15',2,0),(263,'graham.travon','Mike Feeney','bcorkery@example.org',NULL,'2024-04-15 08:04:56','3066 Zieme Manors\nBarrowsport, PA 32257-0733','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2004-03-31 16:50:46','Autem eaque quia voluptas dolorem aut. Explicabo qui laboriosam dolores molestiae qui. Vitae delectus quo dolores assumenda et minima eligendi. Harum et magnam omnis rerum a.',NULL,'Enim sint et ut sint accusamus et aut. Neque exercitationem voluptas quis qui repudiandae eveniet eaque. Id voluptatem quos omnis consequuntur impedit quae.',1,'pNji6RpzV1',0,'1997-09-13 21:03:22','1997-01-06 05:02:43',2,0),(264,'darby87','Mariela Roob','klangosh@example.net',NULL,'2024-04-15 08:04:56','74682 Demario Locks\nDibberthaven, DC 72281-8965','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2002-06-24 05:41:09','Quia accusamus nostrum ut. Sit iusto amet dolorem. Sunt dignissimos reiciendis enim quod quia et. Sed recusandae ad hic maiores dolores.',NULL,'Omnis soluta magni aliquid ut ut. Minima non quis qui nulla amet fugiat. Sunt quia architecto quia molestias rem. Molestias non labore laborum rerum maiores doloremque.',1,'KnLYvUMdV2',0,'1995-07-07 03:41:55','1999-05-30 23:34:51',2,0),(265,'ratke.jarred','Camille Barton','heidenreich.immanuel@example.com',NULL,'2024-04-15 08:04:56','902 Bauch Common Apt. 897\nHayesstad, ME 15627','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-11-01 21:56:26','Quidem voluptates sint in nam aut perferendis corporis. Sit dignissimos consectetur id sit laudantium. Omnis laboriosam excepturi illo suscipit vel consequatur aut.',NULL,'Enim voluptates ipsa rem molestiae alias. Voluptatem vel similique id et id. Placeat veniam sed aut eligendi. Ut iusto et qui.',1,'caEhYQtz5A',0,'1997-03-30 09:55:45','2002-09-20 02:09:45',1,0),(266,'ikuhlman','Niko Balistreri','raynor.hassie@example.net',NULL,'2024-04-15 08:04:56','44295 Zulauf Ville\nLake Faustochester, AR 45197','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-07-15 01:35:33','Culpa quis natus vero. Possimus qui ipsa suscipit aperiam. Recusandae blanditiis incidunt natus omnis fugit. Est blanditiis dolore assumenda ab recusandae.',NULL,'Repellendus eaque nostrum in. Voluptas vel aspernatur a. Odit in rem sit. Exercitationem nobis molestiae recusandae nihil et et.',0,'oUKPZRxf9x',0,'2001-10-16 10:55:35','1997-05-05 07:51:45',2,0),(267,'simeon40','Geovany Pfannerstill','dorothea.schoen@example.org',NULL,'2024-04-15 08:04:56','1159 Renner Forges Suite 205\nPort Melvina, ME 19849','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-02-11 19:35:34','Quam expedita iste nam sed est consequuntur. Quasi ea expedita cumque provident velit ipsam similique. Magnam cumque qui labore architecto minima odio aut harum.',NULL,'Veniam quam sit nihil suscipit nihil ex sint commodi. Natus qui deserunt doloribus odio eos eos. Dolorum quod rerum dolorum dolor consectetur sint.',0,'iNPuI51pIh',0,'2005-06-19 00:40:18','2002-06-06 21:53:59',0,0),(268,'natasha.altenwerth','Lee Hahn','riley62@example.org',NULL,'2024-04-15 08:04:56','830 Oceane Village Apt. 142\nRileybury, OK 56263','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-07-29 15:15:21','Ea voluptatem sit pariatur omnis eos voluptate quia. Velit id est in magnam. Saepe voluptas voluptas fuga velit. Magnam mollitia alias et et consectetur unde vel reiciendis.',NULL,'Iure odio consectetur blanditiis at maiores et. Iusto magni quasi voluptatem harum qui harum. Est provident doloribus sed quis. Doloremque delectus sint occaecati perferendis et voluptatibus.',0,'NA6xUgUU90',0,'2004-02-26 07:21:09','1997-03-12 05:34:58',0,0),(269,'wilkinson.urban','Joanny Cummerata','reinger.lon@example.net',NULL,'2024-04-15 08:04:56','70488 Cynthia Junction\nGardnermouth, ID 93633-2058','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-12-12 10:43:47','Et perspiciatis quod facere ut itaque. Ratione similique illum assumenda et quisquam sit. Et alias voluptatem quis voluptas et odio. Nostrum quis et laborum expedita modi tempore sapiente itaque.',NULL,'Exercitationem et magni quia ducimus cum. Sed recusandae ab labore veniam. Sit quasi nemo et laboriosam corporis odit enim. Non ex eveniet distinctio fuga.',0,'0UA90Xvzr3',0,'2002-11-21 16:23:48','2004-04-06 17:43:50',1,0),(270,'bmitchell','Chet Rohan','federico.wisozk@example.org',NULL,'2024-04-15 08:04:56','96981 Labadie Greens\nPort Melvinatown, IL 19373-0697','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-09-22 20:26:47','Voluptas sunt voluptates autem recusandae voluptatem vero exercitationem est. Ullam maxime atque dolores sit placeat dolore. Facere et est in et a.',NULL,'Tempore facere aliquid hic adipisci tenetur qui. Illum animi sed fuga et. Eos vel eum in totam architecto necessitatibus natus. Eaque natus velit sed facilis quisquam nulla aut blanditiis.',1,'x1fTlLcpXX',0,'1999-10-20 22:10:18','1997-09-03 09:59:57',2,0),(271,'bbartell','Juana Pfeffer','braulio.block@example.net',NULL,'2024-04-15 08:04:56','1233 Ashlee Greens\nEast Gilbert, VA 86324','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-07-02 06:25:59','Rerum quia aliquid voluptatum ad dolores qui. Non tempore minus impedit eum. Velit inventore tempora ducimus est magnam. Cumque molestiae sequi itaque nihil.',NULL,'Sed suscipit quaerat doloribus commodi beatae alias. Ab velit nemo nobis et rerum doloribus. Quod est est earum.',0,'ItVPwB42ZF',0,'1997-12-21 12:06:08','1996-01-06 02:19:21',2,0),(272,'maxie.mann','Mr. Terry Sipes II','fritsch.palma@example.org',NULL,'2024-04-15 08:04:56','8690 Devan Gardens\nRitaland, WY 19406-5576','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-07-26 02:48:28','Consequuntur est est corporis aperiam iure quibusdam itaque. Nulla illum vero autem molestias sunt ratione. Quis dolorum debitis aut dolores autem. Ut iure blanditiis consequuntur porro quas.',NULL,'Repellendus et officia rem est et nihil consectetur. Veritatis quisquam sunt quia. Iste sed porro nostrum ducimus. Eum soluta nisi voluptatum.',0,'gE2wCwxOwk',0,'1999-12-03 22:46:58','2001-12-26 22:30:18',1,0),(273,'virgie.bergnaum','Dr. Lolita Kuhic','esteban20@example.org',NULL,'2024-04-15 08:04:56','4607 Quentin Court Suite 259\nSavionshire, HI 65387-8059','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-06-20 16:53:05','Et voluptas natus occaecati nihil saepe impedit omnis et. Nihil quam voluptas et officiis dolore quia accusamus magnam. Ipsum voluptatem quisquam culpa quidem dolores.',NULL,'Impedit et repudiandae nisi saepe ipsam reiciendis. Esse beatae sunt et molestiae laudantium iste et deleniti.',0,'CKLgzFAPHl',0,'2006-01-26 11:10:38','2001-05-31 09:10:34',0,0),(274,'loyce37','Felton Collins','qdamore@example.org',NULL,'2024-04-15 08:04:56','5888 Lexi Forge\nWisozkchester, MA 97158-7316','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-04-15 15:49:31','Quod aliquam natus magni sequi consequuntur aliquam. In modi vero delectus consequatur cumque. Eius commodi alias quod voluptas voluptatem nobis qui laborum.',NULL,'Modi natus quo nostrum veniam laboriosam et. Reprehenderit culpa dolores nesciunt officia incidunt earum debitis. Sequi consectetur facilis totam est voluptatum error.',0,'Fc0BiEsNnQ',0,'2003-04-19 12:36:34','2005-09-19 09:44:52',2,0),(275,'htowne','Mr. Aric Kertzmann II','iabbott@example.net',NULL,'2024-04-15 08:04:56','35049 Leopoldo Turnpike Apt. 692\nPrudencetown, MO 33933-5902','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-11-22 17:07:23','Eius sed odio incidunt suscipit laborum. Beatae delectus numquam et ratione similique et soluta. Culpa possimus autem est et sint qui et.',NULL,'Dolores ipsam nisi ut dicta architecto officia officiis. Quaerat officia qui aperiam. Accusantium iste et minus voluptas tenetur. Dignissimos recusandae ipsa delectus pariatur qui sequi nobis ipsum.',1,'QR5hD4j5Mt',0,'1995-09-07 14:28:27','1996-04-18 01:31:04',2,0),(276,'olin89','Heaven Conn I','santiago23@example.com',NULL,'2024-04-15 08:04:56','52441 Madie Camp\nPedroborough, MN 01935-0265','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-03-14 20:07:42','Ut exercitationem consequatur ad atque veritatis ducimus. Rerum nihil laboriosam qui consequatur. Sint perferendis eaque qui nihil.',NULL,'Odio omnis velit aut dolorum. Qui eum ipsam non excepturi.',0,'aaY9UfJlYx',0,'2002-06-05 11:25:04','1996-07-26 05:38:26',0,0),(277,'guadalupe.corkery','Dr. Kyler Rau','ydamore@example.com',NULL,'2024-04-15 08:04:56','206 Ron Spur Apt. 689\nNorth Jayceton, VA 40518','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-03-09 02:42:38','Culpa et voluptas excepturi et ratione. Aut facilis autem voluptas exercitationem. Tempore vero ipsum quidem ut et. Officia sequi aut suscipit dolorem.',NULL,'Delectus vel saepe molestias ut dolor nihil. Consequatur optio et et voluptatem. Atque autem totam dignissimos alias fugit.',0,'YC7HJ71z2S',0,'2005-06-20 20:28:12','2000-10-20 09:03:33',1,0),(278,'vharris','Vernice Macejkovic','willow.oreilly@example.net',NULL,'2024-04-15 08:04:56','5325 Ratke Streets\nPort Kennediborough, RI 88734','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-08-14 15:11:53','Ea quas sunt soluta quo. Atque libero illum recusandae veniam et accusamus. Omnis qui ex et cum provident omnis eligendi.',NULL,'Qui odio consequatur fugit exercitationem cupiditate nam quasi. Molestiae facilis iure facilis sit architecto facilis magni. Assumenda hic aut delectus voluptate mollitia sed. Qui id aut ut id.',0,'y1Tw4QM3WM',0,'1999-10-17 18:49:33','1997-12-04 00:35:47',0,0),(279,'hwiegand','Ramona Bartoletti Jr.','swaelchi@example.net',NULL,'2024-04-15 08:04:56','13854 Ondricka Common\nLoweburgh, NY 05992','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-04-16 21:31:49','Assumenda fuga quam quia ex. Repudiandae ut rerum perferendis tempora aliquam tenetur.',NULL,'Sint in facilis qui quia. Velit ab qui qui corporis. Et aut quia minima quasi cupiditate. Sint est qui id qui et possimus sequi. Inventore inventore sed incidunt mollitia.',0,'SstB3viCn3',0,'1997-11-06 02:57:39','1997-10-14 23:32:40',1,0),(280,'greta.roberts','Kaya Koelpin','nienow.winifred@example.org',NULL,'2024-04-15 08:04:56','293 Carolanne Drive\nLake Elmoville, AR 73575','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-02-26 00:26:21','Eaque non vitae quis expedita rerum. Fugit autem voluptatem reiciendis laboriosam modi. Sunt et error culpa laudantium aliquam qui quia.',NULL,'Pariatur soluta qui molestiae et molestias magni. Iure in quaerat qui enim. Ut nihil corporis et optio rerum iure amet.',0,'OcoIiyhS2h',0,'2000-10-28 09:35:15','1995-05-21 18:06:47',1,0),(281,'lernser','Maybell Casper','eldora32@example.net',NULL,'2024-04-15 08:04:56','868 DuBuque Way\nLake Santosborough, TX 52446','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-09-11 01:12:09','Nesciunt modi sit tempore dignissimos. Voluptas iste corrupti non debitis sit id. Tempora nulla eligendi est debitis doloremque aliquam. Numquam rerum et explicabo molestiae totam harum.',NULL,'Earum ab omnis veritatis nihil. Voluptatem et corporis fugit quaerat magnam ducimus aut. Veritatis quis quibusdam ut tempora reprehenderit aspernatur enim.',0,'Qq30YkRaU4',0,'2002-04-24 11:26:56','2005-08-26 19:36:10',1,0),(282,'alice.shanahan','Dr. Rashad Smitham','lind.ahmed@example.org',NULL,'2024-04-15 08:04:56','72631 Padberg View\nEast Laurel, AK 37948-6590','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-10-23 07:31:07','Numquam cumque cumque officiis sapiente id tempora optio. Nemo nemo neque occaecati voluptate. Veritatis tempore nihil id nemo quis eius.',NULL,'Non voluptas perspiciatis omnis voluptatem praesentium quia aliquam. Fugit ipsum earum ipsum et enim veniam qui. In aspernatur et cumque quis accusamus aut.',1,'aHtKKa9pc0',0,'1999-03-18 05:58:35','1995-06-06 02:51:15',0,0),(283,'ebernhard','Ronny Willms PhD','renner.tessie@example.net',NULL,'2024-04-15 08:04:56','762 Medhurst Turnpike Suite 530\nElmerstad, CO 43554','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-11-05 19:23:10','Autem et ipsa sit repudiandae. Corporis hic laboriosam molestiae. Sed in quidem atque quibusdam non rem sequi.',NULL,'Est quo fuga corrupti nulla. Natus non maxime mollitia cupiditate aperiam et. Recusandae dolores cupiditate tenetur voluptate aperiam. Fugiat cupiditate placeat delectus est placeat.',1,'KBCiw9tlxy',0,'2001-05-17 07:15:28','2001-10-10 14:04:03',1,0),(284,'wehner.rosie','Sabrina Schmeler','hspinka@example.org',NULL,'2024-04-15 08:04:56','39185 Beahan Mountain Suite 947\nPort Kaleb, KS 96886','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-06-17 02:41:59','Recusandae occaecati tempora iste et ullam aut tempora. Et nam qui quia. Cum et cumque odit. Quia officiis eum voluptas ipsum ut dolores rerum.',NULL,'Minus quia est voluptatum iste repellendus ut. Ab porro quasi dicta qui accusamus. Earum perferendis tempore ex cumque officia quisquam est. Consequatur dolores similique doloribus omnis sit.',0,'eQmN1FysWE',0,'1995-02-09 12:18:25','1998-08-15 13:44:02',2,0),(285,'jamey.quigley','Margaretta Thompson','xcrist@example.net',NULL,'2024-04-15 08:04:56','590 Alejandrin Trafficway\nLake Clarabelleberg, WI 21535-1673','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-05-15 08:28:24','Quisquam explicabo est ipsam consequatur voluptates. Non voluptatem autem sit nostrum blanditiis. Velit minima cum quam dolores et. Fuga iure autem vero.',NULL,'Sunt qui praesentium qui sit architecto aut. Quae at velit consequatur magnam aut nesciunt iste. Aspernatur voluptates iure rem dicta.',0,'1IhYFfrCQS',0,'2001-03-06 16:03:06','2003-07-24 12:53:48',0,0),(286,'branson13','Sabina Quigley DVM','senger.karley@example.net',NULL,'2024-04-15 08:04:56','98508 Leuschke Common\nWest Ofelia, IL 29225-2214','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-08-19 22:02:57','Accusamus facere dolor consectetur autem quasi corporis fugiat numquam. Nobis molestias dolorem asperiores voluptatem. Possimus quas fuga qui odio.',NULL,'Quia earum aliquam et odit. Explicabo voluptas harum non praesentium eos ea cum. Ut fugit modi sed aut fuga ea.',0,'bZDH4oGy3V',0,'2001-02-27 04:54:16','1994-07-28 23:00:08',0,0),(287,'friesen.odie','Mrs. Willa Prohaska Sr.','xchamplin@example.net',NULL,'2024-04-15 08:04:56','413 Elna Roads Apt. 594\nLake Abeberg, AR 72012','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-08-03 12:44:37','Alias quidem laboriosam excepturi accusamus accusantium. Id qui vero cumque beatae libero optio sunt. Inventore fuga inventore autem eaque. Quisquam pariatur mollitia dolore unde molestias et.',NULL,'At ut quia sunt culpa dolorum. Laudantium unde soluta enim minima at architecto ex ratione. Minima pariatur et cupiditate quo officia voluptatum. Ratione dicta eum fuga consequatur.',0,'EvwK6J8jRM',0,'1995-01-03 19:09:58','1998-05-03 09:25:31',2,0),(288,'xhickle','Dr. Ed Mann I','kihn.thelma@example.net',NULL,'2024-04-15 08:04:56','714 Dariana Avenue\nSouth Zachariahport, KS 57558-0026','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-03-30 07:53:51','Voluptas quis ut aut est dolorem consequatur. Ad repellendus porro assumenda recusandae ut. Blanditiis ad fugit aut illum. Qui aspernatur repellat aut sit.',NULL,'Autem voluptatem nisi non accusamus occaecati voluptate blanditiis. Consequatur ducimus eos aliquid. Id et quis nostrum tempora dolorem. Perspiciatis atque est numquam consequuntur est dolorum.',0,'aMw20fxFd1',0,'2003-12-25 19:28:25','2002-01-07 20:52:29',2,0),(289,'florine84','Lewis Harvey V','nnitzsche@example.org',NULL,'2024-04-15 08:04:56','85364 Madyson Canyon\nNorth Gianniton, KS 28384-5536','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1996-05-23 14:09:52','Quis atque sit vero maxime. Libero molestias ut qui magni est dolor. Beatae ex assumenda ducimus at. Totam similique necessitatibus placeat.',NULL,'Neque animi eum omnis animi tempore. Rem dignissimos quis est corrupti omnis nulla. Cum sapiente in aut asperiores nulla voluptate.',1,'uRH5UFJ8rL',0,'1998-07-29 16:42:30','2003-03-25 00:37:33',2,0),(290,'florine72','Carlie Abshire','mabel04@example.org',NULL,'2024-04-15 08:04:56','811 Jonas Branch Apt. 773\nLake Percy, NM 01118-3733','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-03-04 14:59:16','Nam quos dignissimos quo repellat illum facere. Soluta temporibus quia officia et quia labore quisquam. Non qui error reprehenderit optio ipsum excepturi quaerat. Eligendi suscipit eos et labore aut.',NULL,'Voluptatem sunt iste deserunt et ducimus porro fugit unde. Vitae qui maxime repellat unde. Aut quam ut dolorem minima. Sequi et natus neque aut eligendi est aut commodi.',1,'AKR0Uv7Dyq',0,'2004-06-22 00:38:53','2003-10-08 06:12:39',2,0),(291,'johnson.annette','Mr. Jovany Boyle','dadams@example.com',NULL,'2024-04-15 08:04:56','3176 Fisher Cliff\nLake Alena, IA 04207','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-08-07 16:27:53','Est non exercitationem repellat eum est quos. Quae aut voluptatem enim neque nulla quia et. Aliquid sequi iure architecto.',NULL,'Libero nobis dolores amet minus dicta. Ad tenetur vel rerum at dignissimos quo.',0,'q2eMgEShG2',0,'2000-10-18 11:18:00','1996-12-26 02:06:07',2,0),(292,'mellie.bosco','Mr. Montana Bashirian','wvon@example.com',NULL,'2024-04-15 08:04:56','618 Marcelo Divide Suite 303\nSchusterberg, IN 94037-1546','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-11-30 04:25:21','Sequi minima corrupti sunt velit dolores. Voluptas itaque ea facere tempore.',NULL,'Est vitae atque harum et sed alias animi. Cum vel aperiam saepe ut debitis ipsam.',1,'BvgObqUtGc',0,'2004-10-02 22:47:11','1999-03-07 03:36:20',1,0),(293,'elang','Sunny Kris','garett.wintheiser@example.org',NULL,'2024-04-15 08:04:56','73885 Eichmann Forest\nEast Meredithton, VT 12550','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2000-03-17 06:34:52','Ipsum rerum laboriosam et quas rerum. Quo sunt temporibus eum. Mollitia odio temporibus laboriosam corporis.',NULL,'Non commodi commodi est quia porro aut. Non nulla qui rerum. Temporibus aut ducimus libero molestiae amet dolorem.',0,'t5SHDDEgQe',0,'1997-10-14 19:29:42','2001-10-08 10:17:44',2,0),(294,'trever32','Prof. Harry Cummings','dallin.parker@example.org',NULL,'2024-04-15 08:04:56','130 Feest Run Suite 955\nGraycehaven, AR 33421-6227','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1997-02-18 10:47:19','Molestias quod magni voluptatem excepturi laudantium voluptas maxime. Et fugiat in repellat est blanditiis nam. Quia aut eius nisi est sed aut. Commodi assumenda id labore modi.',NULL,'Accusantium pariatur dignissimos id inventore quia aspernatur. Laudantium et rerum rem eos occaecati et beatae. Autem iusto earum sequi autem.',1,'wSmqGk1Dgf',0,'1994-06-09 00:58:35','2004-01-14 17:09:37',1,0),(295,'mills.kailyn','Lloyd Wilderman II','seamus.turner@example.com',NULL,'2024-04-15 08:04:56','54771 Osvaldo Crest\nNew Myrtiehaven, RI 90457','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1999-06-16 15:08:19','Repudiandae explicabo eveniet et odit aspernatur repellat id. Facilis rem labore aut dolore quia dolore est facilis. Incidunt atque a nemo exercitationem harum velit.',NULL,'Libero recusandae totam ut labore magni sed est modi. Est est nisi nihil. Reprehenderit incidunt reiciendis voluptates dolore veniam. Quis vero a qui ut dignissimos itaque unde.',1,'GDMDGiNDfs',0,'2003-11-19 03:47:42','2003-05-31 01:31:43',0,0),(296,'yohara','Coby Towne','riley88@example.net',NULL,'2024-04-15 08:04:56','141 Bode Turnpike\nGlennaburgh, ND 66691-8278','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2003-11-19 18:51:52','Aut nobis atque nostrum dolor porro. Voluptatem aspernatur enim assumenda eligendi sequi. In perspiciatis et sunt blanditiis. Sit velit voluptatum quasi eos.',NULL,'Molestias nisi quibusdam repellat illum repudiandae sed modi. Qui quasi dolorem dolores ut.',0,'s2Ek1bzQSR',0,'1998-06-04 16:22:40','1994-07-13 12:20:26',1,0),(297,'efay','Lonie Zboncak','kshlerin.aron@example.net',NULL,'2024-04-15 08:04:56','53601 Bins Cliffs Apt. 281\nSouth Lancemouth, DE 28940','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1998-08-26 06:02:41','Magni sint animi libero officia quis. Consequuntur sit doloremque aspernatur tenetur architecto alias quia. Voluptatibus ad soluta qui officiis. Perferendis et ex minus.',NULL,'Blanditiis et fugit earum necessitatibus ullam. Ut quam laborum cumque et velit. Aperiam ut commodi et quasi dolorum iusto. Est impedit illum molestiae est.',0,'GZ5nbNczsY',0,'1994-12-20 18:03:12','1998-07-14 22:58:14',1,0),(298,'neil.stiedemann','Dr. Vivienne Weber V','della.adams@example.net',NULL,'2024-04-15 08:04:56','3527 Laney Squares Suite 587\nBartborough, CO 05292-5502','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','1995-07-13 15:24:32','Nihil officiis non nihil quia labore cumque ipsa suscipit. Harum cum atque possimus qui non qui. Ea sit fugit voluptatem ut nihil veniam corporis nisi.',NULL,'Fugit error reprehenderit qui temporibus. Iure alias ullam maxime alias alias est. Suscipit iste a consequatur laboriosam quae. Repudiandae blanditiis ut amet molestiae quod quidem.',1,'TJiKBatV9a',0,'2003-12-02 03:00:57','2024-04-20 14:35:27',1,0),(299,'harmon.paucek','Dr. Genevieve Welch','myron.gerlach@example.org',NULL,'2024-04-15 08:04:56','9946 Cortney Mall\nWest Dwightport, UT 15671-4327','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2005-06-05 07:00:22','Molestiae sint mollitia nostrum enim dolores voluptatem. Consequatur et doloribus ipsa. Nihil incidunt aliquid esse dolorem.',NULL,'Sunt voluptatem sed esse dolores molestiae magnam. Dolores reprehenderit qui necessitatibus atque totam exercitationem sunt optio. Error dolores et voluptate vero.',1,'4bqBnH35me',0,'1994-06-13 21:17:27','1997-06-08 13:14:52',0,0),(300,'schimmel.lacy','Prof. Meaghan Haag Sr.','bogan.elyse@example.net',NULL,'2024-04-15 08:04:56','45414 Lyla Street\nMaudbury, KY 71455','$2y$12$bzYRB1KaVuK9LbDev38XpOCl2S5g3w6nG64opAixw5TBdB2NmwRhO','2001-06-16 09:39:55','Necessitatibus soluta aut recusandae dicta quo omnis. Distinctio veritatis eius quas assumenda. Ducimus quisquam dolorum nemo provident fuga.',NULL,'Doloribus aperiam odio non et porro nihil. Velit reprehenderit similique et tempora optio qui ea. Id quidem voluptatum sit consectetur.',0,'xZpWCRpCqA',0,'1998-04-27 04:08:18','2005-04-24 16:40:49',1,0),(301,'lxq2309','Quynh Le','lxq.2309@gmail.com',NULL,'2024-05-01 06:45:53',NULL,'$2y$12$TrQ9P90Ryf4r5ZFL2.rBcumj6OiwaNhk//P44XpaEH9baBvLIbzli',NULL,'/images/users/default.jpg',NULL,'nothing',NULL,'lquk22aPYLKzSZP2T3MRB8RvuBBaDzM3Dzqncm1bzfYKcf81abkLqOJDHuVq',0,'2024-04-25 13:20:12','2024-05-01 06:45:53',0,0),(302,'lxq23092','Quynh Le','lxq.23092@gmail.com',NULL,NULL,NULL,'$2y$12$UNu9G7O/7bB4u14cnxOWbuPc6uJUmfe6.Yh/Wlz2xYsjVKQDuSbv2',NULL,'/images/users/default.jpg',NULL,'nothing',NULL,'boPmA8uJu8O2QjFaSbvP2YU6WOWvZsP2g1KUU1SLX3gZg63ThHCbLVEhUfQl',0,'2024-04-25 13:22:13','2024-04-25 13:22:13',0,0),(303,'lxq.23093','Quynh Le','lxq.23093@gmail.com',NULL,NULL,NULL,'$2y$12$UoZnjhGSVC1KiKMcrGHwruk4m4t1Z5mohqyBo8NTlfzq/v6fOxnTu','2024-04-25 14:38:52','/images/users/default.jpg',NULL,'nothing',NULL,NULL,0,'2024-04-25 14:38:52','2024-04-25 14:38:52',0,0),(304,'lxq.23094','Quynh Le','saobangkhoc10x@gmail.com',NULL,NULL,NULL,'$2y$12$I3J0LmHYkTzTHcsqu28UoeNIFLdoizeqX8R7JbWg7o84pl8R9TpJy',NULL,'/images/users/default.jpg',NULL,'',NULL,NULL,0,'2024-04-27 11:03:14','2024-04-27 11:07:03',0,0),(305,'liamdo0705','Liam Do','doducliem07052002@gmail.com',NULL,'2024-05-01 06:47:34',NULL,'$2y$12$R8VkC0up9ak4VrjQxcpnLe9v1G8dSZ.CfDiedMorkQE.DdD06qvV2',NULL,'/images/users/default.jpg',NULL,'',NULL,NULL,0,'2024-05-01 06:47:19','2024-05-01 06:47:34',0,0),(306,'user.test','User Test','user.test@mail.com',NULL,'2024-05-01 20:02:15',NULL,'$2y$12$JfXV0oQpUXnNQPhNm1I/l.vzjRtVgtzI20CIVS3WSuNeezz9F8Rlq',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-01 19:56:14','2024-05-23 10:42:40',0,0),(308,'poster.test','Poster Test','poster.test@mail.com',NULL,'2024-05-01 20:03:15',NULL,'$2y$12$JfXV0oQpUXnNQPhNm1I/l.vzjRtVgtzI20CIVS3WSuNeezz9F8Rlq',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-01 19:56:14','2024-05-01 19:56:14',1,0),(309,'admin.test','Admin Test','admin.test@mail.com',NULL,'2024-05-01 20:03:48',NULL,'$2y$12$zc/s7iuG5Lh3J9VYSarXJOqwCepyO1QIc150PgEO7Nxx9.4G51iTS',NULL,'/storage/images/users/309.jpg?v=1781423766',NULL,NULL,0,NULL,0,'2024-05-01 19:56:14','2026-06-14 14:56:06',2,2005),(310,'phuc123','Trần Đình Phúc','phuc@gmail.com',NULL,NULL,NULL,'$2y$12$qgtKVIriXMsB.UgXOxgfQ.qUs.K3RdGQ1CyLUS0PiPMbrZIbHnOlO',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-09 08:00:24','2024-05-09 08:00:24',0,0),(311,'phuc1','Trần Đình Phúc','trandinhphuc1410@gmail.com.vn',NULL,NULL,NULL,'$2y$12$7.a91kjCVxVteGkxLoQNMOTdvkQRnT.Y2vbiT1ESn1VGFVGACuxwG',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-09 08:01:51','2024-05-09 08:01:51',0,0),(312,'phuc2','Trần Đình Phúc','trandinhphuc1410@gmail.com',NULL,'2024-05-09 08:04:06',NULL,'$2y$12$Q9GxL5wRpyFTMNyIjbwQKeGQvliUmb6iMOupJnWzLg8klZlhZF.Gm',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-09 08:03:56','2024-05-09 08:04:06',0,0),(313,'itbosser','test','itbosser@gmail.com',NULL,'2024-05-12 08:24:22',NULL,'$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC21pudB4BBBLcbPdJoW',NULL,'/images/users/default.jpg',NULL,'',0,NULL,0,'2024-05-12 08:23:19','2024-05-12 08:27:17',2,0),(314,'cuongdtnt109','Cường Phạm Văn Cường','cuongdtnt109@gmail.com','111957474982133011309','2026-06-03 23:40:58',NULL,'$2y$12$BXlioKa4w5iqNmvbCkK0WeGMYo4.troCz1Fpgq0nmAsPOnJJVCEKe',NULL,'https://lh3.googleusercontent.com/a/ACg8ocIMPJjMxA5NEvzjs2cpxi7adcP6Cs3PQDIp35bPBsgpRsOSNg=s96-c',NULL,'',NULL,'3XkY3hKibisDwE9ZPDSq9FU3BaoTDFqyMLJ2KuNyCprrkMsdiPcy9eHs7UKd',0,'2026-06-03 23:40:58','2026-06-03 23:40:58',0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'laravel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19 15:19:35
